import java.util.regex.Pattern;

public class WordCruncher {
	private String word;
	private char[] vowels = { 'a', 'e', 'i', 'o', 'u' };

	public WordCruncher(String word) {
		super();
		Pattern pattern = Pattern.compile("^[A-Za-z]+$");
		if (pattern.matcher(word).matches()) {
			this.word = word;
		} else {
			this.word = "default";
		}
	}

	public WordCruncher() {
		super();
		this.word = "default";
	}

	@Override
	public String toString() {
		return word;
	}

	public int numLetters() {
		return word.length();
	}

	public int numVowels() {
		int count = 0;
		for (int i = 0; i < word.length(); i++) {
			for (int j = 0; j < vowels.length; j++) {
				if (word.charAt(i) == vowels[j]) {
					count++;
				}
			}
		}
		return count;
	}

	public boolean beginsWithVowel() {
		boolean flag = false;
		for (int j = 0; j < vowels.length; j++) {
			if (word.charAt(0) == vowels[j]) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	public String toPigLatin() {
		StringBuffer sb = new StringBuffer();
		if (!beginsWithVowel()) {
			sb.append(word.substring(1, word.length())).append(word.substring(0, 1)).append("ay");
		} else {
			sb.append("way");
		}
		return sb.toString();
	}

	public String toGibberish() {
		StringBuffer sb = new StringBuffer();
		if (!beginsWithVowel()) {
			sb.append(word.substring(0, 1)).append("ithag").append(word.substring(1));
		} else {
			sb.append("ithag").append(word);
		}
		return sb.toString();
	}

	public String reverse() {
		StringBuffer sb = new StringBuffer(word);
		return sb.reverse().toString();
	}

	public int numCharOccurrences(char ch) {
		int count = 0;
		word = word.toLowerCase();
		if (Character.isUpperCase(ch)) {
			ch = Character.toLowerCase(ch);
		}
		for (int i = 0; i < word.length(); i++) {
			if (word.charAt(i) == ch) {
				count++;
			}
		}
		return count;
	}
}
