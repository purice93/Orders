package tiere;
public class Papagei extends Vogel{
	private static final String typ = "Papagei";
		
	public Papagei(String name) {
		super(name,typ);
	}	
}


