package tiere;
public class Adler extends Vogel{
	private static final String typ = "Adler";
	
	public Adler(String name) {
		super(name,typ);
	}	
}
