package tiere;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Adler adler1 = new Adler("American");
		Adler adler2 = new Adler("Dream");
		Papagei papagei1 = new Papagei("Tick");
		Papagei papagei2 = new Papagei("Trick");
		Papagei papagei3 = new Papagei("Track");
		Zebra zebra1 = new Zebra("Eddard");
		Zebra zebra2 = new Zebra("Robb");
		Zebra zebra3 = new Zebra("Zalana");
		Zebra zebra4 = new Zebra("Brau");
		Zebra zebra5 = new Zebra("Arya");
		Loewe loewe1 = new Loewe("Tywin");
		Loewe loewe2 = new Loewe("Jaime");
		Loewe loewe3 = new Loewe("Cersei");
		Loewe loewe4 = new Loewe("Joffrey");
		Walhai walhal1 = new Walhai("Moby");
		Walhai walhal2 = new Walhai("Dick");
		Kugelfisch kugelfisch1 = new Kugelfisch("A");
		Kugelfisch kugelfisch2 = new Kugelfisch("B");
		Kugelfisch kugelfisch3 = new Kugelfisch("C");
		Kugelfisch kugelfisch4 = new Kugelfisch("D");
		Kugelfisch kugelfisch5 = new Kugelfisch("E");
		Kugelfisch kugelfisch6 = new Kugelfisch("F");
		Kugelfisch kugelfisch7 = new Kugelfisch("G");
		Kugelfisch kugelfisch8 = new Kugelfisch("H");
		Kugelfisch kugelfisch9 = new Kugelfisch("I");
		Kugelfisch kugelfisch10 = new Kugelfisch("J");
		
		
	}

}
