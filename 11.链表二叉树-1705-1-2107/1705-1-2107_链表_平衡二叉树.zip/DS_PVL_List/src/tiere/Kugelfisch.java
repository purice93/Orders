package tiere;
public class Kugelfisch extends Wassertier{
	private static final String typ = "Kugelfisch";
		
	public Kugelfisch(String name) {
		super(name,typ);
	}	
}