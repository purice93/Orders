package tiere;
public class Vogel extends Tier {
	private static final String art = "Vogel";
	
	public Vogel(String name,String typ){
		
		super(name,typ, art);
	}
	
	


	
	
}



