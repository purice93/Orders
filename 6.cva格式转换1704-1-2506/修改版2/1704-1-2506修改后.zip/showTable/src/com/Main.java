package com;

import com.windows.AdmintratorWindow;

// 启动函数
public class Main {
    public static void main(String[] args) {
    	// 生成主窗口
        new AdmintratorWindow();   
    }
}