package com.csms;
 
import com.csms.windows.AdmintratorWindow;

// 启动类
public class RunCSMS {
    public static void main(String[] args) {
        new AdmintratorWindow();   
    }
}