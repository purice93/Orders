package demo0611;

import java.awt.print.Book;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Exercise4 {
	// Defines a Map for storing a predetermined list
	// key - seat number ----- Passenger - Passenger type
	private Map<Integer, Passenger> bookedMap = new HashMap<>();

	// Defines the three enumerated types
	public enum Passenger {
		adult, senior, child; 
	};

	// Test the method
	public static void main(String[] args) {
		Exercise4 e4 = new Exercise4();
		e4.bookSeatByNumber(10, Passenger.adult);
		e4.bookSeatByPosition(2, 4, Passenger.child);
		System.out.println(e4.checkNumber(10));
		System.out.println(e4.seatRemain());
		e4.printSeat(2);
	}

	// a) Check if the reservation is made
	public boolean checkNumber(int number) {
		boolean flag = true;
		if (bookedMap == null) {
			return true;
		}
		for (int key : bookedMap.keySet()) {
			if (number == key) {
				flag = false;
				break;
			}
		}
		return flag;
	}

	// b) Book by number,Traverse the search from map
	public boolean bookSeatByNumber(int number, Passenger passager) {
		boolean flag = true;
		if (checkNumber(number)) {
			bookedMap.put(number, passager);
		} else {
			flag = false;
		}
		return flag;
	}

	// c) Number of remaining seats
	public int seatRemain() {
		return 20 - bookedMap.size();
	}

	// d) prints off all the seats in a given row
	public void printSeat(int row) {
		int fisrt = (row-1)*4+1;
		for (int i = fisrt; i < fisrt+4; i++) {
			if (!checkNumber(i)) {
				for (int key : bookedMap.keySet()) {
					if (i == key) {
						System.out.println("seat " + i + " is reserved for " + bookedMap.get(key));
					}
				}
			} else {
				System.out.println("seat " + i + " is unoccupied");
			}
		}
	}

	// e)  Book by Position
	// convert position to the seat number and then use the method bookSeatByNumber
	public boolean bookSeatByPosition(int row, int column, Passenger passager) {
		int number = (row - 1) * 4 + column;
		return bookSeatByNumber(number, passager);
	}

}
