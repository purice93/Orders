package demo0611;
/*
 * Exercise1
 */
public class Exercise1 {
	public static void main(String[] args) {
		Exercise1 ex1 = new Exercise1();

		// b)result is : 2.6666666666666665
		System.out.println(mysteryApprox(2));
		
		// g) result is 3.141592903558554    3.141592655589784
		System.out.println(secondMysteryApprox(100));
		System.out.println(secondMysteryApprox(500));
	}

	// a)
	public static double mysteryApprox(int num) {
		double sum = 0;
		for (int i = 1; i <= num; i++) {
			double temp = Math.pow((-1), num) / (2 * num - 1);
			sum += temp;
		}
		return sum * 4;
	}

	// c)
	public static int tripleProduct(int num) {
		int sum = 1;
		int temp = num * 2;
		for (int i = 1; i <= 3; i++) {
			sum *= temp;
			temp++;
		}
		return sum;
	}

	// d)
	public static int alternateSign(int first, int second) {
		int result = 0;
		if (first % 2 != 0) {
			result = second;
		} else {
			result = (-1) * second;
		}
		return result;
	}

	// e)
	public static double makeFraction(int num) {
		return 1.0 / num;
	}

	// f)
	public static double secondMysteryApprox(int num) {
		double sum = 0;
		for (int i = 0; i < num; i++) {
			sum += computeStep(i);
		}
		return sum;
	}

	public static double computeStep(int step) {
		if (step == 0)
			return 3.0;
		else
			return 4.0 * makeFraction(alternateSign(step, tripleProduct(step)));
	}

}
