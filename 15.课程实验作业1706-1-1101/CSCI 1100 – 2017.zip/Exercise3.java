package demo0611;

import java.util.Scanner;

public class Exercise3 {
	public static void main(String[] args) {
		// c)
		System.out.println(methodA());
		System.out.println(methodB());
	}

	// a)
	public static int methodA() {
		Scanner sc = new Scanner(System.in);
		int input;
		do {
			System.out.println("methodA -- please input an integer value :");
		} while ((input = sc.nextInt()) % 11 != 0);
		return input;
	}

	// b)
	public static String methodB() {
		Scanner sc = new Scanner(System.in);
		String input;
		do {
			System.out.println("methodB -- please input a String :");
		} while ((input = sc.nextLine()).length()<=20);
		return input;
	}
}
