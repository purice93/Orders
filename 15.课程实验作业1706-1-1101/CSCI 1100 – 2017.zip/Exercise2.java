package demo0611;

public class Exercise2 {
	public static void main(String[] args) {
		// c)
		String[] str1 = {"Apples","Oranges","Melons","Watermelon"};
		String[] str2 = {"Apples","Oranges","Pears","Mangos"};
		
		int[] ar1 = {1,2,3,4};
		int[] ar2 = {1,0,1,0};
		
		System.out.println(calculateTotal(str1, ar1));
		System.out.println(calculateTotal(str2, ar2));
	}

	// a)
	public static double checkPrice(String str) {
		switch (str) {
		case "Apples":
			return 0.25;
		case "Oranges":
			return 0.50;
		case "Bananas":
			return 0.75;
		case "Melons":
			return 0.99;
		default:
			return 0;
		}
	}

	// b)
	public static double calculateTotal(String[] strArray,int[] intArray) {
		double sum=0;
		for(int i=0;i<strArray.length;i++) {
			sum+=checkPrice(strArray[i])*intArray[i];
		}
		return sum;
	}

}
