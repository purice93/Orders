package cn.com.util;

import java.awt.HeadlessException;
import java.io.IOException;


public class OracleInput {
	public OracleInput() {

		Runtime rt = Runtime.getRuntime();
		Process processexp = null;
		String imp = "imp  scott/tiger@oracle  file=d:\\tanjindmq.dmp";
		try {
			processexp = rt.exec(imp);
			if (processexp.waitFor() != 0) {
				javax.swing.JOptionPane.showMessageDialog(null, "û�б��ݵ����ݿ���Ϣ�ļ�");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void main(String[] args) {
		new OracleInput();

	}

}
