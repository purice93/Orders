package cn.com.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CloseConn {
	  public static void Close(Connection conn, Statement st, ResultSet rs) {
	      if (conn != null) {
	         if (st != null) {
	            if (rs != null) {
	               try {
	                  rs.close();
	               } catch (SQLException e) {
	                  e.printStackTrace();
	               }
	            }
	            try {
	               st.close();
	            } catch (SQLException e) {
	               e.printStackTrace();
	            }
	         }
	         try {
	            conn.close();
	         } catch (SQLException e) {
	            e.printStackTrace();
	         }
	      }
	   }
}
