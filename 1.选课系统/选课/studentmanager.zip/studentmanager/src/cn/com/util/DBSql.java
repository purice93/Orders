package cn.com.util;

public interface DBSql {
/**
 * ��ʦ������Ϣsql���
 * 
 */
	
//	 ��ѯ������ʦ��Ϣ
	public static final String SELECT_TEACHER_ALL="select * from teacherinfotable t order by t.t_id ";
	
//	 ȫ����ѯ��Ϣ ����
	public static final String SELECT_TEACHER_ALL_COUNT="select count(*) from "
		+ "teacherinfotable t";
	
	// ����ѧ�Ų�ѯ
	public static final String SELECT_TEACHER_BY_T_ID ="select * from " +
	" teacherinfotable  t where  t.t_id = ? order by t.t_id";
	
//	 ���ݽ�ʦ��Ų�ѯ�������
	public static final String SELECT_TEACHER_BY_T_ID_COUNT ="select count(*) from "
		+ " teacherinfotable  t  where  t.t_id = ? order by t.t_id";
	
	
	// ���ݽ�ʦְ���ѯ
	public static final String SELECT_TEACHER_BY_DUTY ="select * from " +
	" teacherinfotable  t where t.t_duty like ? or "
			+ " t.t_duty like ? or t.t_duty like ? or t.t_duty like ?  order by t.t_id";
	
//	 ���ݽ�ʦְ���ѯ�������
	public static final String SELECT_TEACHER_BY_DUTY_COUNT ="select count(*) from "
		+ " teacherinfotable  t  where  t.t_duty like ? or "
			+ " t.t_duty like ? or t.t_duty like ? or t.t_duty like ?  order by t.t_id";
	
	// ����������ѯ
	public static final String SELECT_TEACHER_BY_T_NAME = "select "
			+ " * from teacherinfotable t "
			+ "where   t.t_name like ? or "
			+ " t.t_name like ? or t.t_name like ? or t.t_name like ? order by t.t_id ";

	// ����������ѯ�������
	public static final String SELECT_TEACHER_BY_T_NAME_COUNT = "select count(*) from " +
			" teacherinfotable t where   t.t_name like ? or "
			+ " t.t_name like ? or t.t_name like ? or t.t_name like ? order by t.t_id ";
	
	//ɾ����ѡ��ʦ��Ϣ
	public static final String DELETE_TEACHER_BY_T_ID ="delete from " +
	" teacherinfotable  t where  t.t_id = ? ";
	
	//���ӽ�ʦ��Ϣ
	public static final String INSERT_TEACHER = "insert into teacherinfotable(t_id,t_name,t_sex,t_age,t_duty,t_qq,t_email,t_tel) "
		+ "values(?,?,?,?,?,?,?,?)";
	
	//�޸Ľ�ʦ��Ϣ
	public static final String UPDATE_TEACHER = "update teacherinfotable set " +
			" t_name = ?,t_sex=?,t_age=?,t_duty=?,t_qq=?,t_email=?,t_tel=?" +
			" where t_id=? ";
	
	
	
	
	
	
	
	
	
	
	/**
	 * ��ʦ������Ϣ �߼���ѯ sql���
	 * 
	 */
	
	
	public static final String SELECT_TEACHER_011 = "select * from " +
	" teacherinfotable   where t_id = ? and ( t_duty like ? or "
		+ " t_duty like ? or t_duty like ?  or t_duty like ? ) order by t_id ";
	
		public static final String SELECT_TEACHER_101 = "select * from " +
		" teacherinfotable  "
		+ " where ( t_name like ? or "
		+ " t_name like ? or t_name like ? " +
				" or t_name like ? ) and t_id = ? ";
	
		public static final String SELECT_TEACHER_110 = "select * from " +
	" teacherinfotable  where "
		+ " ( t_name like ? or "
		+ " t_name like ? or t_name like ? " +
				" or t_name like ? ) and ( t_duty like ? or "
		+ " t_duty like ? or t_duty like ?  or t_duty like ? ) ";
	
	
		public static final String SELECT_TEACHER_111 = "select * from " +
	" teacherinfotable where ( t_name like ? or "
		+ " t_name like ? or t_name like ? " +
				" or t_name like ? ) and ( t_duty like ? or "
		+ " t_duty like ? or t_duty like ?  or t_duty like ? )  and t_id = ? ";
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * ѧ��������Ϣsql���
	 * 
	 */
//	 ��ѯ����ѧ����Ϣ
	public static final String SELECT_STU_ALL="select * from " +
			" studentinfotable s order by s.s_id ";
	
//	 ȫ����ѯ��Ϣ ����
	public static final String SELECT_STU_ALL_COUNT="select count(*) from "
		+ "studentinfotable s order by s.s_id";
	
	// ����ѧ�Ų�ѯ
	public static final String SELECT_STU_BY_S_ID ="select * from " +
	" studentinfotable  s where  s.s_id = ? order by s.s_id";
	
//	 ����ѧ�Ų�ѯ�������
	public static final String SELECT_STU_BY_S_ID_COUNT ="select count(*) from "
		+ " studentinfotable  s  where  s.s_id = ? order by s.s_id";
	
	
	// ������Ų�ѯ
	public static final String SELECT_STU_BY_G_ID ="select * from " +
	" studentinfotable  s where  s.g_id = ? order by s.s_id";
	
//	 ������Ų�ѯ�������
	public static final String SELECT_STU_BY_G_ID_COUNT ="select count(*) from "
		+ " studentinfotable  s  where  s.g_id = ? order by s.s_id";
	
	// ����������ѯ
	public static final String SELECT_STU_BY_S_NAME = "select "
			+ " * from studentinfotable s "
			+ "where   s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? or s.s_name like ? order by s.s_id ";

	// ����������ѯ�������
	public static final String SELECT_STU_BY_S_NAME_COUNT = "select count(*) from " +
			" studentinfotable s where   s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? or s.s_name like ? order by s.s_id ";
	
	//ɾ����ѡѧ����Ϣ
	public static final String DELETE_STU_BY_S_ID ="delete from " +
	" studentinfotable  s where  s.s_id = ? ";
	
	//����ѧ����Ϣ
	public static final String INSERT_STU = "insert into studentinfotable(s_id,g_id,s_name,s_sex,s_grade,s_school,s_professional,s_tel,s_qq,s_email) "
		+ "values(?,?,?,?,?,?,?,?,?,?)";
	
	//����ѧ�������ӿ��Կγ���Ϣ
	public static final String INSERT_STU_EXAM = "insert into studentexamchivement(s_id,g_id,classnum) "
		+ "values(?,?,?)";
	
	
	//����ѧ�������ӿ��Կγ���Ϣ
	public static final String INSERT_STU_OR = "insert into studentordinarychivement(s_id,g_id) "
		+ "values(?,?)";
	
	
	//�޸�ѧ����Ϣ
	public static final String UPDATE_STU = "update studentinfotable set " +
			" g_id = ?,s_name=?,s_sex=?,s_grade=?,s_school=?,s_professional=?,s_tel=?,s_qq=?,s_email=?" +
			" where s_id=? ";
	
	
	
	/**
	 * ѧ��������Ϣ �߼���ѯ sql���
	 * 
	 */
	
	
	public static final String SELECT_STU_011 = "select * from " +
	" studentinfotable  s where s.g_id = ? and s.s_id=? order by s.s_id ";
	
		public static final String SELECT_STU_101 = "select * from " +
		" studentinfotable  s "
		+ " where ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ? ";
	
		public static final String SELECT_STU_110 = "select * from " +
	" studentinfotable  s where "
		+ " ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? ";
	
	
		public static final String SELECT_STU_111 = "select * from " +
	" studentinfotable  s where ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? and s.s_id = ? ";
	
	
	
	
	
	
	
	
	
	
	
/**
 * ѧ��ƽʱ�ɼ�����sql���
 * 
 */
	
//	 ��ѯ����ѧ���ɼ�
	public static final String SELECT_OR_ALL="select s.s_id,s.g_id,s.s_name,t.ordinary"
			+ " from studentordinarychivement t,studentinfotable s "
			+ " where  t.s_id=s.s_id order by t.s_id";
	
//	 ȫ����ѯ ����
	public static final String SELECT_OR_ALL_COUNT="select count(*) "
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id ";
	
	
	// ����ѧ�Ų�ѯ
	public static final String SELECT_OR_BY_S_ID ="select s.s_id,s.g_id,s.s_name,t.ordinary"
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id and s.s_id = ? order by t.s_id";
	
//	 ����ѧ�Ų�ѯ�������
	public static final String SELECT_OR_BY_S_ID_COUNT ="select count(*) "
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id and s.s_id = ? order by t.s_id";
	
	
	// ������Ų�ѯ
	public static final String SELECT_OR_BY_G_ID ="select s.s_id,s.g_id,s.s_name,t.ordinary"
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id and s.g_id = ? order by t.s_id";
	
//	 ������Ų�ѯ�������
	public static final String SELECT_OR_BY_G_ID_COUNT ="select count(*) "
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id and s.g_id = ? order by t.s_id";
	
	// ����������ѯ
	public static final String SELECT_OR_BY_S_NAME = "select "
			+ " s.s_id,s.g_id,s.s_name,t.ordinary from "
			+ " studentordinarychivement t,studentinfotable s "
			+ "where t.s_id=s.s_id and ( s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? or s.s_name like ? )";

	// ����������ѯ�������
	public static final String SELECT_OR_BY_S_NAME_COUNT = "select count(s.s_id)  from "
		+ " studentordinarychivement t,studentinfotable s "
		+ "where t.s_id=s.s_id and ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? or s.s_name like ? )";
	
	// �޸�ѡ��ѧ����ѡ�Ŀγ�
	public static final String UPDATE_OR_BY_STUID = " update studentordinarychivement set " +
			" ordinary = ? where s_id=? ";
	
	// ���ƽʱ�ɼ�ѧ��ѧ����������
	public static final String SELECT_OR_STU_SNO_SNAME_EXAM = "select s.s_id,s.s_name,t.ordinary"
		+ " from studentordinarychivement t,studentinfotable s "
		+ " where  t.s_id=s.s_id order by t.s_id";

	// ���ƽʱ�ɼ�ѧ��ѧ��������������
	public static final String SELECT_OR_STU_SNO_SNAME_EXAM_COUNT = "select "
			+ " count(*) from studentordinarychivement t,studentinfotable s "
			+ " where  t.s_id=s.s_id ";
	
	
	// �޸�ѧ��ƽʱ�ɼ�
	public static final String UPDATE_OR_BY_CLASS = "UPDATE "
			+ "studentordinarychivement set   ordinary= ? where s_id = ? ";
	
	
	
	
	
	
	
	/**
	 * ѧ��ƽʱ�ɼ����� �߼���ѯ��� 
	 * 
	 */
	
	
	
	
	
	public static final String SELECT_OR_011 = "select "
		+ " s.s_id,s.g_id,s.s_name,t.exam from "
		+ " studentordinarychivement t,studentinfotable s "
		+ "where  t.s_id=s.s_id and " +
				" s.g_id = ? and s.s_id=?";
	
		public static final String SELECT_OR_101 = "select "
		+ " s.s_id,s.g_id,s.s_name,t.exam from "
		+ " studentordinarychivement t,studentinfotable s "
		+ "where  t.s_id=s.s_id and ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ? ";
	
		public static final String SELECT_OR_110 = "select "
			+ " s.s_id,s.g_id,s.s_name,t.exam from "
			+ " studentordinarychivement t,studentinfotable s where "
		+ "t.s_id=s.s_id and  ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? ";
	
	
		public static final String SELECT_OR_111 = "select "
			+ " s.s_id,s.g_id,s.s_name,t.exam from "
			+ " studentordinarychivement t,studentinfotable s "
		+ "where t.s_id=s.s_id and  ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? and s.s_id = ? ";
	
	
	
	
	
	
	
/**
 * ѧ�����Գɼ�����sql���
 * 
 */
	// ��ѯ����ѧ���ɼ�
	public static final String SELECT_ALL = " select s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam "
			+ " from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id order by t.s_id";

	// ȫ����ѯ ����
	public static final String SELECT_ALL_COUNT = "select count(*) from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id ";

	// ����ѧ�Ų�ѯ
	public static final String SELECT_BY_S_ID = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and s.s_id = ? order by t.s_id";

	// ����ѧ�Ų�ѯ�������
	public static final String SELECT_BY_S_ID_COUNT = "select "
			+ " count(*)from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and s.s_id = ? ";

	// ������Ų�ѯ
	public static final String SELECT_BY_G_ID = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and s.G_id = ? order by t.s_id";

	// ������Ų�ѯ�������
	public static final String SELECT_BY_G_ID_COUNT = "select "
			+ " count(*)from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and s.G_id = ?  ";

	// ���ݿγ̺źŲ�ѯ
	public static final String SELECT_BY_C_ID = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and c.classnum = ? order by t.s_id";

	// ���ݿγ̺źŲ�ѯ�������
	public static final String SELECT_BY_C_ID_COUNT = "select "
			+ " count(*)from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and c.classnum = ?  ";

	// ����������ѯ
	public static final String SELECT_BY_S_NAME = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and ( s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? or s.s_name like ? )";

	// ����������ѯ�������
	public static final String SELECT_BY_S_NAME_COUNT = "select "
			+ " count(s.s_id) from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and ( s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? or s.s_name like ? ) ";

	// ���ݿγ����Ʋ�ѯ
	public static final String SELECT_BY_CLASS_NAME = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and ( c.classname like ? or "
			+ " c.classname like ? or c.classname like ? or c.classname like ? )";

	// ���ݿγ����ƻ������
	public static final String SELECT_BY_CLASS_COUNT = "select "
			+ " count(s.s_id) from studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and ( c.classname like ? or "
			+ " c.classname like ? or c.classname like ? or c.classname like ? ) ";

	// �޸�ѡ��ѧ����ѡ�Ŀγ�
	public static final String UPDATE_EXAM_BY_STUID = " update studentexamchivement set " +
			" exam = ? where s_id=? and classnum=? ";

	// ������пγ���
	public static final String SELECT_CLASS_NAME = " select classnum,CLASSNAME from classtable  ";

	// ������пγ�������
	public static final String SELECT_CLASS_NAME_COUNT = " select count(*) from classtable  ";

	// �����ѧ��Ŀѧ��ѧ����������
	public static final String SELECT_CLASS_STU_SNO_SNAME_EXAM = "select "
			+ " s.s_id,s.s_name,t.exam from  "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and c.classnum = ? "
			+ " order by s.s_id";

	// �����ѧ��Ŀѧ��ѧ��������������
	public static final String SELECT_CLASS_STU_SNO_SNAME_EXAM_COUNT = "select "
			+ " count(s.s_id) from  "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ " where t.classnum=c.classnum and t.s_id=s.s_id and c.classnum = ? "
			+ " order by s.s_id";

	// ���ݿ�Ŀ�޸�ѧ���ɼ�
	public static final String UPDATE_CHIVEMENT_BY_CLASS = "UPDATE "
			+ "studentexamchivement set   exam= ? where s_id = ? and classnum=? ";
	
	
	
	
	
	
	
	
	/**
	 * ѧ�����Գɼ����� �߼���ѯ��� 
	 * 
	 */
	public static final String SELECT_00011 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id " +
				" and s.s_id=?  and c.classnum = ? ";
	
	public static final String SELECT_00101 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id " +
				" and s.g_id=?  and c.classnum = ? ";
	
	public static final String SELECT_00110 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" s.g_id = ? and s.s_id=?";
	
		public static final String SELECT_00111 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  s.g_id = ? and s.s_id=? and c.classnum = ? ";
	
		public static final String SELECT_01001 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					" ( s.s_name like ? or "
			+ " s.s_name like ? or s.s_name like ? " +
					" or s.s_name like ? ) and c.classnum = ? ";
	
		public static final String SELECT_01010 =  "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ? ";
	
		public static final String SELECT_01011 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ? and c.classnum = ? ";
	
		public static final String SELECT_01100 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? ";
	
		public static final String SELECT_01101 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? and c.classnum = ? ";
	
		public static final String SELECT_01110 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? and s.s_id = ? ";
	
		public static final String SELECT_01111 = "select "
		+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
		+ " studentexamchivement t,classtable c,studentinfotable s "
		+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
				" ( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? and s.s_id = ? " +
				" and c.classnum = ? ";
	
	
		public static final String SELECT_10001 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  ( c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and c.classnum = ? ";
	
		public static final String SELECT_10010 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					" ( c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.s_id = ? ";
	
		public static final String SELECT_10011 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					" ( c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.s_id = ? " +
					"and c.classnum = ? ";
	
	
		public static final String SELECT_10100 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  ( c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.g_id = ? ";
	
		public static final String SELECT_10101 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.g_id = ? " +
					" and c.classnum = ?  ";
	
		public static final String SELECT_10110 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.g_id = ? " +
					" and s.s_id = ? = ?  ";
	
	
		public static final String SELECT_10111 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					" ( c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and s.g_id = ? " +
					"  and s.s_id = ?  and c.classnum = ?   ";
	
	
	
		public static final String SELECT_11000 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? )";
	
		public static final String SELECT_11001 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and c.classnum = ?  ";
	
		public static final String SELECT_11010 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ?  ";
	
		public static final String SELECT_11011 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.s_id = ?  and c.classnum = ? ";
	
	
	
		public static final String SELECT_11100 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ? ";
	
		public static final String SELECT_11101 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ?  and c.classnum = ? ";
	
		public static final String SELECT_11110 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ?  and s.s_id = ? ";
	
		public static final String SELECT_11111 = "select "
			+ " s.s_id,s.g_id,s.s_name,c.classnum,c.classname,t.exam from "
			+ " studentexamchivement t,classtable c,studentinfotable s "
			+ "where t.classnum=c.classnum and t.s_id=s.s_id and " +
					"  (c.classname like ? or "
			+ " c.classname like ? or c.classname " +
					" like  ? or c.classname like ? ) and " +
					"( s.s_name like ? or "
		+ " s.s_name like ? or s.s_name like ? " +
				" or s.s_name like ? ) and s.g_id = ?  and s.s_id = ? " +
				"and c.classnum = ? ";
}
