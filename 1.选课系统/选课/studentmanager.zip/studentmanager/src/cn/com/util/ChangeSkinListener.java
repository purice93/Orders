package cn.com.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.BusinessSkin;
import org.jvnet.substance.skin.FieldOfWheatSkin;
import org.jvnet.substance.skin.MistAquaSkin;
import org.jvnet.substance.skin.OfficeBlue2007Skin;

public class ChangeSkinListener implements ActionListener
{

    public void actionPerformed(ActionEvent e)
    {
        String skin = e.getActionCommand();
        if (skin == "��ɫ����")
        {
            SubstanceLookAndFeel.setSkin(new OfficeBlue2007Skin());
        } else if (skin == "������")
        {
            SubstanceLookAndFeel.setSkin(new FieldOfWheatSkin());
        } else if (skin == "Ĭ��Ƥ��")
        {
            SubstanceLookAndFeel.setSkin(new BusinessSkin());
        } else if (skin == "���ʷ��")
        {
            SubstanceLookAndFeel.setSkin(new MistAquaSkin());
        }
    }

}
