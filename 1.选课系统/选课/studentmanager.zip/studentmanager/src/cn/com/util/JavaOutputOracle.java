package cn.com.util;

import java.io.IOException;

public class JavaOutputOracle {
	public JavaOutputOracle(){
		Runtime rt = Runtime.getRuntime();
		Process processexp = null;
		String exp = "exp  scott/tiger@oracle  file=d:\\tanjindmq.dmp";
		try {
			processexp = rt.exec(exp);
//			javax.swing.JOptionPane.showMessageDialog(null, "���ݿⱸ�ݳɹ�");
//			if (processexp.waitFor() != 0) {
//				javax.swing.JOptionPane.showMessageDialog(null, "���ݿⱸ��ʧ��");
//			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

//	public static void main(String[] args) {
//
//	}

}
