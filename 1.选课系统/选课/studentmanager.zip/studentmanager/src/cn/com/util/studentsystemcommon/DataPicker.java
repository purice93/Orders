package cn.com.util.studentsystemcommon;

import javax.swing.JComboBox;

public class DataPicker {
  private JDatePicker data = null;

  public JComboBox getDataPacker() {
    return data = new JDatePicker();
  }

}
