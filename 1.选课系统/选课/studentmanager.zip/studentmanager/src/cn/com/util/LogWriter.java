package cn.com.util;

import java.io.PrintWriter;
import java.util.Date;

public class LogWriter {

   private PrintWriter pw;
   
   private String ownName;

   public LogWriter(PrintWriter pw, String ownName) {
      super();
      this.pw = pw;
      this.ownName = ownName;
   }
   
   public void Log(String msg){
      if (pw != null){
         pw.println("[" + new Date() + "]  " +  ": " + ownName + ": " + msg);
      }
   }
   
}
