package cn.com.util;

import javax.swing.JTable;
import javax.swing.table.TableModel;

public class MyTable extends JTable {
	public MyTable() {
		super();
	}
	public MyTable(TableModel dm){
		super(dm);
	} 

	public MyTable(Object[][] data, Object[] head) {
		super(data, head);
	}

	public boolean isCellEditable(int row, int column) {

		return false;

	}
}
