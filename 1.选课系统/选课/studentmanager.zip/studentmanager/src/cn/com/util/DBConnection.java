package cn.com.util;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnection {
	static Connection conn = null;
	/**
	 * �������ݿ�����������ݿ�
	 * @return
	 */
	public static Connection getConnectionOracle(){
		Properties properties = getProperties();
		String driver = properties.getProperty("driver");
		String url = properties.getProperty("url");
		String user = properties.getProperty("user");
		String pwd = properties.getProperty("pwd");
	try {
		Class.forName(driver);
		conn = DriverManager.getConnection(url,user,pwd);
		System.out.println("���ӳɹ�");
	} catch(Exception e){
		System.out.println("���ݿ������쳣��"+e.getMessage());
	}
	return conn;
	
	}	
	/**
	 * ��connectionoracle�ļ��ж�ȡ��Ϣ
	 * @return
	 */
	public static Properties getProperties(){
		Properties properties = null;
		try{
			properties = new Properties();
			properties.load(new FileInputStream(new File("db.properties")));
		}catch(Exception e){
			System.out.println("�ļ���Ϣ��ȡ�쳣��"+e.getMessage());
		}
		return properties;
		
	}
}