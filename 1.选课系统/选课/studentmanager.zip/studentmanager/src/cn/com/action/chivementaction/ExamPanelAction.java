package cn.com.action.chivementaction;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import cn.com.dao.chivementdao.ExamDao;
import cn.com.dialog.chivementdialog.ExamHighSelectDialog;
import cn.com.dialog.chivementdialog.ExamUpdateClassChivementDialog;
import cn.com.dialog.chivementdialog.ExamUpdateStuDialog;
import cn.com.panel.chivementpanel.ExamPanel;
import cn.com.studentsystem.excel.ExamExcelFrame;
import cn.com.studentsystem.excel.ExamPutOutExcel;
import cn.com.util.LogWriter;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamPanelAction implements ActionListener {

	private ChivementVo examVo;

	private ExamPanel chivementPanel;

	private String[] column = { "ѧ��", "���", "ѧ������", "�γ̱��", "�γ�����", "�γ̳ɼ�" };

	private LogWriter logWriter;

	public ExamPanelAction(ExamPanel chivementPanel, LogWriter logWriter) {
		super();
		this.chivementPanel = chivementPanel;
		this.logWriter = logWriter;
	}

	public void actionPerformed(ActionEvent e) {

		String str = e.getActionCommand();
		ExamDao examdao = null;
		if (str.equals("��ѯ")) {
			String str1 = chivementPanel.getSelect();
			if (str1.equals("��ѯȫ��ѧ���ɼ�")) {
				logWriter.Log("��ѯ��ȫ��ѧ���ĳɼ�");
				examdao = new ExamDao(examVo);
				Object[][] s2 = examdao.selectAll();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				if(s2.length==0){
					javax.swing.JOptionPane
					.showMessageDialog(null, "û�������������");
				}
			} else if (str1.equals("����ѧ�Ų�ѯѧ�����Գɼ�")) {
				examVo = new ChivementVo();
				if (chivementPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						examVo.setS_id(Integer.parseInt(chivementPanel
								.getInput()));
						examdao = new ExamDao(examVo);
						Object[][] s2 = examdao.selectBySid();
						chivementPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if(s2.length==0){
							javax.swing.JOptionPane
							.showMessageDialog(null, "û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("������Ų�ѯѧ�����Գɼ�")) {
				if (chivementPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						examVo = new ChivementVo();
						examVo.setG_id(Integer.parseInt(chivementPanel
								.getInput()));
						examdao = new ExamDao(examVo);
						Object[][] s2 = examdao.selectByGid();
						chivementPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if(s2.length==0){
							javax.swing.JOptionPane
							.showMessageDialog(null, "û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("���ݿγ̱�Ų�ѯѧ���ɼ�")) {
				if (chivementPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						examVo = new ChivementVo();
						examVo.setC_id(Integer.parseInt(chivementPanel
								.getInput()));
						examdao = new ExamDao(examVo);
						Object[][] s2 = examdao.selectByCid();
						chivementPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if(s2.length==0){
							javax.swing.JOptionPane
							.showMessageDialog(null, "û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("����������ѯѧ�����Գɼ�")) {
				if (chivementPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					examVo = new ChivementVo();
					examVo.setS_name(chivementPanel.getInput());
					examdao = new ExamDao(examVo);
					Object[][] s2 = examdao.selectByName();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					if(s2.length==0){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				}
			} else if (str1.equals("���ݿγ����Ʋ�ѯѧ���ɼ�")) {
				if (chivementPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					examVo = new ChivementVo();
					examVo.setClass_name(chivementPanel.getInput());
					examdao = new ExamDao(examVo);
					Object[][] s2 = examdao.selectByClassName();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					if(s2.length==0){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				}
			}

		} else if (str.equals("�߼���ѯ")) {
			ExamHighSelectDialog dialog = new ExamHighSelectDialog(
					chivementPanel);
			dialog.CreatHighSelectDialog().setVisible(true);
		} else if (str.equals("ˢ��")) {
			examdao = new ExamDao(examVo);
			Object[][] s2 = examdao.selectAll();
			chivementPanel.creatJTable().setModel(
					new DefaultTableModel(s2, column));
		} else if (str.equals("�޸�ѡ��ѧ���ɼ�")) {
			if (chivementPanel.creatJTable().getSelectedRow() >= 0) {
				examVo = new ChivementVo();
				int i = chivementPanel.getChevementJtable().getSelectedRow();

				int stuid = Integer.parseInt(chivementPanel
						.getChevementJtable().getValueAt(i, 0).toString());

				String stuname = chivementPanel.getChevementJtable()
						.getValueAt(i, 2).toString();

				int classid = Integer.parseInt(chivementPanel
						.getChevementJtable().getValueAt(i, 3).toString());

				String className = chivementPanel.getChevementJtable()
						.getValueAt(i, 4).toString();

				int exam = Integer.parseInt(chivementPanel.getChevementJtable()
						.getValueAt(i, 5).toString());

				examVo.setS_id(stuid);
				examVo.setS_name(stuname);
				examVo.setC_id(classid);
				examVo.setClass_name(className);
				examVo.setClassExamChivement(exam);
				// examdao = new ExamDao(examVo);
				ExamUpdateStuDialog dialog = new ExamUpdateStuDialog(examVo);
				dialog.creatUpdateStuDialog().setVisible(true);
				// Vector vo = examdao.getSelectClass();
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}

		} else if (str.equals("�޸Ŀ�Ŀ�ɼ�")) {
			ExamUpdateClassChivementDialog dialog = new ExamUpdateClassChivementDialog();
			dialog.creatUpdateClassDialog().setVisible(true);

		} else if (str.equals("��ӡ")) {
			if (chivementPanel.getChevementJtable() != null) {
				try {
					chivementPanel.creatJTable().print(null, null, null, true,
							null, false);
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (PrinterException e1) {
					e1.printStackTrace();
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "���ȵõ�����");
			}
		}else if(str.equals("����")){
			ExamExcelFrame excel_frame = new ExamExcelFrame();
//			String filename = "f:\\exam.xls";
//			int row_count = ExamPanel.chevementJtable.getRowCount();
//			Vector vector = new Vector();
//			for(int i=0;i<row_count;i++){
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 0));
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 1));
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 2));
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 3));
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 4));
//				vector.add(ExamPanel.chevementJtable.getValueAt(i, 5));
//			}
//			WritableWorkbook workbook = ExamPutOutExcel.buildWorkBook(filename);
//			WritableSheet sheet = ExamPutOutExcel.setExcel(workbook, row_count,vector);
//			JOptionPane.showMessageDialog(null, "��Ϣ���ѵ���,�����"+filename);
		}
	}

}
