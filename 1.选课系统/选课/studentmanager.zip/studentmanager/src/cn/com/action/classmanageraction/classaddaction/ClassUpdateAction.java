package cn.com.action.classmanageraction.classaddaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalate;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassUpdate;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassUpdateAction implements ActionListener {
	ClassUpdate update;

	JTable table = ClassIntercalate.buildJTable();

	public ClassUpdateAction(ClassUpdate update) {
		this.update = update;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String str = e.getActionCommand();
		Impl impl;
		if (str.equals("�޸�")) {
			ClassVO vo, showvo;
			DefaultTableModel model = (DefaultTableModel) table.getModel();
			int selectedRow = table.getSelectedRow();
			Object id = model.getValueAt(selectedRow, 0);
			String s = id.toString();
			int a = Integer.parseInt(s);
			impl = new Impl();
			if (!update.classID.getText().equals("")
					&& !update.classname.getText().equals("")
					&& !update.credithour.getText().equals("")
					&& !update.totaltime.getText().equals("")) {
				if(ClassUpdate.c4.getSelectedItem().toString().equals("      ")){
					JOptionPane.showMessageDialog(null, "û�и���ʦ��������ѡ��!");
				}else {
				int a1 = Integer.parseInt(update.c1.getSelectedItem()
						.toString());// ��ÿ��ε��ܴ�
				int a2 = Integer.parseInt(update.c2.getSelectedItem()
						.toString());// ��ý����γ̵��ܴ�
				if (a1 <= a2) {
					vo = update.getInputInfo();

					if (impl.updateClass(vo)) {
						JOptionPane.showMessageDialog(null, "�γ��޸ĳɹ�", "�γ��޸�!",
								JOptionPane.YES_OPTION);
						try {
							showvo = ClassIntercalate.getInputInfo(impl
									.classinfo(a));
							Object[] data = { new Integer(showvo.getClassID()),
									showvo.getClassname(),
									showvo.getTotaltime(),
									showvo.getClasstime(),
									showvo.getCredithour(),
									showvo.getClassestate(),
									showvo.getTeacherID(),
									showvo.getTeachername(),
									showvo.getTeacherduty(),
									showvo.getClassremark() };
							int columns = table.getColumnCount();
							for (int i = 0; i < columns; i++) {
								table.setValueAt(data[i], selectedRow, i);
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						update.dialog.dispose();
					}
				} else {
					JOptionPane.showMessageDialog(null, "����ʱ�䲻�ܱȽ���ʱ��٣�");
				}
				}
			} else {
				JOptionPane.showMessageDialog(null, "�γ̱�š��γ�������ʱ��ѧ�֡���ʦ��Ų���Ϊ�գ�");
			}
		} else if (str.equals("�˳�")) {
			update.dialog.dispose();
		}
	}
}
