package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cn.com.dao.chivementdao.ExamDao;
import cn.com.dialog.chivementdialog.ExamUpdateClassChivementDialog;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamUpdateClassChivementAction implements ActionListener {
   private ChivementVo examVo;

   private ExamUpdateClassChivementDialog dialog;

   public ExamUpdateClassChivementAction(ExamUpdateClassChivementDialog dialog) {
      this.dialog = dialog;
   }

   public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		ExamDao examdao = null;
		if (str.equals("�ύ")) {
			String className = dialog.getSelectClass().getSelectedItem()
					.toString();
			String[] snoname = new String[4];
			snoname = className.split(" ");
			int classno = Integer.parseInt(snoname[1]);
			if (classno != 0) {
				examVo = new ChivementVo();
				examVo.setC_id(Integer.parseInt(snoname[1]));
				examdao = new ExamDao(examVo);
				examdao.SelectClassStuName();
				int[] sNum = examVo.getSid();
                if(sNum.length>0){
				String[] sName = examVo.getSname();
				int[] classExam = examVo.getClassExam();
				ExamUpdateClassChivementDialog dialog1 = new ExamUpdateClassChivementDialog(
						Integer.parseInt(snoname[1]), snoname[3], sNum, sName,
						classExam);
				dialog1.creatUpdateClass1Dialog().setVisible(true);
				dialog.getUpdateClass().dispose();
                }else{
                   javax.swing.JOptionPane.showMessageDialog(null,
                    "û��ѧ��ѡ����ſγ̣�");
                }
			} else {
				javax.swing.JOptionPane.showMessageDialog(null,
						"�ÿγ�Ϊȱʡ�γ̣������޸ģ�");
			}
		}
	}
}
