package cn.com.action.studentmanageraction;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import cn.com.dao.studentmanagerdao.StudentDao;
import cn.com.dialog.studentmanagerdialog.StudentAdd;
import cn.com.dialog.studentmanagerdialog.StudentHighSelectDialog;
import cn.com.dialog.studentmanagerdialog.StudentUpdateDialog;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.studentsystem.excel.StudentExcelFrame;
import cn.com.studentsystem.excel.StudentPutOutExcel;
import cn.com.util.LogWriter;
import cn.com.vo.studentmanagervo.StudentVo;

public class StudentPanelAction implements ActionListener {

	private StudentVo studentVo;

	private StudentPanel studentPanel;

	private String[] column = { "ѧ��", "���", "����", "�Ա�", "�꼶", "ѧУ", "רҵ",
			"��ϵ����", "QQ", "�����ʼ�" };

	private LogWriter logWriter;

	public StudentPanelAction(StudentPanel studentPanel, LogWriter logWriter) {
		super();
		this.studentPanel = studentPanel;
		this.logWriter = logWriter;
	}

	public void actionPerformed(ActionEvent e) {

		String str = e.getActionCommand();
		StudentDao studentdao = null;
		if (str.equals("��ѯ")) {
			String str1 = studentPanel.getSelect();
			if (str1.equals("��ѯȫ��ѧ����Ϣ")) {
				logWriter.Log("��ѯ��ȫ��ѧ���ĳɼ�");
				studentdao = new StudentDao();
				Object[][] s2 = studentdao.selectAll();
				studentPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
			} else if (str1.equals("����ѧ�Ų�ѯѧ����Ϣ")) {
				if (studentPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						studentVo = new StudentVo();
						studentVo.setS_id(Integer.parseInt(studentPanel
								.getInput()));
						studentdao = new StudentDao(studentVo);
						Object[][] s2 = studentdao.selectBySid();
						studentPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if (s2.length == 0) {
							javax.swing.JOptionPane.showMessageDialog(null,
									"û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("������Ų�ѯѧ����Ϣ")) {
				if (studentPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						studentVo = new StudentVo();
						studentVo.setG_id(Integer.parseInt(studentPanel
								.getInput()));
						studentdao = new StudentDao(studentVo);
						Object[][] s2 = studentdao.selectByGid();
						studentPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if (s2.length == 0) {
							javax.swing.JOptionPane.showMessageDialog(null,
									"û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("����������ѯѧ����Ϣ")) {
				if (studentPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					studentVo = new StudentVo();
					studentVo.setS_name(studentPanel.getInput());
					studentdao = new StudentDao(studentVo);
					Object[][] s2 = studentdao.selectByName();
					studentPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					if (s2.length == 0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				}
			}
		} else if (str.equals("�߼���ѯ")) {
			StudentHighSelectDialog dialog = new StudentHighSelectDialog(
					studentPanel);
			dialog.CreatHighSelectDialog().setVisible(true);
		} else if (str.equals("ˢ��")) {
			studentdao = new StudentDao(studentVo);
			Object[][] s2 = studentdao.selectAll();
			studentPanel.creatJTable().setModel(
					new DefaultTableModel(s2, column));
		} else if (str.equals("������Ϣ")) {
			StudentAdd dialog = new StudentAdd();
			JDialog dialog1 = dialog.addstudent();
			dialog1.setModal(true);
		} else if (str.equals("ɾ����Ϣ")) {
			if (studentPanel.creatJTable().getSelectedRow() >= 0) {
				studentVo = new StudentVo();
				int i = studentPanel.getChevementJtable().getSelectedRow();
				int stuid = Integer.parseInt(studentPanel.getChevementJtable()
						.getValueAt(i, 0).toString());
				studentVo.setS_id(stuid);
				int choice = javax.swing.JOptionPane.showConfirmDialog(null,
						"ȷ��ɾ����", "ɾ��ȷ��", JOptionPane.YES_NO_OPTION);
				if (choice == JOptionPane.YES_OPTION) {
					studentdao = new StudentDao(studentVo);
					studentdao.deletestudentinfo();
					javax.swing.JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
					Object[][] s2 = studentdao.selectAll();
					studentPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
				} else {
					javax.swing.JOptionPane.showMessageDialog(null, "ɾ��ȡ����");
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}
		} else if (str.equals("�޸���Ϣ")) {
			if (studentPanel.creatJTable().getSelectedRow() >= 0) {
				try {
				int i = studentPanel.creatJTable().getSelectedRow();
				studentVo = new StudentVo();
				studentVo.setS_id(Integer.parseInt(studentPanel.creatJTable().getValueAt(i, 0).toString()));
				studentVo.setG_id(Integer.parseInt(studentPanel.creatJTable().getValueAt(i, 1).toString()));
				studentVo.setS_name(studentPanel.creatJTable().getValueAt(i, 2).toString());
				studentVo.setS_sex(studentPanel.creatJTable().getValueAt(i, 3).toString());
				studentVo.setS_grade(studentPanel.creatJTable().getValueAt(i, 4).toString());
				studentVo.setS_school(studentPanel.creatJTable().getValueAt(i, 5).toString());
				studentVo.setS_professional(studentPanel.creatJTable().getValueAt(i, 6).toString());
				studentVo.setS_tel(Long.parseLong(studentPanel.creatJTable().getValueAt(i, 7).toString()));
				studentVo.setS_qq(Long.parseLong(studentPanel.creatJTable().getValueAt(i, 8).toString()));
				studentVo.setS_emali(studentPanel.creatJTable().getValueAt(i, 9).toString());
				StudentUpdateDialog dialog = new StudentUpdateDialog(studentVo);
				JDialog dialog1 = dialog.updatestudent();
				dialog1.setModal(true);
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}
		}

		else if (str.equals("��ӡ")) {
			if (studentPanel.getChevementJtable() != null) {
				try {
					studentPanel.creatJTable().print(null, null, null, true,
							null, false);
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (PrinterException e1) {
					e1.printStackTrace();
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "���ȵõ�����");
			}
		}
		else if(str.equals("����")){
			StudentExcelFrame sef = new StudentExcelFrame();

		}
	}

}
