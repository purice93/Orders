package cn.com.action.studentmanageraction;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.Vector;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import cn.com.dao.studentmanagerdao.TeacherDao;
import cn.com.dialog.studentmanagerdialog.TeacherAdd;
import cn.com.dialog.studentmanagerdialog.TeacherHighSelectDialog;
import cn.com.dialog.studentmanagerdialog.TeacherUpdateDialog;
import cn.com.panel.studentmanagerpanel.TeacherPanel;
import cn.com.studentsystem.excel.TeacherExcelFrame;
import cn.com.studentsystem.excel.TeacherPutOutExcel;
import cn.com.util.LogWriter;
import cn.com.vo.studentmanagervo.TeacherVo;

public class TeacherPanelAction implements ActionListener {

	private TeacherVo teacherVo;

	private TeacherPanel teacherPanel;

	private String[] column = { "��ʦID", "��ʦ����", "��ʦ�Ա�", "��ʦ����", "��ʦְ��", "��ʦQQ",
			"��ʦemail", "��ʦ�绰" };

	private LogWriter logWriter;

	public TeacherPanelAction(TeacherPanel teacherPanel, LogWriter logWriter) {
		super();
		this.teacherPanel = teacherPanel;
		this.logWriter = logWriter;
	}

	public void actionPerformed(ActionEvent e) {

		String str = e.getActionCommand();
		TeacherDao teacherdao = null;
		if (str.equals("��ѯ")) {
			String str1 = teacherPanel.getSelect();
			if (str1.equals("��ѯȫ����ʦ��Ϣ")) {
				logWriter.Log("��ѯ��ȫ����ʦ�ĳɼ�");
				teacherdao = new TeacherDao();
				Object[][] s2 = teacherdao.selectAll();
				teacherPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
			} else if (str1.equals("���ݽ�ʦ��Ų�ѯ��ʦ��Ϣ")) {
				if (teacherPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						teacherVo = new TeacherVo();
						teacherVo.setT_id(Integer.parseInt(teacherPanel
								.getInput()));
						teacherdao = new TeacherDao(teacherVo);
						Object[][] s2 = teacherdao.selectBySid();
						teacherPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if (s2.length == 0) {
							javax.swing.JOptionPane.showMessageDialog(null,
									"û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("���ݽ�ʦְ���ѯ��ʦ��Ϣ")) {
				if (teacherPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					teacherVo = new TeacherVo();
					teacherVo.setT_duty(teacherPanel.getInput());
					teacherdao = new TeacherDao(teacherVo);
					Object[][] s2 = teacherdao.selectByDuty();
					teacherPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					if (s2.length == 0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				}
			} else if (str1.equals("����������ѯ��ʦ��Ϣ")) {
				if (teacherPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
				}
				teacherVo = new TeacherVo();
				teacherVo.setT_name(teacherPanel.getInput());
				teacherdao = new TeacherDao(teacherVo);
				Object[][] s2 = teacherdao.selectByName();
				teacherPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				if (s2.length == 0) {
					javax.swing.JOptionPane.showMessageDialog(null, "û�������������");
				}
			}
		} else if (str.equals("�߼���ѯ")) {
			TeacherHighSelectDialog dialog = new TeacherHighSelectDialog(
					teacherPanel);
			dialog.CreatHighSelectDialog().setVisible(true);
		} else if (str.equals("ɾ����Ϣ")) {
			if (teacherPanel.creatJTable().getSelectedRow() >= 0) {
				teacherVo = new TeacherVo();
				int i = teacherPanel.getChevementJtable().getSelectedRow();
				int teacherid = Integer.parseInt(teacherPanel
						.getChevementJtable().getValueAt(i, 0).toString());
				if (teacherid != 0) {
					teacherVo.setT_id(teacherid);
					int choice = javax.swing.JOptionPane.showConfirmDialog(
							null, "ȷ��ɾ����", "ɾ��ȷ��", JOptionPane.YES_NO_OPTION);
					if (choice == JOptionPane.YES_OPTION) {
						teacherdao = new TeacherDao(teacherVo);
						teacherdao.deletestudentinfo();
						javax.swing.JOptionPane
								.showMessageDialog(null, "ɾ���ɹ���");
						Object[][] s2 = teacherdao.selectAll();
						teacherPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
					} else {
						javax.swing.JOptionPane
								.showMessageDialog(null, "ɾ��ȡ����");
					}
				} else {
					javax.swing.JOptionPane.showMessageDialog(null,
							"����ʦΪȱʡ��ʦ������ɾ����");
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}
		} else if (str.equals("ˢ��")) {
			teacherdao = new TeacherDao(teacherVo);
			Object[][] s2 = teacherdao.selectAll();
			teacherPanel.creatJTable().setModel(
					new DefaultTableModel(s2, column));
		} else if (str.equals("������Ϣ")) {
			TeacherAdd dialog = new TeacherAdd();
			JDialog dialog1 = dialog.init();
			dialog1.setModal(true);
		}

		else if (str.equals("�޸���Ϣ")) {
			if (teacherPanel.creatJTable().getSelectedRow() >= 0) {
				teacherVo = new TeacherVo();
				int i = teacherPanel.getChevementJtable().getSelectedRow();

				int teacherid = Integer.parseInt(teacherPanel
						.getChevementJtable().getValueAt(i, 0).toString());
				if (teacherid != 0) {
					String teachername = teacherPanel.getChevementJtable()
							.getValueAt(i, 1).toString();

					String sex = teacherPanel.getChevementJtable().getValueAt(
							i, 2).toString();

					int age = Integer.parseInt(teacherPanel
							.getChevementJtable().getValueAt(i, 3).toString());

					String duty = teacherPanel.getChevementJtable().getValueAt(
							i, 4).toString();

					Long tel = Long.parseLong(teacherPanel
							.getChevementJtable().getValueAt(i, 7).toString());
					// /////////////////////////////////////////////
					Long qq = Long.parseLong(teacherPanel.getChevementJtable()
							.getValueAt(i, 5).toString());

					String email = teacherPanel.getChevementJtable()
							.getValueAt(i, 6).toString();
					// /////////////////////////////////////////
					TeacherVo teacherVo = new TeacherVo();
					teacherVo.setT_id(teacherid);
					teacherVo.setT_name(teachername);
					teacherVo.setT_sex(sex);
					teacherVo.setT_age(age);
					teacherVo.setT_duty(duty);
					teacherVo.setT_tel(tel);
					teacherVo.setT_qq(qq);
					teacherVo.setT_email(email);
					TeacherUpdateDialog dialog = new TeacherUpdateDialog(
							teacherVo);
					JDialog dialog1 = dialog.init();
					dialog1.setModal(true);

				} else {
					javax.swing.JOptionPane.showMessageDialog(null,
							"����ʦΪȱʡ��ʦ�������޸ģ�");
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}
		} else if (str.equals("��ӡ")) {
			if (teacherPanel.getChevementJtable() != null) {
				try {
					teacherPanel.creatJTable().print(null, null, null, true,
							null, false);
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (PrinterException e1) {
					e1.printStackTrace();
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "���ȵõ�����");
			}
		} else if (str.equals("����")) {
			TeacherExcelFrame tef = new TeacherExcelFrame();


		}
	}
}
