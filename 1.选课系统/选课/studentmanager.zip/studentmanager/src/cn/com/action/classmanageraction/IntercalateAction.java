package cn.com.action.classmanageraction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalate;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalateAdd;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassUpdate;
import cn.com.dialog.classmanagerdialog.classintercalate.MessageAwake;

public class IntercalateAction implements ActionListener {
	ClassIntercalate intercalate;

	ClassUpdate update;

	ClassIntercalateAdd add;

	MessageAwake awake;

	Impl impl;

	JTable table = ClassIntercalate.buildJTable();

	public IntercalateAction(MessageAwake awake) {
		this.awake = awake;
	}

	public IntercalateAction(ClassIntercalateAdd add) {
		this.add = add;
	}

	public IntercalateAction(ClassUpdate update) {
		this.update = update;
	}

	public IntercalateAction(ClassIntercalate intercalate) {
		this.intercalate = intercalate;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("���ӿγ�")) {
			add = new ClassIntercalateAdd();
			add.buildDialog("���ӿγ�");
		} else if (str.equals("�޸Ŀγ�")) {
			int row = table.getSelectedRow();
			if (row == -1) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ҫ�޸ĵ���");
			}else {
			if (Integer.parseInt(table.getValueAt(row, 0).toString()) != 0) {
				update = new ClassUpdate();
				update.buildDialog("�޸Ŀγ�");
			} else {
				JOptionPane.showMessageDialog(null, "�ÿγ�Ϊȱʡ�γ̣������޸ģ�");
			}
			}
		} else if (str.equals("ɾ���γ�")) {
			int row = table.getSelectedRow();
			if (row == -1) {
				JOptionPane.showMessageDialog(null, "��ѡ����Ҫɾ������");
			} else {
				awake = new MessageAwake();
			}
		} else if (str.equals("��")) {

			DefaultTableModel model = (DefaultTableModel) table.getModel();
			impl = new Impl();
			int row = table.getSelectedRow();
			int classNo = Integer.parseInt(table.getValueAt(row, 0).toString());
			if(classNo != 0){
			if (impl.classDelete(classNo)) {
				JOptionPane.showMessageDialog(null, "�γ�ɾ���ɹ���");
				model.removeRow(row);
				awake.dispose();
			}
			awake.dispose();
			}else{
				JOptionPane.showMessageDialog(null, "�˿γ�Ϊȱʡֵ������ɾ��");
			}
		} else if (str.equals("��")) {
			awake.dispose();
		} 
	}

}

