package cn.com.action.chivementaction;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.chivementdao.OrdinaryDao;
import cn.com.dialog.chivementdialog.OrdinaryHighSelectDialog;
import cn.com.dialog.chivementdialog.OrdinaryUpdateClassChivementDialog;
import cn.com.dialog.chivementdialog.OrdinaryUpdateStuDialog;
import cn.com.panel.chivementpanel.OrdinaryPanel;
import cn.com.studentsystem.excel.OrdinaryExcelFrame;
import cn.com.util.LogWriter;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryPanelAction implements ActionListener {

	private ChivementVo examVo;

	private OrdinaryPanel ordinaryPanel;

	private String[] column = { "ѧ��", "���", "ѧ������", "ƽʱ�ɼ�" };

	private LogWriter logWriter;

	public OrdinaryPanelAction(OrdinaryPanel chivementPanel, LogWriter logWriter) {
		super();
		this.ordinaryPanel = chivementPanel;
		this.logWriter = logWriter;
	}

	public void actionPerformed(ActionEvent e) {

		String str = e.getActionCommand();
		OrdinaryDao ordinarydao = null;
		if (str.equals("��ѯ")) {
			String str1 = ordinaryPanel.getSelect();
			if (str1.equals("��ѯȫ��ѧ���ɼ�")) {
				logWriter.Log("��ѯ��ȫ��ѧ���ĳɼ�");
				ordinarydao = new OrdinaryDao();
				Object[][] s2 = ordinarydao.selectAll();
				ordinaryPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
			} else if (str1.equals("����ѧ�Ų�ѯѧ��ƽʱ�ɼ�")) {
				if (ordinaryPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {
						examVo = new ChivementVo();
						examVo.setS_id(Integer.parseInt(ordinaryPanel
								.getInput()));
						ordinarydao = new OrdinaryDao(examVo);
						Object[][] s2 = ordinarydao.selectBySid();
						ordinaryPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if (s2.length == 0) {
							javax.swing.JOptionPane.showMessageDialog(null,
									"û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("������Ų�ѯѧ��ƽʱ�ɼ�")) {
				if (ordinaryPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
					try {

						examVo = new ChivementVo();
						examVo.setG_id(Integer.parseInt(ordinaryPanel
								.getInput()));
						ordinarydao = new OrdinaryDao(examVo);
						Object[][] s2 = ordinarydao.selectByGid();
						ordinaryPanel.creatJTable().setModel(
								new DefaultTableModel(s2, column));
						if (s2.length == 0) {
							javax.swing.JOptionPane.showMessageDialog(null,
									"û�������������");
						}
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"��������ȷ���ַ���ʽ��");
					}
				}
			} else if (str1.equals("����������ѯѧ��ƽʱ�ɼ�")) {
				if (ordinaryPanel.getInput().equals("")) {
					javax.swing.JOptionPane
							.showMessageDialog(null, "��ѯ��������Ϊ�գ�");
				} else {
				examVo = new ChivementVo();
				examVo.setS_name(ordinaryPanel.getInput());
				ordinarydao = new OrdinaryDao(examVo);
				Object[][] s2 = ordinarydao.selectByName();
				ordinaryPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				if (s2.length == 0) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"û�������������");
				}
			}
			}
		} else if (str.equals("�߼���ѯ")) {
			OrdinaryHighSelectDialog dialog = new OrdinaryHighSelectDialog(
					ordinaryPanel);
			dialog.CreatHighSelectDialog().setVisible(true);
		} else if (str.equals("ˢ��")) {
			ordinarydao = new OrdinaryDao(examVo);
			Object[][] s2 = ordinarydao.selectAll();
			ordinaryPanel.creatJTable().setModel(
					new DefaultTableModel(s2, column));
		} else if (str.equals("�޸�ѡ��ѧ���ɼ�")) {
			if (ordinaryPanel.creatJTable().getSelectedRow() >= 0) {
				examVo = new ChivementVo();
				int i = ordinaryPanel.getChevementJtable().getSelectedRow();

				int stuid = Integer.parseInt(ordinaryPanel.getChevementJtable()
						.getValueAt(i, 0).toString());

				String stuname = ordinaryPanel.getChevementJtable().getValueAt(
						i, 2).toString();

				int ordinary = Integer.parseInt(ordinaryPanel
						.getChevementJtable().getValueAt(i, 3).toString());

				examVo.setS_id(stuid);
				examVo.setS_name(stuname);
				examVo.setClassExamChivement(ordinary);
				OrdinaryUpdateStuDialog dialog = new OrdinaryUpdateStuDialog(
						examVo);
				dialog.creatUpdateStuDialog().setVisible(true);
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ��");
			}

		} else if (str.equals("�޸�ƽʱ�ɼ�")) {
			examVo = new ChivementVo();
			ordinarydao = new OrdinaryDao(examVo);
			ordinarydao.SelectClassStuName();
			int[] sNum = examVo.getSid();
			String[] sName = examVo.getSname();
			int[] classExam = examVo.getClassExam();
			OrdinaryUpdateClassChivementDialog dialog1 = new OrdinaryUpdateClassChivementDialog(
					sNum, sName, classExam);
			dialog1.creatUpdateClass1Dialog().setVisible(true);

		} else if (str.equals("��ӡ")) {
			if (ordinaryPanel.getChevementJtable() != null) {
				try {
					ordinaryPanel.creatJTable().print(null, null, null, true,
							null, false);
				} catch (HeadlessException e1) {
					e1.printStackTrace();
				} catch (PrinterException e1) {
					e1.printStackTrace();
				}
			} else {
				javax.swing.JOptionPane.showMessageDialog(null, "���ȵõ�����");
			}
		}else if(str.equals("����")){
			OrdinaryExcelFrame excel_frame = new OrdinaryExcelFrame();
//			String filename = "f:\\ordinary.xls";
//			int row_count = OrdinaryPanel.chevementJtable.getRowCount();
//			Vector vector = new Vector();
//			for(int i=0;i<row_count;i++){
//				vector.add(OrdinaryPanel.chevementJtable.getValueAt(i, 0));
//				vector.add(OrdinaryPanel.chevementJtable.getValueAt(i, 1));
//				vector.add(OrdinaryPanel.chevementJtable.getValueAt(i, 2));
//				vector.add(OrdinaryPanel.chevementJtable.getValueAt(i, 3));
//				
//			}
//			WritableWorkbook workbook = OrdinaryPutOutExcel.buildWorkBook(filename);
//			WritableSheet sheet = OrdinaryPutOutExcel.setExcel(workbook, row_count,vector);
//			JOptionPane.showMessageDialog(null, "��Ϣ���ѵ���,�����"+filename);
//			
		}
	}

}
