package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import cn.com.dao.chivementdao.OrdinaryDao;
import cn.com.dao.chivementdao.OrdinaryHighSelectDao;
import cn.com.dialog.chivementdialog.OrdinaryHighSelectDialog;
import cn.com.panel.chivementpanel.OrdinaryPanel;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryHighSelectPanelAction implements ActionListener {
	private String[] column = { "ѧ��", "���", "ѧ������", "ƽʱ�ɼ�" };

	OrdinaryHighSelectDialog ordinaryhighSelectDialog;

	private OrdinaryPanel chivementPanel;

	public OrdinaryHighSelectPanelAction(
			OrdinaryHighSelectDialog ordinaryhighSelectDialog,
			OrdinaryPanel chivementPanel) {
		super();
		this.ordinaryhighSelectDialog = ordinaryhighSelectDialog;
		this.chivementPanel = chivementPanel;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			ChivementVo examVo = null;
			OrdinaryDao examdao = null;
			OrdinaryHighSelectDao examhighdao = null;

			boolean selectStuId4 = ordinaryhighSelectDialog.getSelectStuIdBox()
					.isSelected();
			boolean selectGroupId3 = ordinaryhighSelectDialog
					.getSelectGroupIdBox().isSelected();
			boolean selectStuName2 = ordinaryhighSelectDialog
					.getSelectStuNameBox().isSelected();

			if (selectStuId4&&!selectStuName2 && !selectGroupId3) {
				// 001
				int stuId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examdao = new OrdinaryDao(examVo);
					Object[][] s2 = examdao.selectBySid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2.length == 0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3&&!selectStuName2&& !selectStuId4) {
				// 010
				int groupId = 0;
				try {
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examdao = new OrdinaryDao(examVo);
					Object[][] s2 = examdao.selectByGid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2.length == 0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3 && selectStuId4&&!selectStuName2) {
				// 011
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examhighdao = new OrdinaryHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2&& !selectGroupId3 && !selectStuId4) {
				// 100
				String stuName = ordinaryhighSelectDialog
						.getSelectStuNameText().getText();
				examVo = new ChivementVo();
				examVo.setS_name(stuName);
				examdao = new OrdinaryDao(examVo);
				Object[][] s2 = examdao.selectByName();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				ordinaryhighSelectDialog.getDialog().dispose();
				if (s2.length == 0) {
					javax.swing.JOptionPane.showMessageDialog(null, "û�������������");
				}
			} else if (selectStuName2 && selectStuId4&& !selectGroupId3) {
				// 101
				int stuId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					String stuName = ordinaryhighSelectDialog
							.getSelectStuNameText().getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examhighdao = new OrdinaryHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3&& !selectStuId4) {
				// 110
				int groupId = 0;
				try {
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = ordinaryhighSelectDialog
							.getSelectStuNameText().getText();
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new OrdinaryHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3 && selectStuId4) {
				// 111
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = ordinaryhighSelectDialog
							.getSelectStuNameText().getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new OrdinaryHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else {
				// 000
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ���ѯ����");
			}
		} else if (str.equals("ȡ��")) {
			ordinaryhighSelectDialog.getDialog().dispose();
		}
	}

}
