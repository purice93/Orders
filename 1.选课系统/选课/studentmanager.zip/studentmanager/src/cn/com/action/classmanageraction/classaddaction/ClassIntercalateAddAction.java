package cn.com.action.classmanageraction.classaddaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalate;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalateAdd;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassUpdate;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassIntercalateAddAction implements ActionListener {
   ClassIntercalateAdd add;

   ClassIntercalate table;

   public ClassIntercalateAddAction(ClassIntercalateAdd add) {
      this.add = add;
   }

   public void actionPerformed(ActionEvent e) {
      // TODO Auto-generated method stu
      String str = e.getActionCommand();
      Impl impl = null;
      if (str.equals("����")) {
         ClassVO vo, showvo;
         if (!add.classID.getText().equals("")
               && !add.classname.getText().equals("")
               && !add.credithour.getText().equals("")
               && !add.totaltime.getText().equals("")) {
            impl = new Impl();
            if (!impl.checkClassEx(Integer.parseInt(add.classID.getText()))) {
               if (ClassIntercalateAdd.c4.getSelectedItem().toString().equals(
                     "      ")) {
                  JOptionPane.showMessageDialog(null, "û�и���ʦ��������ѡ��!");
               } else {
               }

               int a1 = Integer.parseInt(add.c1.getSelectedItem().toString());// ��ÿ��ε��ܴ�
               int a2 = Integer.parseInt(add.c2.getSelectedItem().toString());// ��ý����γ̵��ܴ�
               if (a1 <= a2) {
                  String s = ClassIntercalateAdd.classID.getText();
                  int a = Integer.parseInt(s);
                  DefaultTableModel model = (DefaultTableModel) ClassIntercalate
                        .buildJTable().getModel();

                  // �������Ŀγ̱��
                  vo = add.getInputInfo();
                  System.out.println(vo);
                  if (impl.appendClass(vo)) {
                     JOptionPane.showMessageDialog(null, "�γ����ӳɹ���");

                     try {
                        showvo = ClassIntercalate.getInputInfo(impl
                              .classinfo(a));
                        Object[] data = { new Integer(showvo.getClassID()),
                              showvo.getClassname(), showvo.getTotaltime(),
                              showvo.getClasstime(), showvo.getCredithour(),
                              showvo.getClassestate(), showvo.getTeacherID(),
                              showvo.getTeachername(), showvo.getTeacherduty(),
                              showvo.getClassremark() };
                        model.addRow(data);
                     } catch (SQLException e1) {
                        e1.printStackTrace();
                     }
                     add.dialog.dispose();

                  }
               } else {
                  JOptionPane.showMessageDialog(null, "����ʱ�䲻�ܱȽ���ʱ��٣�");
               }
            } else {
               JOptionPane.showMessageDialog(null, "�ÿγ̱���Ѿ����ڣ�");
            }
         } else {
            JOptionPane.showMessageDialog(null, "�γ̱�š��γ�������ʱ��ѧ�֡���ʦ��Ų���Ϊ�գ�");
         }
      } else if (str.equals("�˳�")) {
         add.dialog.dispose();

      }

   }
}
