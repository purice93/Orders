package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cn.com.dao.chivementdao.OrdinaryDao;
import cn.com.dialog.chivementdialog.OrdinaryUpdateClassChivementDialog;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryUpdateStuClass1Action implements ActionListener {
	private ChivementVo chivemnetVo;

	private OrdinaryUpdateClassChivementDialog dialog;

	public OrdinaryUpdateStuClass1Action(
			OrdinaryUpdateClassChivementDialog dialog) {
		this.dialog = dialog;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		OrdinaryDao ordinary = null;
		if (str.equals("�ύ")) {
			chivemnetVo = new ChivementVo();
			int[] exam = new int[dialog.getSNum().length];
			for (int i = 0; i < exam.length; i++) {
				if (dialog.getExam()[i].getText().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
							+ dialog.getSNum()[i] + "��ѧ���ɼ�����Ϊ�գ�");
				} else {
					try {
						exam[i] = (Integer.parseInt(dialog.getExam()[i]
								.getText()));
						javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
								+ dialog.getSNum()[i] + "��ѧ���ɼ��޸ĳɹ�");
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
								+ dialog.getSNum()[i] + "��ѧ���ɼ���ʽ����");
					}
				}
			}
			chivemnetVo.setClassExam(exam);
			chivemnetVo.setSid(dialog.getSNum());
			ordinary = new OrdinaryDao(chivemnetVo);
			ordinary.UpdateClassStuName();
			javax.swing.JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
			dialog.getUpdateClass1().dispose();

		}
	}
}
