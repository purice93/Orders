package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cn.com.dao.chivementdao.ExamDao;
import cn.com.dialog.chivementdialog.ExamUpdateClassChivementDialog;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamUpdateStuClass1Action implements ActionListener {
	private ChivementVo examVo;

	private ExamUpdateClassChivementDialog dialog;

	public ExamUpdateStuClass1Action(ExamUpdateClassChivementDialog dialog) {
		this.dialog = dialog;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		ExamDao examdao = null;
		if (str.equals("�ύ")) {
			examVo = new ChivementVo();
			int[] exam = new int[dialog.getSNum().length];
			for (int i = 0; i < exam.length; i++) {
				if (dialog.getExam()[i].getText().equals("")) {
					javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
							+ dialog.getSNum()[i] + "��ѧ���ɼ�����Ϊ�գ�");
				} else {
					try {
						exam[i] = (Integer.parseInt(dialog.getExam()[i]
								.getText()));
						examVo.setClassExam(exam);
						examVo.setSid(dialog.getSNum());
						examVo.setC_id(dialog.getClassNo());
						examdao = new ExamDao(examVo);
						examdao.UpdateClassStuName();
						javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
								+ dialog.getSNum()[i] + "��ѧ���ɼ��޸ĳɹ�");
						dialog.getUpdateClass1().dispose();
					} catch (NumberFormatException ex) {
						javax.swing.JOptionPane.showMessageDialog(null, "ѧ��Ϊ"
								+ dialog.getSNum()[i] + "��ѧ���ɼ���ʽ����");

					}
				}
			}

		}
	}
}
