package cn.com.action.classmanageraction.enrgisteraction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classmanager.ClassEnregister;
import cn.com.dialog.classmanagerdialog.classmanager.ClassManager;

public class EnregisterAction implements ActionListener {
	ClassEnregister enregister;

	public EnregisterAction(ClassEnregister enregister) {
		this.enregister = enregister;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String str = e.getActionCommand();
		if (str.equals("�Ǽ�")) {
			ClassManager manager = new ClassManager();
			Impl impl = new Impl();
			int row = manager.buildJTable().getSelectedRow();
			int stuNo = Integer.parseInt(manager.stu_ID.getText());
			DefaultTableModel model1 = (DefaultTableModel) manager
					.buildJTable().getModel();
			Object num = model1.getValueAt(row, 0);
			int classNo = Integer.parseInt(num.toString());
			String className = model1.getValueAt(row, 1).toString();
			if (impl.checkClassBook(stuNo, classNo)) {

				impl.momerizeBookTime(stuNo, classNo);
			} else {
				impl.classBook(classNo, stuNo, className);
			}
			Object[][] data = impl.classBookInfo(stuNo, classNo);
			DefaultTableModel model = (DefaultTableModel) manager
					.buildJTable1().getModel();
			int count = model.getRowCount();
			for (int j = count - 1; j >= 0; j--) {
				model.removeRow(j);
			}
			for (int i = 0; i < data.length; i++) {
				model.addRow(data[i]);
			}
			enregister.dialog.dispose();
		} else if (str.equals("�˳�")) {
			enregister.dialog.dispose();
		}

	}

}
