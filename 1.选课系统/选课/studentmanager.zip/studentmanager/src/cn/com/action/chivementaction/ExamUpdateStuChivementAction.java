package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cn.com.dao.chivementdao.ExamDao;
import cn.com.dialog.chivementdialog.ExamUpdateStuDialog;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamUpdateStuChivementAction implements ActionListener {

	private ChivementVo examVo;

	private ExamUpdateStuDialog dialog;

	public ExamUpdateStuChivementAction(ChivementVo examVo,
			ExamUpdateStuDialog dialog) {
		super();
		this.examVo = examVo;
		this.dialog = dialog;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			if (dialog.getText().getText().equals("")) {
				javax.swing.JOptionPane.showMessageDialog(null, "��������Ϊ�գ�");
			} else {
				int classno = examVo.getC_id();
				if(classno!=0){
				try {
					examVo.setClassExamChivement(Integer.parseInt(dialog
							.getText().getText()));
					ExamDao examdao = new ExamDao(examVo);
					examdao.updatSelectClass();
					javax.swing.JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					dialog.getUpdateStu().dispose();
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}}else{
					javax.swing.JOptionPane.showMessageDialog(null,
					"�ÿγ�Ϊȱʡ�γ̣������޸ģ�");
				}
			}
		}
	}

}
