package cn.com.action.classmanageraction.classaddaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classmanager.ClassAdd;
import cn.com.dialog.classmanagerdialog.classmanager.ClassManager;


public class ClassAddAction implements ActionListener {
	ClassAdd add;

	ClassManager dialog;

	public ClassAddAction(ClassAdd add) {
		this.add = add;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String str = e.getActionCommand();
		if (str.equals("����")) {
			Object[][] data = null;
			Impl impl = new Impl();
			dialog = new ClassManager();
			DefaultTableModel model = (DefaultTableModel) add.buildJTable()
					.getModel();
			DefaultTableModel model1 = (DefaultTableModel) dialog.buildJTable()
					.getModel();
			int[] row = add.buildJTable().getSelectedRows();
			int column = model.getColumnCount();
			String no = dialog.stu_ID.getText();
			if(no == ""){
				JOptionPane.showMessageDialog(null, "��������Ҫѡ�ε�ѧ��ѧ��");
			}else{
			int stuNo = Integer.parseInt(no);
			System.out.println(row.length + " " + column);
			data = new Object[row.length][column];
			for (int i = 0; i < row.length; i++) {
				for (int a = 0; a < column; a++) {
					data[i][a] = model.getValueAt(row[i], a);
				}
				int j = Integer
						.parseInt(model.getValueAt(row[i], 0).toString());
				System.out.println("j="+j);
				if (impl.classChooseByStu(stuNo,j)) {

					model1.addRow(data[i]);
					JOptionPane.showMessageDialog(null, "�Ѿ�����ѡ��Ŀμ��뵽�α����ˣ�");
				}else{
					JOptionPane.showMessageDialog(null, "�γ�����ʧ�ܣ�");
				}
			}
			if(add.buildJTable().getSelectedRow() == -1){
				JOptionPane.showMessageDialog(null, "�㻹û��ѡ��γ̣�");
			}else{	
			add.dialog.dispose();
			}
			}
		} else if (str.equals("�˳�")) {
			add.dialog.dispose();
		}

	}

}
