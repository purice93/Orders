package cn.com.action.studentmanageraction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import cn.com.dao.studentmanagerdao.TeacherDao;
import cn.com.dao.studentmanagerdao.TeacherHighSelectDao;
import cn.com.dialog.studentmanagerdialog.TeacherHighSelectDialog;
import cn.com.panel.studentmanagerpanel.TeacherPanel;
import cn.com.vo.studentmanagervo.TeacherVo;

public class TeacherHighSelectPanelAction implements ActionListener {
	private String[] column = { "��ʦID", "��ʦ����", "��ʦ�Ա�", "��ʦ����", "��ʦְ��", "��ʦQQ",
				"��ʦemail", "��ʦ�绰" };

	TeacherHighSelectDialog teacherhighSelectDialog;

	private TeacherPanel chivementPanel;

	public TeacherHighSelectPanelAction(
			TeacherHighSelectDialog teacherhighSelectDialog,
			TeacherPanel chivementPanel) {
		super();
		this.teacherhighSelectDialog = teacherhighSelectDialog;
		this.chivementPanel = chivementPanel;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			TeacherVo teacherVo = null;
			TeacherDao teacherdao = null;
			TeacherHighSelectDao teacherhighdao = null;

			boolean selectStuId4 = teacherhighSelectDialog
					.getSelectTeacherIdBox().isSelected();
			boolean selectGroupId3 = teacherhighSelectDialog
					.getSelectDutyIdBox().isSelected();
			boolean selectStuName2 = teacherhighSelectDialog
					.getSelectTeacherNameBox().isSelected();

			if (selectStuId4&&!selectGroupId3&&!selectStuName2) {
				// 001
				int teacherId = 0;
				try {
					teacherId = Integer.parseInt(teacherhighSelectDialog
							.getSelectTeacherIdText().getText());
					teacherVo = new TeacherVo();
					teacherVo.setT_id(teacherId);
					teacherdao = new TeacherDao(teacherVo);
					Object[][] s2 = teacherdao.selectBySid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					teacherhighSelectDialog.getDialog().dispose();
					if (s2.length == 0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3&&!selectStuId4&&!selectStuName2) {
				// 010
				String duty = teacherhighSelectDialog
						.getSelectTeacherDutyText().getText();
				teacherVo = new TeacherVo();
				teacherVo.setT_duty(duty);
				teacherdao = new TeacherDao(teacherVo);
				Object[][] s2 = teacherdao.selectByDuty();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				teacherhighSelectDialog.getDialog().dispose();
				if (s2.length == 0) {
					javax.swing.JOptionPane.showMessageDialog(null, "û�������������");
				}
			} else if (selectGroupId3 && selectStuId4&&selectStuName2) {
				// 011
				int teacherId = 0;
				try {
					teacherId = Integer.parseInt(teacherhighSelectDialog
							.getSelectTeacherIdText().getText());
					String duty = teacherhighSelectDialog
							.getSelectTeacherDutyText().getText();
					teacherVo = new TeacherVo();
					teacherVo.setT_id(teacherId);
					teacherVo.setT_duty(duty);
					teacherhighdao = new TeacherHighSelectDao(teacherVo);
					Object[][] s2 = teacherhighdao.select011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					teacherhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2&&!selectStuId4&&!selectGroupId3) {
				// 100
				String teacherName = teacherhighSelectDialog
						.getSelectTeacherNameText().getText();
				teacherVo = new TeacherVo();
				teacherVo.setT_name(teacherName);
				teacherdao = new TeacherDao(teacherVo);
				Object[][] s2 = teacherdao.selectByName();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				teacherhighSelectDialog.getDialog().dispose();
				if (s2.length == 0) {
					javax.swing.JOptionPane.showMessageDialog(null, "û�������������");
				}
			} else if (selectStuName2 && selectStuId4&&!selectGroupId3) {
				// 101
				int teacherId = 0;
				try {
					teacherId = Integer.parseInt(teacherhighSelectDialog
							.getSelectTeacherIdText().getText());
					String teachrName = teacherhighSelectDialog
							.getSelectTeacherNameText().getText();
					teacherVo = new TeacherVo();
					teacherVo.setT_id(teacherId);
					teacherVo.setT_name(teachrName);
					teacherhighdao = new TeacherHighSelectDao(teacherVo);
					Object[][] s2 = teacherhighdao.select101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					teacherhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3&&!selectStuId4) {
				// 110

				String duty = teacherhighSelectDialog
						.getSelectTeacherDutyText().getText();
				String teacherName = teacherhighSelectDialog
						.getSelectTeacherNameText().getText();
				teacherVo = new TeacherVo();
				teacherVo.setT_duty(duty);
				teacherVo.setT_name(teacherName);
				teacherhighdao = new TeacherHighSelectDao(teacherVo);
				Object[][] s2 = teacherhighdao.select110();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				teacherhighSelectDialog.getDialog().dispose();
				if (s2==null) {
					javax.swing.JOptionPane.showMessageDialog(null, "û�������������");
				}

			} else if (selectStuName2 && selectGroupId3 && selectStuId4) {
				// 111
				int teacherId = 0;
				try {
					teacherId = Integer.parseInt(teacherhighSelectDialog
							.getSelectTeacherIdText().getText());
					String duty = teacherhighSelectDialog
							.getSelectTeacherDutyText().getText();
					String teacherName = teacherhighSelectDialog
							.getSelectTeacherNameBox().getText();
					teacherVo = new TeacherVo();
					teacherVo.setT_id(teacherId);
					teacherVo.setT_duty(duty);
					teacherVo.setT_name(teacherName);
					teacherhighdao = new TeacherHighSelectDao(teacherVo);
					Object[][] s2 = teacherhighdao.select111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					teacherhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else {
				// 000
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ���ѯ����");
			}
		} else if (str.equals("ȡ��")) {
			teacherhighSelectDialog.getDialog().dispose();
		}
	}

}
