package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import cn.com.dao.chivementdao.ExamDao;
import cn.com.dao.chivementdao.ExamHighSelectDao;
import cn.com.dialog.chivementdialog.ExamHighSelectDialog;
import cn.com.panel.chivementpanel.ExamPanel;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamHighSelectPanelAction implements ActionListener {
	private String[] column = { "ѧ��", "���", "ѧ������", "�γ̱��", "�γ�����", "�γ̳ɼ�" };

	ExamHighSelectDialog highSelectDialog;

	private ExamPanel chivementPanel;

	public ExamHighSelectPanelAction(ExamHighSelectDialog highSelectDialog,
			ExamPanel chivementPanel) {
		super();
		this.highSelectDialog = highSelectDialog;
		this.chivementPanel = chivementPanel;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			ChivementVo examVo = null;
			ExamDao examdao = null;
			ExamHighSelectDao examhighdao = null;

			boolean selectClass5 = highSelectDialog.getSelectClassBox()
					.isSelected();
			boolean selectStuId4 = highSelectDialog.getSelectStuIdBox()
					.isSelected();
			boolean selectGroupId3 = highSelectDialog.getSelectGroupIdBox()
					.isSelected();
			boolean selectStuName2 = highSelectDialog.getSelectStuNameBox()
					.isSelected();
			boolean selectClassName1 = highSelectDialog.getSelectClassNameBox()
					.isSelected();

			if (selectClass5&&!selectClassName1 && !selectStuName2 && !selectGroupId3
					&& !selectStuId4) {
//				00001
				int classNo = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examdao = new ExamDao(examVo);
					Object[][] s2 = examdao.selectByCid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2.length==0){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuId4&&!selectClassName1 && !selectStuName2 && !selectGroupId3
					&& !selectClass5) {
//				00010
				int stuId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examdao = new ExamDao(examVo);
					Object[][] s2 = examdao.selectBySid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2.length==0){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClass5 && selectStuId4&&!selectClassName1 && !selectStuName2 && !selectGroupId3
					 ) {
//				00011
				int classNo = 0;
				int stuId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select00011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3&&!selectClassName1 && !selectStuName2 
					&& !selectStuId4 && !selectClass5) {
//				00100
				int groupId = 0;
				try {
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examdao = new ExamDao(examVo);
					Object[][] s2 = examdao.selectByGid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2.length==0){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3 && selectClass5&&!selectClassName1 && !selectStuName2
					&& !selectStuId4) {
//				00101
				int classNo = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setG_id(groupId);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select00101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3 && selectStuId4&&!selectClassName1 && !selectStuName2
					&& !selectClass5) {
//				00110
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select00110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3 && selectStuId4 && selectClass5&&!selectClassName1 && !selectStuName2) {
//				00111
				int classNo = 0;
				int stuId = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select00111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2&&!selectClassName1 && !selectGroupId3
					&& !selectStuId4 && !selectClass5) {
//				01000
				String stuName = highSelectDialog.getSelectStuNameText()
						.getText();
				examVo = new ChivementVo();
				examVo.setS_name(stuName);
				examdao = new ExamDao(examVo);
				Object[][] s2 = examdao.selectByName();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				highSelectDialog.getDialog().dispose();
				if(s2.length==0){
					javax.swing.JOptionPane
					.showMessageDialog(null, "û�������������");
				}
			} else if (selectStuName2 && selectClass5&&!selectClassName1 && !selectGroupId3
					&& !selectStuId4) {
//				01001
				int classNo = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01001();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectStuId4&&!selectClassName1  && !selectGroupId3
					&& !selectClass5) {
//				01010
				int stuId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01010();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectStuId4 && selectClass5&&!selectClassName1  && !selectGroupId3
					) {
//				01011
				int classNo = 0;
				int stuId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3&&!selectClassName1 
					&& !selectStuId4 && !selectClass5) {
//				01100
				int groupId = 0;
				try {
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01100();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3 && selectClass5&&!selectClassName1 
					&& !selectStuId4 ) {
//				01101
				int classNo = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3 && selectStuId4&&!selectClassName1 
					&& !selectClass5) {
//				01110
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectStuName2 && selectGroupId3 && selectStuId4
					&& selectClass5&&!selectClassName1 ) {
//				01111
				int classNo = 0;
				int stuId = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select01111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && !selectStuName2 && !selectGroupId3
					&& !selectStuId4 && !selectClass5) {
//				10000
				String className = highSelectDialog.getSelectClassNameText()
				.getText();
				examVo = new ChivementVo();
				examVo.setClass_name(className);
				examdao = new ExamDao(examVo);
				Object[][] s2 = examdao.selectByClassName();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				highSelectDialog.getDialog().dispose();
				if(s2.length==0){
					javax.swing.JOptionPane
					.showMessageDialog(null, "û�������������");
				}
			}

			else if (selectClassName1 && selectClass5&& !selectStuName2 && !selectGroupId3
					&& !selectStuId4 ) {
//				10001
				int classNo = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10001();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuId4&& !selectStuName2 && !selectGroupId3
					 && !selectClass5) {
//				10010
				int stuId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10010();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuId4 && selectClass5&& !selectStuName2 && !selectGroupId3
					) {
//				10011
				int classNo = 0;
				int stuId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
					
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectGroupId3&& !selectStuName2 
					&& !selectStuId4 && !selectClass5) {
//				10100
				int groupId = 0;
				try {
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10100();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectGroupId3 && selectClass5&& !selectStuName2 && 
					!selectStuId4 ) {
//				10101
				int classNo = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setG_id(groupId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectGroupId3 && selectStuId4&& !selectStuName2 
					&& !selectClass5) {
//				10110
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectGroupId3 && selectStuId4
					&& selectClass5&& !selectStuName2) {
//				10111
				int classNo = 0;
				int stuId = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select10111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2&&!selectGroupId3
					&& !selectStuId4 && !selectClass5) {
//				11000
				String stuName = highSelectDialog.getSelectStuNameText()
						.getText();
				String className = highSelectDialog.getSelectClassNameText()
						.getText();
				examVo = new ChivementVo();
				examVo.setS_name(stuName);
				examVo.setClass_name(className);
				examhighdao = new ExamHighSelectDao(examVo);
				Object[][] s2 = examhighdao.select11000();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				highSelectDialog.getDialog().dispose();
				if(s2==null){
					javax.swing.JOptionPane
					.showMessageDialog(null, "û�������������");
				}
			}

			else if (selectClassName1 && selectStuName2 && selectClass5 && !selectGroupId3
					&& !selectStuId4 ) {
//				11001
				int classNo = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11001();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectStuId4&& !selectGroupId3
					&& !selectClass5) {
//				11010
				int stuId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11010();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectStuId4
					&& selectClass5&& !selectGroupId3) {
//				11011
				int classNo = 0;
				int stuId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectGroupId3
					&& !selectStuId4 && !selectClass5) {
//				11100
				int groupId = 0;
				try {
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11100();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectGroupId3
					&& selectClass5
					&& !selectStuId4) {
//				11101
				int classNo = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectGroupId3
					&& selectStuId4&& !selectClass5) {
//				11110
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectClassName1 && selectStuName2 && selectGroupId3
					&& selectStuId4 && selectClass5) {
//				11111
				int classNo = 0;
				int stuId = 0;
				int groupId = 0;
				try {
					classNo = Integer.parseInt(highSelectDialog
							.getSelectClassText().getText());
					stuId = Integer.parseInt(highSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(highSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = highSelectDialog.getSelectStuNameText()
					.getText();
					String className = highSelectDialog.getSelectClassNameText()
					.getText();
					examVo = new ChivementVo();
					examVo.setC_id(classNo);
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examVo.setClass_name(className);
					examhighdao = new ExamHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select11111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					highSelectDialog.getDialog().dispose();
					if(s2==null){
						javax.swing.JOptionPane
						.showMessageDialog(null, "û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else {
//				00000
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ���ѯ����");
			}
		} else if (str.equals("ȡ��")) {
			highSelectDialog.getDialog().dispose();
		}
	}

}
