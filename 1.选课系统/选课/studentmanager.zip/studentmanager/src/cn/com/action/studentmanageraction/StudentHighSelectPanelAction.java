package cn.com.action.studentmanageraction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import cn.com.dao.studentmanagerdao.StudentDao;
import cn.com.dao.studentmanagerdao.StudentHighSelectDao;
import cn.com.dialog.studentmanagerdialog.StudentHighSelectDialog;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.vo.studentmanagervo.StudentVo;

public class StudentHighSelectPanelAction implements ActionListener {
///////////////////////////////////////////////////////////
	private String[] column = { "ѧ��", "���", "����", "�Ա�", "�꼶", "ѧУ", "רҵ", "��ϵ����",
				"QQ", "�����ʼ�" };
/////////////////////////////////////////////////////////////
	StudentHighSelectDialog ordinaryhighSelectDialog;

	private StudentPanel chivementPanel;

	public StudentHighSelectPanelAction(StudentHighSelectDialog ordinaryhighSelectDialog,
			StudentPanel chivementPanel) {
		super();
		this.ordinaryhighSelectDialog = ordinaryhighSelectDialog;
		this.chivementPanel = chivementPanel;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			StudentVo examVo = null;
			StudentDao examdao = null;
			StudentHighSelectDao examhighdao = null;

			boolean selectStuId4 = ordinaryhighSelectDialog.getSelectStuIdBox()
					.isSelected();
			boolean selectGroupId3 = ordinaryhighSelectDialog.getSelectGroupIdBox()
					.isSelected();
			boolean selectStuName2 = ordinaryhighSelectDialog.getSelectStuNameBox()
					.isSelected();
////////////////////////////////////////
                if (selectStuId4&&!selectGroupId3&&!selectStuName2) {
///////////////////////////////////////
//				001
				int stuId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					examVo = new StudentVo();
					examVo.setS_id(stuId);
					examdao = new StudentDao(examVo);
					Object[][] s2 = examdao.selectBySid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
//////////////////////////////////////////////
					if (s2.length==0) {
////////////////////////////////////////////////
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else if (selectGroupId3&&!selectStuId4&&!selectStuName2) {
//				010
				int groupId = 0;
				try {
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new StudentVo();
					examVo.setG_id(groupId);
					examdao = new StudentDao(examVo);
					Object[][] s2 = examdao.selectByGid();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2.length==0) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			}else if (selectGroupId3 && selectStuId4&&!selectStuName2) {
//				011
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					examVo = new StudentVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examhighdao = new StudentHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select011();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2 == null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			}  else if (selectStuName2&&!selectStuId4&&!selectGroupId3) {
//				100
				String stuName = ordinaryhighSelectDialog.getSelectStuNameText()
						.getText();
				examVo = new StudentVo();
				examVo.setS_name(stuName);
				examdao = new StudentDao(examVo);
				Object[][] s2 = examdao.selectByName();
				chivementPanel.creatJTable().setModel(
						new DefaultTableModel(s2, column));
				ordinaryhighSelectDialog.getDialog().dispose();
				if (s2.length==0) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"û�������������");
				}
			} else if (selectStuName2 && selectStuId4&&!selectGroupId3) {
//				101
				int stuId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					String stuName = ordinaryhighSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new StudentVo();
					examVo.setS_id(stuId);
					examVo.setS_name(stuName);
					examhighdao = new StudentHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select101();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			}  else if (selectStuName2 && selectGroupId3&&!selectStuId4) {
//				110
				int groupId = 0;
				try {
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = ordinaryhighSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new StudentVo();
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new StudentHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select110();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			}  else if (selectStuName2 && selectGroupId3 && selectStuId4) {
//				111
				int stuId = 0;
				int groupId = 0;
				try {
					stuId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectStuIdText().getText());
					groupId = Integer.parseInt(ordinaryhighSelectDialog
							.getSelectGroupIdText().getText());
					String stuName = ordinaryhighSelectDialog.getSelectStuNameText()
					.getText();
					examVo = new StudentVo();
					examVo.setS_id(stuId);
					examVo.setG_id(groupId);
					examVo.setS_name(stuName);
					examhighdao = new StudentHighSelectDao(examVo);
					Object[][] s2 = examhighdao.select111();
					chivementPanel.creatJTable().setModel(
							new DefaultTableModel(s2, column));
					ordinaryhighSelectDialog.getDialog().dispose();
					if (s2==null) {
						javax.swing.JOptionPane.showMessageDialog(null,
								"û�������������");
					}
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			} else {
//				000
				javax.swing.JOptionPane.showMessageDialog(null, "����ѡ���ѯ����");
			}
		} else if (str.equals("ȡ��")) {
			ordinaryhighSelectDialog.getDialog().dispose();
		}
	}

}
