package cn.com.action.classmanageraction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;

import cn.com.dao.classmanagerdao.Impl;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalate;
import cn.com.dialog.classmanagerdialog.classmanager.ClassAdd;
import cn.com.dialog.classmanagerdialog.classmanager.ClassByTeacher;
import cn.com.dialog.classmanagerdialog.classmanager.ClassEnregister;
import cn.com.dialog.classmanagerdialog.classmanager.ClassManager;
import cn.com.frame.Test;
import cn.com.panel.classmanagerpanel.ClassPanel;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.vo.classmanagervo.ClassStudentVo;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassInfoAction implements ActionListener {
	ClassPanel panel;

	ClassManager panel1;

	ClassEnregister enregister;

	ClassAdd add;

	ClassIntercalate intercalate;

	Impl impl;

	ClassByTeacher teacher;

	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public ClassInfoAction(ClassIntercalate intercalate) {
		this.intercalate = intercalate;

	}

	public ClassInfoAction(ClassAdd add) {
		this.add = add;
	}

	public ClassInfoAction(ClassManager panel1) {
		this.panel1 = panel1;
	}

	public ClassInfoAction(ClassPanel panel,
			TitledTabProperties titledTabProperties, Test test, TabbedPanel tp) {
		this.panel = panel;
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public ClassInfoAction(ClassEnregister enregister) {
		this.enregister = enregister;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String str = e.getActionCommand();
		if (str.equals("�γ̹���")) {
			panel1 = new ClassManager();
         JDialog panel2 = panel1.buildPanel("�γ̹���");
//         JScrollPane js = new JScrollPane();
//         js.setViewportView(panel2);
//			TitledTab tab = new TitledTab("�γ̹���", null, js, null);
//			tab.setHighlightedStateTitleComponent(test
//					.createCloseTabButton(tab));
//			tab.getProperties().addSuperObject(titledTabProperties);
//			tp.addTab(tab);
//			tp.setSelectedTab(tab);
         panel2.setModal(true);
		} else if (str.equals("�ϿεǼ�")) {

			// DefaultTableModel model = (DefaultTableModel)
			// dialog.buildJTable()
			// .getModel();
			int row = panel1.buildJTable().getSelectedRow();

			if (!panel1.stu_ID.getText().equals("")
					&& panel1.c.getSelectedItem().equals("  ѧ��  ")) {
				System.out.println("dialog.text.getText() = "
						+ panel1.text.getText().toString());

				if (row == -1) {
					JOptionPane.showMessageDialog(null, "��ѡ����Ҫ�ǼǵĿ�Ŀ");
				} else {
					int classNo = Integer.parseInt(panel1.buildJTable()
							.getValueAt(row, 0).toString());
					impl = new Impl();
					ClassVO vo = impl.classPInfo(classNo);
					enregister = new ClassEnregister(vo);
				}
			} else {
				JOptionPane.showMessageDialog(null, "���Ȳ�ѯ����������֤��", "�Ǽ���ʾ",
						JOptionPane.YES_OPTION);
			}

		} else if (str.equals("ѧ��ѡ��")) {
			if (!panel1.stu_ID.getText().equals("")
					&& panel1.c.getSelectedItem().equals("  ѧ��  ")) {
				add = new ClassAdd();
				impl = new Impl();
				DefaultTableModel model = (DefaultTableModel) add.buildJTable()
						.getModel();
				Object[][] data = impl.getClassInfo();
				for (int i = 0; i < data.length; i++) {
					model.addRow(data[i]);
				}
				add.buildDialog("ѧ��ѡ��");
			} else {
				JOptionPane.showMessageDialog(null, "���Ȳ�ѯ����������֤��", "���ӿγ���ʾ",
						JOptionPane.YES_OPTION);
			}

		} else if (str.equals("�γ�����")) {
			intercalate = new ClassIntercalate();
//			intercalate.buildDialog("�γ�����");
//			panel1 = new ClassIntercalate();
			TitledTab tab = new TitledTab("�γ�����", null, intercalate
					.buildDialog("�γ�����"), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("  ��ѯ  ")) {
			String s = (String) panel1.c.getSelectedItem();
			String num = panel1.text.getText();
			if (num.equals("")) {
				JOptionPane.showMessageDialog(null, "��������");
			} else {
				impl = new Impl();
				if (s.equals("  ѧ��  ")) {
					if (impl.checkStudent(Integer
							.parseInt(panel1.text.getText()))) {
						int no = Integer.parseInt(num);

						DefaultTableModel model = (DefaultTableModel) panel1
								.buildJTable().getModel();
						int row = panel1.buildJTable().getRowCount();
						for (int i = row - 1; i >= 0; i--) {
							model.removeRow(i);
						}
						ClassStudentVo vo = null;
						try {
							vo = impl.setLableInfo(impl.stuFind(no));
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						if (vo != null) {
							panel1.getLabelInfo(vo);
							Object[][] data = impl.FindC_TByNo(no);
							for (int i = 0; i < data.length; i++) {
								model.addRow(data[i]);
							}
						}
					} else {
						JOptionPane.showMessageDialog(null, "��ѧ��������");
					}
				} else if (s.equals("  ��ʦ  ")
						&& impl.checkTeacher(Integer.parseInt(panel1.text
								.getText()))) {
					int t_id = Integer.parseInt(num);
					DefaultTableModel model = (DefaultTableModel) teacher
							.buildTable().getModel();
					int row = model.getRowCount();
					for (int i = row - 1; i >= 0; i--) {
						model.removeRow(i);
					}
					Object[][] data = impl.ClassFindByTNo(t_id);
					for (int i = 0; i < data.length; i++) {
						model.addRow(data[i]);

					}
					new ClassByTeacher();
				} else {
					JOptionPane.showMessageDialog(null, "����ʦ������");
				}
			}
		} else if (str.equals("����γ�")) {
			impl = new Impl();
			DefaultTableModel model = (DefaultTableModel) teacher.buildTable()
					.getModel();
			int row = model.getRowCount();
			for (int i = row - 1; i >= 0; i--) {
				model.removeRow(i);
			}
			Object[][] data = impl.allClassFind();
			for (int i = 0; i < data.length; i++) {
				model.addRow(data[i]);
			}
			new ClassByTeacher();
		}else if(str.equals("���ڲ�ѯ")){
			ClassManager manager = new ClassManager();
			Impl impl = new Impl();
			int row = manager.buildJTable().getSelectedRow();
			String s = manager.stu_ID.getText();
			if(!s.equals("")){
			int stuNo = Integer.parseInt(s);
//			DefaultTableModel model1 = (DefaultTableModel) manager
//					.buildJTable().getModel();
//			Object num = model1.getValueAt(row, 0);
//			int classNo = Integer.parseInt(num.toString());
//			String className = model1.getValueAt(row, 1).toString();
			System.out.println("stuNo = "+stuNo);
			Object[][] data = impl.momerizeABookTime(stuNo);
			DefaultTableModel model = (DefaultTableModel) manager
					.buildJTable1().getModel();
			int count = model.getRowCount();
			for(int j = count -1;j>=0;j--){
				model.removeRow(j);
			}
			for (int i = 0; i < data.length; i++) {
				model.addRow(data[i]);
			}}else{
				JOptionPane.showMessageDialog(null, "��û��ѡ��ѧ��");
			}
		}else if(str.equals("�γ�ע��")){
			ClassManager manager = new ClassManager();
			Impl impl = new Impl();
			int row = manager.buildJTable().getSelectedRow();
			String s = manager.stu_ID.getText();
			if(!s.equals("")){
			int stuNo = Integer.parseInt(s);
			
			if(row == -1){
				JOptionPane.showMessageDialog(null, "��ѡ����Ҫע���Ŀγ̣�");
				
			}else{
				DefaultTableModel model = (DefaultTableModel)manager.buildJTable().getModel();
				int selectRow = manager.buildJTable().getSelectedRow();
				String no = manager.buildJTable().getValueAt(selectRow, 0).toString();
				int classNo = Integer.parseInt(no);
				if(impl.classDeleteChoose(stuNo,classNo)){
					JOptionPane.showMessageDialog(null, "ע���ɹ���");
					model.removeRow(row);
					
				}
				}
				
			}else{
				JOptionPane.showMessageDialog(null, "��û��ѡ��ѧ��");
			}
		}

	}
}
