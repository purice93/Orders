package cn.com.action.chivementaction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cn.com.dao.chivementdao.OrdinaryDao;
import cn.com.dialog.chivementdialog.OrdinaryUpdateStuDialog;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryUpdateStuChivementAction implements ActionListener {

	private ChivementVo chivementVo;

	private OrdinaryUpdateStuDialog dialog;

	public OrdinaryUpdateStuChivementAction(ChivementVo examVo,
			OrdinaryUpdateStuDialog dialog) {
		super();
		this.chivementVo = examVo;
		this.dialog = dialog;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("�ύ")) {
			if (dialog.getText().getText().equals("")) {
				javax.swing.JOptionPane.showMessageDialog(null, "��������Ϊ�գ�");
			} else {
				try {
					chivementVo.setClassExamChivement(Integer.parseInt(dialog
							.getText().getText()));
					OrdinaryDao ordinarydao = new OrdinaryDao(chivementVo);
					ordinarydao.updatSelectClass();
					javax.swing.JOptionPane.showMessageDialog(null, "�޸ĳɹ���");
					dialog.getUpdateStu().dispose();
				} catch (NumberFormatException ex) {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��������ȷ���ַ���ʽ��");
				}
			}
		}

	}
}