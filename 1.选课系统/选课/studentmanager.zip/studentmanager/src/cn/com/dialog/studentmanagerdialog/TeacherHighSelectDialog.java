package cn.com.dialog.studentmanagerdialog;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.action.studentmanageraction.TeacherHighSelectPanelAction;
import cn.com.panel.studentmanagerpanel.TeacherPanel;


public class TeacherHighSelectDialog {
	private JDialog dialog;
	
	private TeacherPanel teacherypanel;
	
	
	private JTextField selectTeacherIdText;
	
	private JTextField selectTeacherDutyText;
	
	private JTextField selectTeacherNameText;
	
	
	
	private JCheckBox selectTeacherIdBox;
	
	private JCheckBox selectDutyIdBox;
	
	private JCheckBox selectTeacherNameBox;
	
	
	
	
	public TeacherHighSelectDialog(TeacherPanel teacherPanel) {
		super();
		this.teacherypanel = teacherPanel;
	}

	public JDialog CreatHighSelectDialog() {
		if (dialog == null) {
			dialog = new JDialog();
			dialog.add(HighSelectPanel());
//			dialog.setSize(500, 500);
			dialog.setModal(true);
			dialog.pack();
			dialog.setLocationRelativeTo(null);
			return dialog;
		}
		return null;
	}
	

	public JPanel HighSelectPanel() {
		JPanel panel = new JPanel();
		initTxt();
		panel.setLayout(new BorderLayout());
		panel.add(CreatSelectPanel(), "Center");
		panel.add(CreatButtonPanel(), "South");
		panel.setBorder(BorderFactory.createTitledBorder("��ѡ���ѯ����:"));
		return panel;
	}

	public JPanel CreatSelectPanel() {
		JPanel panel = new JPanel();

		panel.setLayout(new GridLayout(3, 2));
		panel.add(this.creatselectstuIdBox());
		panel.add(this.selectTeacherIdText);
		panel.add(this.creatselectGroupIdBox());
		panel.add(this.selectTeacherDutyText);
		panel.add(this.creatselectStuNameBox());
		panel.add(this.selectTeacherNameText);
		return panel;

	}

	public JPanel CreatButtonPanel() {
		JPanel panel = new JPanel();
		panel.add(creatBtn("�ύ"));
		panel.add(creatBtn("ȡ��"));
		return panel;
	}

	public void initTxt() {
		selectTeacherIdText = creatTextField(selectTeacherIdText);
		selectTeacherDutyText = creatTextField(selectTeacherDutyText);
		selectTeacherNameText = creatTextField(selectTeacherNameText);
	}

	public JTextField creatTextField(JTextField textfield) {
		textfield = new JTextField(8);
		textfield.setEditable(false);
		return textfield;
	}

	public JButton creatBtn(String name) {
		JButton btn = new JButton(name);
		TeacherHighSelectPanelAction action = new TeacherHighSelectPanelAction(this,teacherypanel);
		btn.addActionListener(action);
		return btn;
	}


	public JCheckBox creatselectstuIdBox() {
		if (selectTeacherIdBox == null) {
			selectTeacherIdBox = new JCheckBox("���ݽ�ʦ��Ų�ѯ:");
		}
		selectTeacherIdBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectTeacherIdBox.isSelected()) {
					selectTeacherIdText.setEditable(true);
				} else {
					selectTeacherIdText.setText("");
					selectTeacherIdText.setEditable(false);
				}
			}

		});
		return selectTeacherIdBox;
	}

	public JCheckBox creatselectGroupIdBox() {
		if (selectDutyIdBox == null) {
			selectDutyIdBox = new JCheckBox("����ְ���ѯ(��ģ����ѯ):");
		}
		selectDutyIdBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectDutyIdBox.isSelected()) {
					selectTeacherDutyText.setEditable(true);
				} else {
					selectTeacherDutyText.setText("");
					selectTeacherDutyText.setEditable(false);
				}
			}

		});
		return selectDutyIdBox;
	}

	public JCheckBox creatselectStuNameBox() {
		if (selectTeacherNameBox == null) {
			selectTeacherNameBox = new JCheckBox("����������ѯ(��ģ����ѯ):");
		}
		selectTeacherNameBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectTeacherNameBox.isSelected()) {
					selectTeacherNameText.setEditable(true);
				} else {
					selectTeacherNameText.setText("");
					selectTeacherNameText.setEditable(false);
				}
			}

		});
		return selectTeacherNameBox;
	}

	

	public JCheckBox getSelectDutyIdBox() {
		return selectDutyIdBox;
	}

	public JCheckBox getSelectTeacherIdBox() {
		return selectTeacherIdBox;
	}

	public JCheckBox getSelectTeacherNameBox() {
		return selectTeacherNameBox;
	}


	public JTextField getSelectTeacherDutyText() {
		return selectTeacherDutyText;
	}

	public JTextField getSelectTeacherIdText() {
		return selectTeacherIdText;
	}

	public JTextField getSelectTeacherNameText() {
		return selectTeacherNameText;
	}

	public JDialog getDialog() {
		return dialog;
	}

}
