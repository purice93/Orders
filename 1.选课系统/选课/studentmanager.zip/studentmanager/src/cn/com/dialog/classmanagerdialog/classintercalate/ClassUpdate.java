package cn.com.dialog.classmanagerdialog.classintercalate;

import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cn.com.action.classmanageraction.classaddaction.ClassUpdateAction;
import cn.com.dao.classmanagerdao.Impl;
import cn.com.util.GBC;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassUpdate {
	public JDialog dialog;

	ActionListener action;

	JPanel p5;// ��ű���߿�

	JPanel p4;// ��ű��桢�˳���ť

	JLabel label = new JLabel("                   ");

	public static JComboBox c1;// ����ʱ��

	public static JComboBox c2;// ����ʱ��

	JComboBox c3;// �γ�״̬

	public static JComboBox c4;// �γ�״̬

	public static JTextField classID;// ��ʦ����

	public static JTextField classname, totaltime, credithour, classremake, teacherid;

	public JTextField teachername;

	public ClassUpdate() {
		BorderDemo();
		showInfo();
	}

	public JDialog buildDialog(String title) {
		if (dialog == null) {
			dialog = new JDialog();
			dialog.setTitle(title);
			BorderDemo();
			dialog.add(p4, "South");
			dialog.add(p5);
			dialog.setModal(true);
			dialog.setSize(600, 400);
			dialog.setLocationRelativeTo(null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			showClassInfo();

		}
		return dialog;
	}

	/**
	 * ��ѡ�����Ҫ�޸ĵĿγ���Ϣ��ʾ���޸������
	 */
	public void showClassInfo() {
		DefaultTableModel model = (DefaultTableModel) ClassIntercalate
				.buildJTable().getModel();
		int selectedRow = ClassIntercalate.buildJTable().getSelectedRow();
		if (selectedRow == -1) {
			JOptionPane.showMessageDialog(null, "��ѡ����Ҫ�޸ĵĿγ�", "�޸���ʾ��",
					JOptionPane.YES_NO_OPTION);
		} else {

			Object id = model.getValueAt(selectedRow, 0);
			Object name = model.getValueAt(selectedRow, 1);
			Object t_time = model.getValueAt(selectedRow, 2);
			Object c_hour = model.getValueAt(selectedRow, 4);
			Object remake = model.getValueAt(selectedRow, 9);
			Object estate = model.getValueAt(selectedRow, 5);
			Object t_id = model.getValueAt(selectedRow, 6);
			Object t_name = model.getValueAt(selectedRow, 7);
			// ���������ʽ���ַ����ָ�
			Object c_time = model.getValueAt(selectedRow, 3);
			String str = c_time.toString();
			Pattern p = null;
			p = Pattern.compile("-+");
			String[] a = p.split(str);
			classID.setText(id.toString());
			classname.setText(name.toString());
			totaltime.setText(t_time.toString());
			credithour.setText(c_hour.toString());
			classremake.setText(remake.toString());
			c4.setSelectedItem(t_id.toString());
			System.out.println(t_id.toString());
			teachername.setText(t_name.toString());
			c3.setSelectedItem(estate.toString());
			c1.setSelectedItem(a[0]);
			c2.setSelectedItem(a[1]);
			classID.setEditable(false);
			dialog.setVisible(true);
		}
	}

	/**
	 * ����߿�
	 * 
	 */
	public void BorderDemo() {
		p5 = new JPanel();
		p5.setLayout(new GridBagLayout());
		p5.setBorder(BorderFactory.createTitledBorder("�γ�����"));
		showInfo();
	}

	/**
	 * ���Ĳ���
	 * 
	 */
	public void showInfo() {
		p5.add(new JLabel("�γ̱�ţ�"), new GBC(0, 0).setFill(GBC.WEST));
		p5.add(classID = new JTextField(10), new GBC(1, 0).setInsets(7)
				.setFill(GBC.WEST));
		p5.add(new JLabel("�γ����ƣ�"), new GBC(2, 0).setFill(GBC.WEST));
		p5.add(classname = new JTextField(10), new GBC(3, 0).setInsets(7)
				.setFill(GBC.WEST));
		p5.add(new JLabel("����ʱ�䣺"), new GBC(0, 1).setFill(GBC.WEST));
		String[] str = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "1",
				"10", "11", "12", "1", "13", "14", "15", "16", "17", "18",
				"      " };
		p5.add(c1 = new JComboBox(str), new GBC(1, 1).setInsets(7).setFill(
				GBC.WEST));

		p5.add(new JLabel("����ʱ�䣺"), new GBC(2, 1).setFill(GBC.WEST));
		p5.add(c2 = new JComboBox(str), new GBC(3, 1).setInsets(7).setFill(
				GBC.WEST));

		p5.add(new JLabel("��ʱ��"), new GBC(0, 2).setFill(GBC.WEST));
		p5.add(totaltime = new JTextField(10), new GBC(1, 2).setInsets(7)
				.setFill(GBC.WEST));
		p5.add(new JLabel("ѧ�֣�"), new GBC(2, 2).setFill(GBC.WEST));
		p5.add(credithour = new JTextField(10), new GBC(3, 2).setInsets(7)
				.setFill(GBC.WEST));
		p5.add(new JLabel("�γ�״̬��"), new GBC(0, 3).setFill(GBC.WEST));
		String[] s = { "����", "ͣ��", "      " };
		p5.add(c3 = new JComboBox(s), new GBC(1, 3).setInsets(7).setFill(
				GBC.WEST));
		p5.add(new JLabel("��ע��"), new GBC(2, 3).setFill(GBC.WEST));
		p5.add(classremake = new JTextField(10), new GBC(3, 3).setInsets(7)
				.setFill(GBC.WEST));
		p5.add(new JLabel("ִ�̽�ʦ��ţ�"), new GBC(0, 4).setFill(GBC.WEST));
		p5.add(c4 = new JComboBox(), new GBC(1, 4).setInsets(GBC.WEST));
		Impl impl = new Impl();
		impl.findTeacherNo1();
//		c4.addItem("1");
//		c4.addItem("2");
//		c4.addItem("12");
//		c4.addItem("121");
		c4.addItem("      ");
		p5.add(teacherid = new JTextField(10), new GBC(1, 4)
				.setInsets(GBC.WEST));
		p5.add(new JLabel("ִ�̽�ʦ������"), new GBC(2, 4).setFill(GBC.WEST));
		p5.add(teachername = new JTextField(10), new GBC(3, 4).setInsets(7)
				.setFill(GBC.WEST));

		teachername.setEditable(false);
		c4.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String str = e.getActionCommand();
				String selectItem = c4.getSelectedItem().toString();
				if (selectItem != "      ") {
					int teacherNo = Integer.parseInt(selectItem);
					Impl impl = new Impl();
					teachername.setText(impl.findTeacherByNo(teacherNo));
				}

			}

		});
		p4 = new JPanel();
		p4.add(buildButton("�޸�"));
		p4.add(label);
		p4.add(buildButton("�˳�"));

	}

	public ClassVO getInputInfo() {
		/**
		 * int classID, String classname, String classestate, String
		 * teachername, int teacherID, String classtime, String totaltime, int
		 * credithour, String classremark
		 */
		int c_id = Integer.parseInt(classID.getText());
		String c_name = classname.getText();
		String c_time = (c1.getSelectedItem() + "-" + c2.getSelectedItem())
				.toString();
		String s = c4.getSelectedItem().toString();
//		if(s == "      "){
//		
//			s = "1";
//		}
		int t_id = Integer.parseInt(s);		
		String c_estate = c3.getSelectedItem().toString();
		int c_hour = Integer.parseInt(credithour.getText());
		String c_remake = classremake.getText();
		int total_time = Integer.parseInt(totaltime.getText());
		return new ClassVO(c_id, c_name, c_estate, t_id, c_time, total_time,
				c_hour, c_remake);
	}

	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new ClassUpdateAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new ClassUpdateAction(this);
		button.addActionListener(action);
		return button;
	}

}
