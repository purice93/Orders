package cn.com.dialog.classmanagerdialog.classmanager;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.com.dao.classmanagerdao.Impl;


public class ClassByTeacher extends JDialog{
	static JTable table = null;
	static ClassManager manager;
	
	public ClassByTeacher(){
		initalDialog();
	}

	private void initalDialog(){
		this.setSize(400,400);
		this.setLocationRelativeTo(null);
		this.add(buildScrollPane());
		this.setModal(true);
		this.setVisible(true);
	    this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
	}
	
   public JScrollPane buildScrollPane(){
	   JScrollPane scrollpane = new JScrollPane(buildTable());
	   return scrollpane;
   }
   
   public static JTable buildTable(){
	   if(table == null){ 
		   String[] str = {"�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬", "�γ̱�ע"};
		   Object[][]data = {};   
		   DefaultTableModel model = new DefaultTableModel(data,str);
		   table = new JTable(model);
	   }
	   return table;
   }
//   public static JTable buildTable(){
//	   if(table == null){ 
//		   String[] str = {"�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬", "�γ̱�ע"};
//		   Impl impl = new Impl();
//		   String num = manager.text.getText();
//		   int t_id = Integer.parseInt(num);
//		   Object[][]data = impl.ClassFindByTNo(t_id);
//		   DefaultTableModel model = new DefaultTableModel(data,str);
//		   table = new JTable(model);
//	   }
//	   return table;
//   }
}
