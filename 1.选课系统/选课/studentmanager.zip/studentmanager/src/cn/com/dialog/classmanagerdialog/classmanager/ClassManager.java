package cn.com.dialog.classmanagerdialog.classmanager;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cn.com.action.classmanageraction.ClassInfoAction;
import cn.com.util.GBC;
import cn.com.vo.classmanagervo.ClassStudentVo;

public class ClassManager {
   JDialog panel;

	JSplitPane splitPane = null;

	static JTable table;
	
	static JTable table1;

	ActionListener action;
	
	public JComboBox c;
	
	public static JTextField text;

	public static JLabel stu_name,// ѧ������
	                     stu_ID;// ѧ��

	public JLabel stu_sex,// ѧ���Ա�
			      qqNo,// qq����
			      stu_tel,// �绰����
			      stu_email,// ��������
			      grade,// �꼶
			      school,// ѧУ
			      speciality,// רҵ
			      g_No;// ���


	/**
	 * �������ģʽ������һ��Dialog
	 * 
	 * @param title����
	 * @return
	 */
	public JDialog buildPanel(String title) {
		if (panel == null) {
			initLabel();
			panel = new JDialog();
         
//			panel.setBorder(BorderFactory.createTitledBorder(title));
			panel.setTitle(title);
//         panel.setModal(true);
//         panel.setSize(1300, 800);
			panel.setSize(1000, 700);
			panel.add(MainPanel());
         panel.dispose();
         panel.setLocationRelativeTo(null);
         panel.setModal(true);
         panel.setVisible(true);

		}
		return panel;
	}

	/**
	 * ��ǩ�ĳ�ʼ��
	 * 
	 */
	private void initLabel() {
		stu_ID = new JLabel();
		stu_name = new JLabel();
		stu_sex = new JLabel();
		qqNo = new JLabel();
		stu_email = new JLabel();
		stu_tel = new JLabel();
		grade = new JLabel();
		school = new JLabel();
		speciality = new JLabel();
		g_No = new JLabel();
	}

	/**
	 * ��ǩ�õ��Ӵ����ݿ��д�����������Ϣ
	 * 
	 * @param vo
	 */

	public void getLabelInfo(ClassStudentVo vo) {
		stu_ID.setText(Integer.toString(vo.getStu_ID()));
		stu_name.setText(vo.getStu_name());
		stu_sex.setText(vo.getStu_sex());
		qqNo.setText(Integer.toString(vo.getQqNo()));
		stu_tel.setText(Integer.toString(vo.getStu_tel()));
		stu_email.setText(vo.getStu_email());
		grade.setText(vo.getGrade());
		school.setText(vo.getSchool());
		speciality.setText(vo.getSpeciality());
		g_No.setText(Integer.toString(vo.getG_No()));
	}

	/**
	 * ����������ʾ�γ̱���Ϣ
	 * 
	 * @return
	 */
	private JPanel getPanel1() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.add(new JLabel("ѧ��ѧ�ţ�"), new GBC(0, 0).setFill(GBC.WEST));
		panel.add(stu_ID, new GBC(1, 0).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("ѧ  У��"), new GBC(2, 0).setFill(GBC.WEST));
		panel.add(school, new GBC(3, 0).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("���ڵ���ţ�"), new GBC(4, 0).setFill(GBC.WEST));
		panel.add(g_No, new GBC(5, 0).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("ѧ��������"), new GBC(0, 1).setFill(GBC.WEST));
		panel.add(stu_name, new GBC(1, 1).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("��  ����"), new GBC(2, 1).setFill(GBC.WEST));
		panel.add(grade, new GBC(3, 1).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("�绰���룺"), new GBC(4, 1).setFill(GBC.WEST));
		panel.add(stu_tel, new GBC(5, 1).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("��  ��"), new GBC(0, 2).setFill(GBC.WEST));
		panel.add(stu_sex, new GBC(1, 2).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("ר  ҵ��"), new GBC(2, 2).setFill(GBC.WEST));
		panel.add(speciality, new GBC(3, 2).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("QQ ���룺"), new GBC(4, 2).setFill(GBC.WEST));
		panel.add(qqNo, new GBC(5, 2).setInsets(4).setWeight(8, 0));
		panel.add(new JLabel("e_mail��"), new GBC(0, 4).setFill(GBC.WEST));
		panel.add(stu_email, new GBC(1, 4).setInsets(14).setWeight(8, 0));

		panel
				.add(
						new JLabel(
								"-------------------------------"),
						new GBC(0, 3).setFill(GBC.WEST));
		return panel;

	}

	/**
	 * ������ѯ�����
	 * 
	 * @return
	 */

	public JPanel getPanel2() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new FlowLayout(FlowLayout.CENTER));
		String[] str = { "  ѧ��  ", "  ��ʦ  " };
//		Box box = new Box(BoxLayout.X_AXIS);
//		box.add(Box.createHorizontalStrut(15));
		panel.add(new JLabel("�������ţ�"));
		panel.add(text = new JTextField(10));
		panel.add(new JLabel("   "));
		panel.add(c = new JComboBox(str));
		panel.add(new JLabel("   "));
		panel.add(buildButton("  ��ѯ  "));
		panel.add(new JLabel("   "));
		panel.add(buildButton("����γ�"));
		
//		panel.add(Box.createHorizontalStrut(15), new GBC(0, 0).setInsets(5)
//				.setWeight(0, 0).setFill(GBC.WEST));
//		panel.add(new JLabel("�������ţ�"), new GBC(1, 0, 2, 1)
//				.setFill(GBC.HORIZONTAL));
//		panel.add(text = new JTextField(10), new GBC(3, 0, 1, 1).setInsets(0).setWeight(
//				3, 0).setFill(GBC.WEST));
//	
//		panel.add(c = new JComboBox(str), new GBC(5, 0)
//						.setFill(GBC.WEST));
//		panel.add(buildButton("��ѯ"), new GBC(6, 0).setInsets(20)
//				.setWeight(0, 0).setFill(GBC.WEST));
//		panel.add(buildButton("���ȫ���γ�"), new GBC(7, 0).setInsets(20).setWeight(
//				0, 0).setFill(GBC.WEST));
//		panel.add(box);
		return panel;
	}

	/**
	 * ��ÿγ�ͳ������
	 * 
	 * @return
	 */
	public JTabbedPane getClassstatInfo() {
		JTabbedPane pane = new JTabbedPane();
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
		panel1.setLayout(new BorderLayout());
//		Box box = new Box(BoxLayout.X_AXIS);
//		box.add(Box.createHorizontalStrut(400));
		panel2.add(buildButton("ѧ��ѡ��"));
		panel2.add(buildButton("�γ�ע��"));
		panel2.add(buildButton("�ϿεǼ�"));
		panel1.add(panel2, "North");
		panel1.add(getJScrollPane());
		pane.add("ѧ���γ�ͳ��", panel1);
		return pane;
	}

	/**
	 * ����ϿεǼ�����
	 * 
	 * @return
	 */
	public JTabbedPane getClassstatInfo1() {
		JTabbedPane pane = new JTabbedPane();
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
		panel1.setLayout(new BorderLayout());
//		Box box = new Box(BoxLayout.X_AXIS);
//		box.add(Box.createHorizontalStrut(10));
		
//		JLabel label1 = new JLabel("            ");
//		JLabel label2 = new JLabel("            ");
		panel2.add(buildButton("���ڲ�ѯ"));
//		panel2.add(label1);
//		panel2.add(label2);
		panel1.add(panel2, "North");
		panel1.add(getJScrollPane1());
		pane.add("ѧ���ϿεǼ�", panel1);
		return pane;
	}

	/**
	 * ����������panel���
	 * 
	 * @return
	 */
	public JSplitPane buildSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setOneTouchExpandable(true);
			splitPane.setLeftComponent(getClassstatInfo());
			splitPane.setRightComponent(getClassstatInfo1());
			splitPane.setDividerLocation(750);

		}
		return splitPane;
	}

	public JPanel MainPanel() {
		JPanel panel1 = new JPanel(new BorderLayout());
		JPanel panel2 = new JPanel(new BorderLayout());
		panel2.add(getPanel2(), "North");
		panel2.add(getPanel1(), "Center");
		panel1.add(panel2, "North");
		panel1.add(buildSplitPane());

		return panel1;
	}

	public JScrollPane getJScrollPane() {
		JScrollPane scrollpane = new JScrollPane(buildJTable());

		return scrollpane;
	}
	public JScrollPane getJScrollPane1() {
		JScrollPane scrollpane = new JScrollPane(buildJTable1());
		
		return scrollpane;
	}

	/**
	 * ���������
	 * 
	 * @return
	 */
	public JTable buildJTable() {
		 String[] str = { "�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬",
				"ִ����ʦ���", "ִ����ʦ����", "ְ��", "�γ̱�ע" };
		if (table == null) {
			Object[][] data = {};
			DefaultTableModel model = new DefaultTableModel(data, str);
			table = new JTable(model);
			table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		}
		return table;
	}

	public  JTable buildJTable1() {
		String[] str1 = { "�γ̱��", "�γ�����","�ǼǴ���" };
		if (table1 == null) {
			Object[][] data = {};
			DefaultTableModel model = new DefaultTableModel(data, str1);
			table1 = new JTable(model);
		}
		return table1;
	}

	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new ClassInfoAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new ClassInfoAction(this);
		button.addActionListener(action);
		return button;
	}

}
