package cn.com.dialog.studentmanagerdialog;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.dao.studentmanagerdao.StudentDao;
import cn.com.vo.studentmanagervo.StudentVo;

/**
 * �޸�ѧ����Ϣ����
 * 
 * @author
 * 
 * 
 */

public class StudentUpdateDialog implements ActionListener {

	private JDialog jd;// �޸�ѧ����Ϣ

	private JPanel north;

	private JPanel south;

	private JPanel jp3;

	private Choice sex;

	private JLabel s_id;// ѧ��ID

	private JLabel g_id;// ��ID

	private JLabel s_name;// ѧ������

	private JLabel s_sex;// ѧ���Ա�

	private JLabel s_grade;// ѧ�������꼶

	private JLabel s_school;// ѧ������ѧУ

	private JLabel s_professional;// ѧ����ѧרҵ

	private JLabel s_tel;// ѧ����ϵ����(�ֻ�����)

	private JLabel s_qq;// ѧ��QQ����

	private JLabel s_email;// ѧ�������ʼ�

	private JTextField jtf1;// ��s_id ����

	private JTextField jtf2;// ��g_id����

	private JTextField jtf3;// ��s_name����

	private JTextField jtf5;// ����s_tel����

	private JTextField jtf6;// ��s_qq����

	private JTextField jtf7;// ��s_emali����

	private JTextField grade;// �꼶

	private JTextField school;// ѧУ

	private JTextField professional;// רҵ

	private JButton save;// ����

	private JButton reset;// ����

	private JButton exit;// �˳�

	private StudentVo studentVo;

	public StudentUpdateDialog(StudentVo studentVo) {
		this.studentVo = studentVo;
	}

	public JDialog updatestudent() {

		sex = new Choice();
		sex.add("��");
		sex.add("Ů");
		if (studentVo.getS_sex().equals("��")) {
			sex.select(0);
		} else {
			sex.select(1);
		}

		jd = new JDialog();

		north = new JPanel(new GridLayout(5, 4, 5, 5));

		south = new TJPanel();

		jp3 = new TJPanel();

		s_id = new JLabel("ѧ��ID", JLabel.CENTER);

		g_id = new JLabel("��ID", JLabel.CENTER);

		s_name = new JLabel("ѧ������", JLabel.CENTER);

		s_sex = new JLabel("ѧ���Ա�", JLabel.CENTER);

		s_grade = new JLabel("ѧ�������꼶", JLabel.CENTER);

		s_school = new JLabel("ѧ������ѧУ", JLabel.CENTER);

		s_professional = new JLabel("ѧ����ѧרҵ", JLabel.CENTER);

		s_tel = new JLabel("ѧ����ϵ����", JLabel.CENTER);

		s_qq = new JLabel("ѧ��QQ����", JLabel.CENTER);

		s_email = new JLabel("ѧ�������ʼ�", JLabel.CENTER);

		jtf1 = new JTextField(10);
		jtf2 = new JTextField(10);
		jtf3 = new JTextField(10);
		jtf5 = new JTextField(10);
		jtf6 = new JTextField(10);
		jtf7 = new JTextField(10);
		jtf7 = new JTextField(10);
		grade = new JTextField(10);
		school = new JTextField(10);
		professional = new JTextField(10);
		jtf1.setText(Integer.toString(studentVo.getS_id()));
		jtf1.setEditable(false);
		jtf2.setText(Integer.toString(studentVo.getG_id()));
		jtf3.setText(studentVo.getS_name());
		jtf5.setText(Long.toString(studentVo.getS_tel()));
		jtf6.setText(Long.toString(studentVo.getS_qq()));
		jtf7.setText(studentVo.getS_emali());
		grade.setText(studentVo.getS_grade());
		school.setText(studentVo.getS_school());
		professional.setText(studentVo.getS_professional());

		save = new JButton("����");
		reset = new JButton("�� ��");
		exit = new JButton("�� ��");

		north.add(s_id);
		north.add(jtf1);

		north.add(g_id);
		north.add(jtf2);

		north.add(s_name);
		north.add(jtf3);

		north.add(s_sex);
		north.add(sex);

		north.add(s_grade);
		north.add(grade);

		north.add(s_school);
		north.add(school);

		north.add(s_professional);
		north.add(professional);

		north.add(s_tel);
		north.add(jtf5);

		north.add(s_qq);
		north.add(jtf6);

		north.add(s_email);
		north.add(jtf7);
		jp3.setBorder(BorderFactory.createTitledBorder("��ť��"));
		jp3.add(save);
		jp3.add(reset);
		jp3.add(exit);

		jd.add(north, "North");
		jd.add(jp3, "Center");
		// ///////////////////////////////////////////////
		// /���޸�
		jd.setSize(500, 230);
		// //////////////////////////////////////
		jd.setLocationRelativeTo(null);
		jd.setVisible(true);

		save.addActionListener(this);
		reset.addActionListener(this);
		exit.addActionListener(this);
		return jd;
	}

	public void actionPerformed(ActionEvent arg0) {
		StudentVo s = new StudentVo();
		String str = arg0.getActionCommand();
		if (arg0.getSource() == save) {
			try {
				if (!jtf1.getText().equals("") && !jtf2.getText().equals("")
						&& !jtf3.getText().equals("")
						&& !grade.getText().equals("")
						&& !school.getText().equals("")
						&& !professional.getText().equals("")
						&& !jtf5.getText().equals("")
						&& !jtf6.getText().equals("")
						&& !jtf7.getText().equals("")) {
					s.setS_id(Integer.parseInt(jtf1.getText()));
					s.setG_id(Integer.parseInt(jtf2.getText()));
					s.setS_name((jtf3.getText()));
					s.setS_sex(sex.getSelectedItem());
					s.setS_grade(grade.getText());
					s.setS_school(school.getText());
					s.setS_professional(professional.getText());
					// ///////////////
					s.setS_tel(Long.parseLong(jtf5.getText()));
					s.setS_qq(Long.parseLong(jtf6.getText()));
					s.setS_emali(jtf7.getText());
					// //////////////////
					StudentDao studentdao = new StudentDao(s);
					studentdao.updateInfo();
					javax.swing.JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
					jd.dispose();
				} else {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��ѡ��Ϊ�գ��뷵��������д��");
				}
			} catch (NumberFormatException ex) {
				javax.swing.JOptionPane.showMessageDialog(null, "��������ȷ���ַ���ʽ��");
			}
		} else if (str.equals("�� ��")) {
			jtf2.setText("");
			jtf3.setText("");
			sex.select(0);
			jtf5.setText("");
			jtf6.setText("");
			jtf7.setText("");
			grade.setText("");
			school.setText("");
			professional.setText("");

		} else if (str.equals("�� ��")) {
			jd.dispose();
		}
	}

	class TJPanel extends JPanel {
		ImageIcon icon;

		public TJPanel() {

			icon = new ImageIcon("image/addstudent.jpg");
			this.setSize(icon.getIconWidth(), icon.getIconHeight());
		}

		@Override
		/**
		 * ��дpaintComponent,JP1,����
		 */
		protected void paintComponent(Graphics arg0) {
			super.paintComponent(arg0);
			Image i = icon.getImage();
			arg0.drawImage(i, 0, 0, this);
		}

	}
}
