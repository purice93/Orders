package cn.com.dialog.classmanagerdialog.classintercalate;

import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.action.classmanageraction.classaddaction.ClassIntercalateAddAction;
import cn.com.dao.classmanagerdao.Impl;
import cn.com.util.GBC;
import cn.com.vo.classmanagervo.ClassVO;


public class ClassIntercalateAdd {
	public JDialog dialog;
	
	ActionListener action;

	JPanel p5;// ��ű���߿�

	JPanel p4;// ��ű��桢�˳���ť

	JLabel label = new JLabel("                   ");

	public static JComboBox c1;// ����ʱ��

	public static JComboBox c2;// ����ʱ��

	public static JComboBox c3;// �γ�״̬
	
	public static JComboBox c4;// ��ʦ���

	public static JTextField classID;// �γ̱��

	public static JTextField classname, totaltime, credithour, classremake, teacherid;
	public static JTextField teachername;// ��ʦ����

	public ClassIntercalateAdd(){
		BorderDemo();
		showInfo();
	}
	public JDialog buildDialog(String title) {
		if (dialog == null) {
			dialog = new JDialog();
			dialog.setName(title);
			BorderDemo();
			dialog.add(p4, "South");
			dialog.add(p5);
			dialog.setModal(true);
			dialog.setSize(600, 400);
			dialog.setLocationRelativeTo(null);
			dialog.setVisible(true);
			dialog.dispose();
		}
		return dialog;
	}

	/**
	 * ����߿�
	 * 
	 */
	public void BorderDemo() {
		p5 = new JPanel();
		p5.setLayout(new GridBagLayout());
		p5.setBorder(BorderFactory.createTitledBorder("�γ�����"));
		showInfo();
	}

	/**
	 * ���Ĳ���
	 * 
	 */
		public void showInfo() {
			p5.add(new JLabel("�γ̱�ţ�"), new GBC(0, 0).setFill(GBC.WEST));
			p5.add(classID = new JTextField(10), new GBC(1, 0).setInsets(7)
					.setFill(GBC.WEST));
			p5.add(new JLabel("�γ����ƣ�"), new GBC(2, 0).setFill(GBC.WEST));
			p5.add(classname = new JTextField(10), new GBC(3, 0).setInsets(7)
					.setFill(GBC.WEST));
			p5.add(new JLabel("����ʱ�䣺"), new GBC(0, 1).setFill(GBC.WEST));
			String[] str = {"1","2","3","4","5","6","7","8","9","1","10","11","12","1","13","14","15",
					"16","17","18","      "};
			p5.add(c1 = new JComboBox(str), new GBC(1, 1).setInsets(7).setFill(GBC.WEST));
			
			
			p5.add(new JLabel("����ʱ�䣺"), new GBC(2, 1).setFill(GBC.WEST));
			p5.add(c2 = new JComboBox(str), new GBC(3, 1).setInsets(7).setFill(GBC.WEST));
			
			p5.add(new JLabel("��ʱ��"), new GBC(0, 2).setFill(GBC.WEST));
			p5.add(totaltime = new JTextField(10), new GBC(1, 2).setInsets(7)
					.setFill(GBC.WEST));
			p5.add(new JLabel("ѧ�֣�"), new GBC(2, 2).setFill(GBC.WEST));
			p5.add(credithour = new JTextField(10), new GBC(3, 2).setInsets(7)
					.setFill(GBC.WEST));
			p5.add(new JLabel("�γ�״̬��"), new GBC(0, 3).setFill(GBC.WEST));
			String[] s = {"����","ͣ��","      "};
			p5.add(c3 = new JComboBox(s), new GBC(1, 3).setInsets(7).setFill(GBC.WEST));
			p5.add(new JLabel("��ע��"), new GBC(2, 3).setFill(GBC.WEST));
			p5.add(classremake = new JTextField(10), new GBC(3, 3).setInsets(7)
					.setFill(GBC.WEST));
			p5.add(new JLabel("ִ�̽�ʦ��ţ�"), new GBC(0, 4).setFill(GBC.WEST));
			p5.add(c4 = new JComboBox(), new GBC(1, 4)
					.setInsets(GBC.WEST));
			Impl impl = new Impl();
			impl.findTeacherNo();
			c4.addItem("      ");
			p5.add(new JLabel("ִ�̽�ʦ������"), new GBC(2, 4).setFill(GBC.WEST));
			p5.add(teachername = new JTextField(10), new GBC(3, 4).setInsets(7)
					.setFill(GBC.WEST));
			teachername.setEditable(false);
			c4.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent e) {
					String str = e.getActionCommand();
					String selectItem = c4.getSelectedItem().toString();
					if(selectItem !="      "){
					int teacherNo = Integer.parseInt(selectItem);
					Impl impl = new Impl();
					teachername.setText(impl.findTeacherByNo(teacherNo));
					}
					
				}
				
			});
			p4 = new JPanel();
			p4.add(buildButton("����"));
			p4.add(label);
			p4.add(buildButton("�˳�"));
		
//		teacherid.addMouseListener(new MouseAdapter(){
//			String str;
//			public void mouseClicked(MouseEvent e) {
//				// TODO Auto-generated method stub
//				str = teacherid.getText();	
//				System.out.println("�����"+str);
//				if(str.equals("")){
//					
//				}else{
//				teachername.setText(Impl.findTeacherByNo(Integer.parseInt(str)));
//				}
//			}
//		});

	}

	public ClassVO getInputInfo() {
		int c_id = Integer.parseInt(classID.getText());
		String c_name = classname.getText();
		String c_time = (c1.getSelectedItem() + "-" + c2.getSelectedItem())
				.toString();
		String t_name = teachername.getText();
		int t_id = Integer.parseInt(c4.getSelectedItem().toString());
		String c_estate = c3.getSelectedItem().toString();
		int c_hour = Integer.parseInt(credithour.getText());
		String c_remake = classremake.getText();
		int total_time = Integer.parseInt(totaltime.getText());
		return new ClassVO(c_id, c_name, c_estate, t_name, t_id, c_time,
				total_time, c_hour, c_remake);
	}

	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new ClassIntercalateAddAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new ClassIntercalateAddAction(this);
		button.addActionListener(action);
		return button;
	}

}
