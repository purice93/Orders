package cn.com.dialog.chivementdialog;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.action.chivementaction.ExamHighSelectPanelAction;
import cn.com.panel.chivementpanel.ExamPanel;

public class ExamHighSelectDialog {
	private JDialog dialog;
	
	private ExamPanel chivementPanel;
	
	private JTextField selectClassText;
	
	private JTextField selectStuIdText;
	
	private JTextField selectGroupIdText;
	
	private JTextField selectStuNameText;
	
	private JTextField selectClassNameText;
	
	private JCheckBox selectClassBox;
	
	private JCheckBox selectStuIdBox;
	
	private JCheckBox selectGroupIdBox;
	
	private JCheckBox selectStuNameBox;
	
	private JCheckBox selectClassNameBox;
	
	private JButton enterbutton;
	
	private JButton exitbutton;
	
	public ExamHighSelectDialog(ExamPanel chivementPanel) {
		super();
		this.chivementPanel = chivementPanel;
	}

	public JDialog CreatHighSelectDialog() {
		if (dialog == null) {
			dialog = new JDialog();
			dialog.add(HighSelectPanel());
//			dialog.setSize(500, 500);
			dialog.setModal(true);
			dialog.pack();
			dialog.setLocationRelativeTo(null);
			return dialog;
		}
		return null;
	}
	

	public JPanel HighSelectPanel() {
		JPanel panel = new JPanel();
		initTxt();
		panel.setLayout(new BorderLayout());
		panel.add(CreatSelectPanel(), "Center");
		panel.add(CreatButtonPanel(), "South");
		panel.setBorder(BorderFactory.createTitledBorder("��ѡ���ѯ����:"));
		return panel;
	}

	public JPanel CreatSelectPanel() {
		JPanel panel = new JPanel();

		panel.setLayout(new GridLayout(5, 2));
		panel.add(this.creatselectAllBox());
		panel.add(this.selectClassText);
		panel.add(this.creatselectstuIdBox());
		panel.add(this.selectStuIdText);
		panel.add(this.creatselectGroupIdBox());
		panel.add(this.selectGroupIdText);
		panel.add(this.creatselectStuNameBox());
		panel.add(this.selectStuNameText);
		panel.add(this.creatselectClassNameBox());
		panel.add(this.selectClassNameText);
		return panel;

	}

	public JPanel CreatButtonPanel() {
		JPanel panel = new JPanel();
		panel.add(creatBtn("�ύ"));
		panel.add(creatBtn("ȡ��"));
		return panel;
	}

	public void initTxt() {
		selectClassText = creatTextField(selectClassText);
		selectStuIdText = creatTextField(selectStuIdText);
		selectGroupIdText = creatTextField(selectGroupIdText);
		selectStuNameText = creatTextField(selectStuNameText);
		selectClassNameText = creatTextField(selectClassNameText);
	}

	public JTextField creatTextField(JTextField textfield) {
		textfield = new JTextField(8);
		textfield.setEditable(false);
		return textfield;
	}

	public JButton creatBtn(String name) {
		JButton btn = new JButton(name);
		ExamHighSelectPanelAction action = new ExamHighSelectPanelAction(this,chivementPanel);
		btn.addActionListener(action);
		return btn;
	}

	public JCheckBox creatselectAllBox() {
		if (selectClassBox == null) {
			selectClassBox = new JCheckBox("���ݿγ̱�Ų�ѯѧ���ɼ�:");
		}
		selectClassBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectClassBox.isSelected()) {
					selectClassText.setEditable(true);
				} else {
					selectClassText.setText("");
					selectClassText.setEditable(false);
				}
			}

		});
		return selectClassBox;
	}

	public JCheckBox creatselectstuIdBox() {
		if (selectStuIdBox == null) {
			selectStuIdBox = new JCheckBox("����ѧ�Ų�ѯѧ���ɼ�:");
		}
		selectStuIdBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectStuIdBox.isSelected()) {
					selectStuIdText.setEditable(true);
				} else {
					selectStuIdText.setText("");
					selectStuIdText.setEditable(false);
				}
			}

		});
		return selectStuIdBox;
	}

	public JCheckBox creatselectGroupIdBox() {
		if (selectGroupIdBox == null) {
			selectGroupIdBox = new JCheckBox("������Ų�ѯѧ���ɼ�:");
		}
		selectGroupIdBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectGroupIdBox.isSelected()) {
					selectGroupIdText.setEditable(true);
				} else {
					selectGroupIdText.setText("");
					selectGroupIdText.setEditable(false);
				}
			}

		});
		return selectGroupIdBox;
	}

	public JCheckBox creatselectStuNameBox() {
		if (selectStuNameBox == null) {
			selectStuNameBox = new JCheckBox("����������ѯѧ���ɼ�(��ģ����ѯ):");
		}
		selectStuNameBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectStuNameBox.isSelected()) {
					selectStuNameText.setEditable(true);
				} else {
					selectStuNameText.setText("");
					selectStuNameText.setEditable(false);
				}
			}

		});
		return selectStuNameBox;
	}

	public JCheckBox creatselectClassNameBox() {
		if (selectClassNameBox == null) {
			selectClassNameBox = new JCheckBox("���ݿγ����Ʋ�ѯ�ɼ�(��ģ����ѯ):");
		}
		selectClassNameBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (selectClassNameBox.isSelected()) {
					selectClassNameText.setEditable(true);
				} else {
					selectClassNameText.setText("");
					selectClassNameText.setEditable(false);
				}
			}

		});
		return selectClassNameBox;
	}
	
	public JCheckBox getSelectClassBox() {
		return selectClassBox;
	}

	public JCheckBox getSelectClassNameBox() {
		return selectClassNameBox;
	}

	public JCheckBox getSelectGroupIdBox() {
		return selectGroupIdBox;
	}

	public JCheckBox getSelectStuIdBox() {
		return selectStuIdBox;
	}

	public JCheckBox getSelectStuNameBox() {
		return selectStuNameBox;
	}

	public JTextField getSelectClassText() {
		return selectClassText;
	}

	public JTextField getSelectClassNameText() {
		return selectClassNameText;
	}

	public JTextField getSelectGroupIdText() {
		return selectGroupIdText;
	}

	public JTextField getSelectStuIdText() {
		return selectStuIdText;
	}

	public JTextField getSelectStuNameText() {
		return selectStuNameText;
	}

	public JDialog getDialog() {
		return dialog;
	}

}
