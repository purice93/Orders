package cn.com.dialog;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AboutUsDialog {
	private JButton tijiao;

	private JDialog dialog;

	public JDialog CreatAbout() {
		if (dialog == null) {
			dialog = new JDialog();
			dialog.setTitle("��������");
			dialog.setSize(500, 300);
			dialog.setLocationRelativeTo(null);
			dialog.setVisible(true);
			return dialog;
		}
		return null;
	}

	public JPanel CreatSouth() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(2,1));
		panel.add(new JLabel("",JLabel.CENTER));
		panel.add(new JLabel("",JLabel.CENTER));
		return panel;
	}

	public JButton CreatButton() {
		if (tijiao == null) {
			JButton tijiao = new JButton("�ύ");
			tijiao.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dialog.dispose();
				}

			});
			return tijiao;
		}
		return null;
	}
}
