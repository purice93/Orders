package cn.com.dialog.classmanagerdialog.classmanager;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cn.com.action.classmanageraction.classaddaction.ClassAddAction;
import cn.com.util.GBC;

public class ClassAdd {
	public JDialog dialog;
	ClassManager manager;
	ActionListener action;
	JPanel p5;//���ñ߿�
	public static JTextField text;//��ѧ��ѧ��
	public static JLabel label;//ѧ������
	JTable table;
	/**
	 * ����һ�����ӿγ̵�Dialog
	 * @param title
	 * @return
	 */
	public JDialog buildDialog(String title){
		if(dialog == null){
			dialog = new JDialog();
			dialog.setName(title);
			dialog.setSize(900,600);
			dialog.setModal(true);
			dialog.setLocationRelativeTo(null);
			BorderDemo();
			dialog.add(getClassInfo());
			dialog.add(getLabel(),"South");
			dialog.setVisible(true);
			dialog.dispose();
		}
		return dialog;
	}
	/**
	 * ���ñ߿�
	 *
	 */
	public void BorderDemo(){
	    p5 = new JPanel();
	    p5.setLayout(new GridBagLayout());
		p5.setBorder(BorderFactory.createTitledBorder("�γ�����"));
		addInfo();
//		this.add(p4,"South");
		dialog.setLayout(new BorderLayout());
		dialog.add(p5,"North");
	}
	
	/**
	 * ��ñ�ѡѧ����ѧ�ź�����
	 *
	 */
	public void addInfo(){
		p5.add(new JLabel("ѧ��ѧ�ţ�"),new GBC(0,0).setFill(GBC.WEST));
		p5.add(text = new JTextField(10),new GBC(2,0).setInsets(14).setFill(GBC.WEST));
		p5.add(new JLabel("ѧ��������"),new GBC(4,0).setFill(GBC.WEST));
		p5.add(label = new JLabel(),new GBC(6,0).setInsets(14).setFill(GBC.WEST));
		text.setEditable(false);
	    text.setText(manager.stu_ID.getText());
		label.setText(manager.stu_name.getText());
		
	}
	
	/**
	 * ����ѡ��γ̵�JTabbedPane���
	 * @return
	 */
	public JTabbedPane getClassInfo(){
		JTabbedPane pane = new JTabbedPane();
		JPanel panel1 = new JPanel();
		panel1.setLayout(new BorderLayout());
		panel1.add(getJScrollPane());
		pane.add("ѡ��γ�", panel1);
		return pane;
	}
	
	public JScrollPane getJScrollPane() {
		JScrollPane scrollpane = new JScrollPane(buildJTable());
		
		return scrollpane;
	}

	/**
	 * ���������
	 * 
	 * @return
	 */
	public  JTable buildJTable() {
		 String[] str = { "�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬",
				"ִ����ʦ���", "ִ����ʦ����", "ְ��", "�γ̱�ע" };
		if (table == null) {
			Object[][] data = {};
			DefaultTableModel model = new DefaultTableModel(data, str);
			table = new JTable(model);
		}
		return table;
	}
	
	/**
	 * ͳ��ѡ��
	 * @return
	 */
	public JPanel getLabel(){
		JPanel panel = new JPanel();
		panel.add(buildButton("����"));
		panel.add(buildButton("�˳�"));
	    return panel;
	}
	
	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new ClassAddAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new ClassAddAction(this);
		button.addActionListener(action);
		return button;
	}
//	public static void main(String[] args){
//		 ClassAdd t = new ClassAdd();
//		 t.buildDialog("���ӿγ�");
//	}

}
