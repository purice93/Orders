package cn.com.dialog.classmanagerdialog.classintercalate;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cn.com.action.classmanageraction.IntercalateAction;
import cn.com.dao.classmanagerdao.Impl;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassIntercalate {
	public JPanel jpanel;// �γ����õĶԻ���

	ActionListener action;

	static Impl impl;

	JPanel panel1;// �������ӡ��޸ġ�ɾ�����˳���ť

	JPanel panel3;// ����ѡ�α�

	static JTable table;

	static String[] str = { "�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬", "ִ����ʦ���",
			"ִ����ʦ����", "ְ��","�γ̱�ע"};

	public JPanel buildDialog(String title) {
		if (jpanel == null) {
			jpanel = new JPanel();
			jpanel.setBorder(BorderFactory.createTitledBorder(title));
//			dialog.setName(title);
			jpanel.setLayout(new BorderLayout());
			panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
			panel1.add(buildButton("���ӿγ�"));
			panel1.add(buildButton("�޸Ŀγ�"));
			panel1.add(buildButton("ɾ���γ�"));
			jpanel.add(panel1, "North");
			jpanel.add(getJScrollPane(), "Center");
//			jpanel.setModal(true);
//			jpanel.setSize(900, 600);
//			dialog.setSize(900, 600);
//			dialog.setLocationRelativeTo(null);
//			dialog.setVisible(true);
//			dialog.dispose();
		}
		return jpanel;
	}

	public JScrollPane getJScrollPane() {
		JScrollPane scrollpane = new JScrollPane(buildJTable());

		return scrollpane;
	}

	/**
	 * ���������
	 * 
	 * @return
	 */
	public static JTable buildJTable() {
		if (table == null) {
			impl = new Impl();
			Object[][] data = impl.getClassInfo();
			DefaultTableModel model = new DefaultTableModel(data, str);
			table = new JTable(model);
		}
		return table;
	}

	public static ClassVO getInputInfo(ResultSet set) throws SQLException {
		ClassVO vo = null;
		/**
		 * "�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬", "ִ����ʦ���", "ִ����ʦ����",
		 * "ְ��"����
		 * 
		 */
		// ����¼ӵĿγ̱��
		while(set.next()){
		int c_id = set.getInt(1);
		String c_name = set.getString(2);
		int c_total = set.getInt(3);
		String c_time = set.getString(4);
		int credithour = set.getInt(5);
		String c_estate = set.getString(6);
		int t_id = set.getInt(7);
		String t_name = set.getString(8);
		String t_duty = set.getString(9);
		String t_remake = set.getString(10);
		 vo = new ClassVO(c_id, c_name, c_total, c_time, credithour, c_estate,
				t_id, t_name, t_duty,t_remake);
		}
		return vo;

	}

	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new IntercalateAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new IntercalateAction(this);
		button.addActionListener(action);
		return button;
	}

	public static void main(String[] agrs) {
		ClassIntercalate t = new ClassIntercalate();
		t.buildDialog("���ӿγ�");
	}

}
