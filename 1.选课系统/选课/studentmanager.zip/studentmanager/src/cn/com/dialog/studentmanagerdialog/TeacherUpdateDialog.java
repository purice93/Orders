package cn.com.dialog.studentmanagerdialog;

import java.awt.Choice;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.dao.studentmanagerdao.TeacherDao;
import cn.com.vo.studentmanagervo.TeacherVo;

/**
 * �޸�ѧ����Ϣ����
 * 
 * @author
 * 
 * 
 */

public class TeacherUpdateDialog implements ActionListener {
	private JDialog updateeacher;// �޸���ʦ��Ϣ�Ի���

	private Choice tsex, tduty;// ��ʦ�Ա�ְ��

	private JLabel t_id, t_name, t_sex, t_age, t_duty, t_tel, t_qq, t_email;// 8����Ӧ��ǩ

	private JButton submit,// �ύ
			reset,// ����
			cancel;// ȡ��

	private JTextField tid, tname, tage, ttel, tqq, ttemail;

	private JPanel north, south;

	private TeacherVo teacherVo;

	public TeacherUpdateDialog(TeacherVo teacherVo) {
		this.teacherVo = teacherVo;
	}

	// /**
	// * ��ʼ��
	// *
	// */
	public JDialog init() {

		// ��������
		updateeacher = new JDialog();
		north = new JPanel(new GridLayout(4, 4, 5, 5));
		south = new JPanel();
		tsex = new Choice();
		tduty = new Choice();
		tsex.add("��");
		tsex.add("Ů");
		if (teacherVo.getT_sex().equals("��")) {
			tsex.select(0);
		} else {
			tsex.select(1);
		}

		tduty.add("��ѧ");
		tduty.add("����");
		if (teacherVo.getT_sex().equals("��ѧ")) {
			tduty.select(0);
		} else {
			tduty.select(1);
		}
		t_id = new JLabel("��ʦID", JLabel.CENTER);
		t_name = new JLabel("��ʦ����", JLabel.CENTER);
		t_sex = new JLabel("��ʦ�Ա�", JLabel.CENTER);
		t_age = new JLabel("��ʦ����", JLabel.CENTER);
		t_duty = new JLabel("��ʦְ��", JLabel.CENTER);
		t_tel = new JLabel("��ʦ����", JLabel.CENTER);
		t_qq = new JLabel("��ʦQQ", JLabel.CENTER);

		submit = new JButton("�ύ");
		reset = new JButton("����");
		cancel = new JButton("ȡ��");

		tid = new JTextField(10);
		tname = new JTextField(10);
		tage = new JTextField(10);
		ttel = new JTextField(10);
		tqq = new JTextField(10);
		ttemail = new JTextField(10);

		tid.setText(Integer.toString(teacherVo.getT_id()));
		tname.setText(teacherVo.getT_name());
		tage.setText(Integer.toString(teacherVo.getT_age()));
		ttel.setText(Long.toString(teacherVo.getT_tel()));
		tqq.setText(Long.toString(teacherVo.getT_qq()));
		ttemail.setText(teacherVo.getT_email());
		tid.setEditable(false);

		t_email = new JLabel("��ʦemail", JLabel.CENTER);

		// ���ӵ�nroth��
		north.add(t_id);
		north.add(tid);
		north.add(t_name);
		north.add(tname);
		north.add(t_sex);
		north.add(tsex);
		north.add(t_age);
		north.add(tage);
		north.add(t_duty);
		north.add(tduty);
		north.add(t_tel);
		north.add(ttel);
		north.add(t_qq);
		north.add(tqq);
		north.add(t_email);
		north.add(ttemail);
		// ���ӵ�south��
		south.setBorder(BorderFactory.createTitledBorder("��ť��"));
		south.add(submit);
		south.add(reset);
		south.add(cancel);

		// ��north,south.���ӵ��Ի�����
		updateeacher.add(north, "North");
		updateeacher.add(south, "South");
		updateeacher.setSize(500, 200);
		updateeacher.setLocationRelativeTo(null);
		updateeacher.setVisible(true);

		submit.addActionListener(this);
		reset.addActionListener(this);
		cancel.addActionListener(this);
		return updateeacher;

	}

	public void actionPerformed(ActionEvent arg0) {

		String str = arg0.getActionCommand();
		if (str.equals("�ύ")) {
			try {
				if (!tid.getText().equals("") && !tname.getText().equals("")
						&& !tage.getText().equals("")
						&& !ttel.getText().equals("")
						&& !tqq.getText().equals("")
						&& !ttemail.getText().equals("")) {
					teacherVo.setT_id(Integer.parseInt(tid.getText()));
					teacherVo.setT_name(tname.getText());
					teacherVo.setT_sex(tsex.getSelectedItem());
					teacherVo.setT_age(Integer.parseInt(tage.getText()));
					teacherVo.setT_duty(tduty.getSelectedItem());
					teacherVo.setT_tel(Long.parseLong(ttel.getText()));
					teacherVo.setT_qq(Long.parseLong(tqq.getText()));
					teacherVo.setT_email(ttemail.getText());
					TeacherDao teacherdao = new TeacherDao(teacherVo);
					teacherdao.updateInfo();
					updateeacher.dispose();
				} else {
					javax.swing.JOptionPane.showMessageDialog(null,
							"��ѡ��Ϊ�գ��뷵��������д��");
				}
			} catch (NumberFormatException ex) {
				javax.swing.JOptionPane.showMessageDialog(null, "��������ȷ���ַ���ʽ��");
			}
		} else if (str.equals("����")) {

			tname.setText("");
			tage.setText("");
			ttel.setText("");
			tqq.setText("");
			ttemail.setText("");
			tsex.select(0);
			tduty.select(0);

		} else if (str.equals("ȡ��")) {
			updateeacher.dispose();

		}
	}
}
