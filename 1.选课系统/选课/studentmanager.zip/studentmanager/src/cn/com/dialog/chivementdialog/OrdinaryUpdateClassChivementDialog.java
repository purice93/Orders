package cn.com.dialog.chivementdialog;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import cn.com.action.chivementaction.OrdinaryUpdateStuClass1Action;

public class OrdinaryUpdateClassChivementDialog {
	private JDialog updateClass1;

	private int[] sNum;

	private String[] sName;

	private int[] classExam;
	
	private JLabel[] stuid;

	private JLabel[] name;

	private JTextField[] exam;

	private JScrollPane jScrollPane;

	public JDialog getUpdateClass1() {
		return updateClass1;
	}

	public JTextField[] getExam() {
		return exam;
	}

	public int[] getSNum() {
		return sNum;
	}

	public OrdinaryUpdateClassChivementDialog() {
		super();
	}

	public OrdinaryUpdateClassChivementDialog(int[] num, String[] name, int[] classExam) {
		super();
		this.sNum = num;
		this.sName = name;
		this.classExam = classExam;
	}


	public JDialog creatUpdateClass1Dialog() {
		if (updateClass1 == null) {
			updateClass1 = new JDialog();
			updateClass1.setLayout(new BorderLayout());
			updateClass1.add(creatJScrllPane(), "Center");
			updateClass1.add(ButtonPanel(), "South");
//			updateClass1.pack();
			updateClass1.setSize(550,120);
			updateClass1.setModal(true);
			updateClass1.setLocationRelativeTo(null);
			return updateClass1;
		}
		return null;
	}

	public JPanel ButtonPanel() {
		JPanel panel = new JPanel();
		JButton button1 = new JButton("�ύ");
		JButton button2 = new JButton(" ȡ��");
		OrdinaryUpdateStuClass1Action action = new OrdinaryUpdateStuClass1Action(this);
		button1.addActionListener(action);
		button2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				updateClass1.dispose();
			}

		});

		panel.add(button1);
		panel.add(button2);
		return panel;
	}

	public JScrollPane creatJScrllPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setPreferredSize(new Dimension(270, 350));
			jScrollPane
					.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			jScrollPane.setViewportView(GridPanel());
			return jScrollPane;
		}
		return null;
	}

	public JPanel GridPanel() {
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(sNum.length, 3));
		creatIdLabel();
		creatNameLabel();
		creatExamText();
		for (int i = 0; i < sNum.length; i++) {
			panel.add(stuid[i]);
			panel.add(name[i]);
			panel.add(exam[i]);
		}
		panel.setBorder(BorderFactory.createTitledBorder("ƽʱ�ɼ��޸�"));
		return panel;
	}

	public void creatIdLabel() {
		if (stuid == null) {
			stuid = new JLabel[sNum.length];
			for (int i = 0; i < sNum.length; i++) {
				stuid[i] = new JLabel("ѧ�ţ� " + Integer.toString(sNum[i]));
			}
		}

	}

	public void creatNameLabel() {
		if (name == null) {
			name = new JLabel[sName.length];
			for (int i = 0; i < sName.length; i++) {
				name[i] = new JLabel("������ " + sName[i]);
			}
		}

	}

	public void creatExamText() {
		if (exam == null) {
			String[] str = new String[classExam.length];
			exam = new JTextField[classExam.length];
			for (int i = 0; i < classExam.length; i++) {
				str[i] = Integer.toString(classExam[i]);
				exam[i] = new JTextField(15);
				exam[i].setText(str[i]);
			}
		}

	}
}
