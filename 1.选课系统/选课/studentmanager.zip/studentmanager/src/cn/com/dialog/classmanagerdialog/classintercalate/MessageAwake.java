package cn.com.dialog.classmanagerdialog.classintercalate;

import java.awt.Font;
import java.awt.GridBagLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cn.com.action.classmanageraction.IntercalateAction;
import cn.com.util.GBC;

public class MessageAwake extends JDialog{
	IntercalateAction action;
	public MessageAwake(){
		initalDialog();
	}
	public void initalDialog(){
		this.setSize(300,150);
		JPanel pane = new JPanel(new GridBagLayout());
		JPanel pane1 = new JPanel();
		JLabel label;
		pane1.add(label = new JLabel("�����Ҫɾ����ѡ�Ŀ�Ŀ��"),new GBC(1,0).setFill(GBC.BOTH));
		label.setFont(new Font("�����п�",Font.BOLD, 18));
		pane.add(buildButton("��"),new GBC(0,1).setInsets(10).setFill(GBC.BOTH));
		pane.add(buildButton("��"),new GBC(2,1).setInsets(10).setFill(GBC.BOTH));
		this.add(pane1);
		this.add(pane,"South");
		this.setLocationRelativeTo(null);
		this.setModal(true);
		this.setVisible(true);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	}
	
	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new IntercalateAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new IntercalateAction(this);
		button.addActionListener(action);
		return button;
	}
//	public static void main(String[] args){
//		new MessageAwake();
//	}
}
