package cn.com.dialog.classmanagerdialog.classmanager;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import cn.com.action.classmanageraction.enrgisteraction.EnregisterAction;
import cn.com.util.GBC;
import cn.com.vo.classmanagervo.ClassVO;

public class ClassEnregister extends JDialog{
	public static JPanel p5;
    public JDialog dialog;
    ActionListener action;//�����¼�
	static JLabel classnum;//�γ̱��
	static JLabel classname;//�γ�����
	static JLabel classtime;//�γ�ʱ��
	static JLabel credithour;//ѧ��
	JLabel enregistertime;
	/**
	 * ����һ���ϿεǼǵ�Dialog
	 * @param title
	 * @return
	 */
	public ClassEnregister(ClassVO vo){
		BorderDemo();
		addInfo();
		getLabelInfo(vo);
		buildDialog("�ϿεǼ�");
		
	}
	public void  buildDialog(String title) {
		if(dialog == null){
		addInfo();
		dialog = new JDialog();
		dialog.setName(title);
		dialog.setSize(300, 200);
		dialog.setModal(true);
		dialog.setTitle("�ϿεǼ�");
		dialog.setLayout(new BorderLayout());
		dialog.add(p5);
		dialog.add(getTime(), "South");
		dialog.setLocationRelativeTo(null);
		dialog.setVisible(true);
		dialog.dispose();
		}
	}

	/**
	 * 
	 * ���ñ߿����
	 */
	public void BorderDemo() {
		p5 = new JPanel();
		p5.setLayout(new GridBagLayout());
		p5.setBorder(BorderFactory.createTitledBorder("�γ�������Ϣ"));

	}

	
	/**
	 * �γ���Ϣ���ص����
	 * 
	 */
	public static void addInfo() {
		p5.add(new JLabel("�γ̱�ţ�     "), new GBC(0, 0).setFill(GBC.WEST));
		p5.add(classnum = new JLabel(), new GBC(1, 0).setInsets(10).setFill(
				GBC.WEST));
		p5.add(new JLabel("�γ����ƣ�     "), new GBC(3, 0).setFill(GBC.WEST));
		p5.add(classname = new JLabel(), new GBC(4, 0).setInsets(10).setFill(
				GBC.WEST));
		p5.add(new JLabel("�γ�ʱ�Σ�     "), new GBC(0, 1).setFill(GBC.WEST));
		p5.add(classtime = new JLabel(), new GBC(1, 1).setInsets(10).setFill(
				GBC.WEST));
		p5.add(new JLabel("ѧ�֣�         "), new GBC(3, 1).setFill(GBC.WEST));
		p5.add(credithour = new JLabel(), new GBC(4, 1).setInsets(10).setFill(
				GBC.WEST));
	}

	/**
	 * �Ǽ�ʱ��͵Ǽǡ��˳���ť
	 */
	public JPanel getTime() {
		
		Calendar now = Calendar.getInstance();
		String date = now.get(Calendar.YEAR) + "-"
				+ (now.get(Calendar.MONTH) + 1) + "-"
				+ now.get(Calendar.DAY_OF_MONTH) + " "
				+ now.get(Calendar.HOUR_OF_DAY) + ":"
				+ now.get(Calendar.MINUTE) + ":" + now.get(Calendar.SECOND);
		System.out.println(date.toString());

		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		panel.add(new JLabel("�Ǽ�ʱ�䣺     "), new GBC(0, 2).setFill(GBC.WEST));
		panel.add(new JLabel(date.toString()), new GBC(1, 2).setInsets(10)
				.setFill(GBC.WEST));
		panel.add(buildButton("�Ǽ�"),new GBC(0,3).setInsets(10).setFill(GBC.WEST));
		panel.add(buildButton("�˳�"),new GBC(1,3).setInsets(10).setFill(GBC.WEST));
		return panel;
	}
	
	/**
	 * ���α�ǩ��ֵ
	 */
	public void getLabelInfo(ClassVO vo){
		addInfo();
		classnum.setText(Integer.toString(vo.getClassID()));
		classname.setText(vo.getClassname());
		classtime.setText(vo.getClasstime());
		credithour.setText(Integer.toString(vo.getCredithour()));
	}
	
	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name) {
		JButton button = new JButton(name);
		action = new EnregisterAction(this);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new EnregisterAction(this);
		button.addActionListener(action);
		return button;
	}

}
