package cn.com.dialog.chivementdialog;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;

import cn.com.action.chivementaction.OrdinaryUpdateStuChivementAction;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryUpdateStuDialog {

	private JDialog updateStu;


	private JTextField text;

	private ChivementVo examVo;

	public OrdinaryUpdateStuDialog(ChivementVo examVo) {
		this.examVo = examVo;
	}

	public JDialog getUpdateStu() {
		return updateStu;
	}

	public JDialog creatUpdateStuDialog() {
		if (updateStu == null) {
			updateStu = new JDialog();
			updateStu.add(UpdateStuInfoPanel());
			updateStu.setModal(true);
			updateStu.pack();
			updateStu.setLocationRelativeTo(null);
			return updateStu;
		}
		return null;
	}

	public JPanel UpdateStuInfoPanel() {
		JPanel panel = new JPanel();
		JButton button1 = new JButton("�ύ");
		OrdinaryUpdateStuChivementAction action = new OrdinaryUpdateStuChivementAction(examVo,this);
		button1.addActionListener(action);
		JButton button2 = new JButton("ȡ��");
		button2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				updateStu.dispose();
			}

		});
		panel.add(creatTxet());
		panel.add(button1);
		panel.add(button2);
		panel.setBorder(BorderFactory.createTitledBorder("ѧ�ţ�"
				+ examVo.getS_id() + "  ������" + examVo.getS_name() + "  ��ƽʱ�ɼ�"));
		return panel;
	}

	public JTextField creatTxet() {
		if (text == null) {
			text = new JTextField(12);
			text.setText(Integer.toString((examVo.getClassExamChivement())));
			return text;
		}
		return null;
	}

	
	public JTextField getText() {
		return text;
	}
}
