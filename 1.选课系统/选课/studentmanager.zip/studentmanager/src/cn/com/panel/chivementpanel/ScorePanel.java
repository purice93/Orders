package cn.com.panel.chivementpanel;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class ScorePanel extends JPanel {
	ImageIcon i;
	
	public ScorePanel() {
		i = new ImageIcon("img//classdesk13.jpg");
		setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	
	protected void paintComponent(Graphics g) {
		// TODO Auto-generated method stub
		super.paintComponent(g);
		Image image = i.getImage();
		g.drawImage(image, 0, 0, this);
		
	}

}
