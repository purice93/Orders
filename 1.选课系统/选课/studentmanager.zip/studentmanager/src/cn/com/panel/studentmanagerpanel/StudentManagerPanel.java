package cn.com.panel.studentmanagerpanel;

import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;
import cn.com.frame.Test;
import cn.com.panel.chivementpanel.ExamPanel;
import cn.com.panel.chivementpanel.OrdinaryPanel;
import cn.com.util.GBC;

public class StudentManagerPanel implements ActionListener {
	private JPanel infomanager;

	private StudentPanel student;

	private TeacherPanel teacher;

	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public StudentManagerPanel(TitledTabProperties titledTabProperties, Test test,
			TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public JPanel ChivementPanel() {
		if (infomanager == null) {
			infomanager = new JPanel();
			infomanager.setLayout(new GridBagLayout());
			
			JButton b1 = new JButton("ѧ����Ϣ����");
			JButton b2 = new JButton("��ʦ��Ϣ����");
		
			infomanager.add(b1, new GBC(0, 10, 10, 10).setInsets(20).setFill(
					GBC.BOTH).setIpad(10, 10));
			infomanager.add(b2, new GBC(50, 100, 60, 60).setInsets(20).setFill(
					GBC.BOTH).setIpad(10, 10));
			b1.addActionListener(this);
			b2.addActionListener(this);
		}
		return infomanager;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("ѧ����Ϣ����")) {
			student = new StudentPanel();
			TitledTab tab = new TitledTab(str, null, student, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("��ʦ��Ϣ����")) {
			teacher = new TeacherPanel();
			TitledTab tab = new TitledTab(str, null, teacher, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		}
	}
}
