package cn.com.panel;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class AboutUs{
	JDialog panel = null;
	public JDialog creat(){
		if(panel==null){
			panel = new JDialog();
			JPanel p1 = new JPanel();
			JPanel p2 = new JPanel();
			JPanel p3 = new JPanel();
			p1.setLayout(new FlowLayout(FlowLayout.CENTER));
			p2.setLayout(new FlowLayout(FlowLayout.CENTER));
			p3.setLayout(new FlowLayout(FlowLayout.CENTER));
			panel.setLayout(new GridLayout(3,1));
			JLabel uslabel=new JLabel(" ��ԭ�ǹ�����    2008-2008");
			JLabel linklabel=new JLabel("<html><a href='http://www.baidu.com'>www.baidu.com</a></html>");
			linklabel.addMouseListener(new MouseAdapter(){
				public void mouseClicked(MouseEvent e){
				try{
					Runtime.getRuntime().exec("cmd /c start http://www.baidu.com");
//				Runtime.getRuntime().exec("cmd /c start "+"http://www.baidu.com"); 
				}catch(Exception ex){
				ex.printStackTrace();
				}
				}
				});
			JButton b = new JButton("ȷ��");
			b.addActionListener(new ActionListener(){

				public void actionPerformed(ActionEvent arg0) {
					panel.dispose();
				}
				
			});
			
			p1.add(uslabel);
			p2.add(linklabel);
			p3.add(b);
			panel.add(p1);
			panel.add(p2);
			panel.add(p3);
			panel.pack();
			panel.setLocationRelativeTo(null);
			panel.setVisible(true);
			return panel;
		}
		return null;
	}
}
