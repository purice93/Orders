package cn.com.panel.studentmanagerpanel;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import cn.com.action.studentmanageraction.TeacherPanelAction;
import cn.com.util.LogWriter;
import cn.com.util.MyTable;


public class TeacherPanel extends JPanel {
   // �½�������� ������ʾ��ѯ���ĳɼ�
   public static  MyTable stuinfoJtable;

   protected JComboBox selectJbox;

   private JScrollPane stuJScrollPane;

   private JTextField selecttext;

   private JLabel label = new JLabel("��ʦ��Ϣ��ѯ", JLabel.LEFT);

   private JButton printButton;

   private JButton addButton;

   private JButton deleteButton;
   
   private JButton updateStuButton;

   private JButton daochuButton;

   private JButton referrButton;

   private JButton highSelectButton;
   
   private JButton refresh;

   private PrintWriter pw;

   private LogWriter logWriter;

   public TeacherPanel() {
      Log();
      this.setLayout(new BorderLayout());
      this.add(creatNorthPanel(), "North");
      this.add(creatSouthPanel(), "South");
      this.add(creatTableCenterPanel(), "Center");
      this.setBorder(BorderFactory.createTitledBorder("��ʦ��Ϣ����:"));
   }

   public void Log() {
      Properties dbProps = new Properties();
      InputStream is;
      try {
         is = new FileInputStream("io.properties");
         dbProps.load(is);
      } catch (IOException e) {
         e.printStackTrace();
      }
      String logfile = dbProps.getProperty("logfile");
      if (logfile != null) {
         try {
            pw = new PrintWriter(new FileWriter(logfile, true), true);
            logWriter = new LogWriter(pw, "examChivement");
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat fromatter = new SimpleDateFormat("yyyy'��'MM'��'dd'��'HH:mm:ss");
            String time = fromatter.format(cal.getTime());
            logWriter.Log(time+"��������");
         } catch (IOException e) {
            e.printStackTrace();
         }
      }

   }

   public JPanel creatNorthPanel() {
      JPanel panel = new JPanel();
      panel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
      referrButton = creatButton(referrButton, "��ѯ");
      highSelectButton = creatButton(highSelectButton, "�߼���ѯ");
      refresh = creatButton(refresh, "ˢ��");
      panel.add(label);
      panel.add(creatSelectBox());
      panel.add(creatSelectText());
      panel.add(referrButton);
      panel.add(highSelectButton);
      panel.add(refresh);
      panel.setBorder(BorderFactory.createTitledBorder("��ѯ��ʦ��Ϣ:"));
      return panel;
   }

   public JPanel creatSouthPanel() {
      JPanel panel = new JPanel();
      panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
      addButton = creatButton(addButton, "������Ϣ");
      deleteButton = creatButton(updateStuButton, "ɾ����Ϣ");
      updateStuButton = creatButton(updateStuButton, "�޸���Ϣ");
      printButton = creatButton(printButton, "��ӡ");
      daochuButton = creatButton(daochuButton, "����");
      panel.add(addButton);
      panel.add(deleteButton);
      panel.add(updateStuButton);
      panel.add(printButton);
      panel.add(daochuButton);
      return panel;
   }

   public JScrollPane creatTableCenterPanel() {
	   stuJScrollPane = new JScrollPane();
	   stuJScrollPane.setViewportView(creatJTable());
	   stuJScrollPane.setBorder(BorderFactory.createTitledBorder("��ѯ�����ʾ:"));
      return stuJScrollPane;
   }

   public MyTable creatJTable() {
      if (stuinfoJtable == null) {
         Object[][] data = {};
         String[] str = {"��ʦID", "��ʦ����", "��ʦ�Ա�", "��ʦ����", "��ʦְ��", "��ʦQQ",
 				"��ʦemail", "��ʦ�绰" };
         DefaultTableModel model = new DefaultTableModel(data, str);
         stuinfoJtable = new MyTable(model);
         stuinfoJtable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         stuinfoJtable.getTableHeader().setReorderingAllowed(false);
//         stuinfoJtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
      }
      return stuinfoJtable;
   }

   public JTextField creatSelectText() {
      selecttext = new JTextField(8);
      return selecttext;
   }

   public JComboBox creatSelectBox() {
      String[] s = { "��ѯȫ����ʦ��Ϣ", "���ݽ�ʦ��Ų�ѯ��ʦ��Ϣ", "���ݽ�ʦְ���ѯ��ʦ��Ϣ",
            "����������ѯ��ʦ��Ϣ" };
      selectJbox = new JComboBox(s);
      return selectJbox;
   }

   public JButton creatButton(JButton button, String name) {
      button = new JButton(name);
      TeacherPanelAction action = new TeacherPanelAction(this,logWriter);
      button.addActionListener(action);
      return button;

   }

   public String getSelect() {
      String s = selectJbox.getSelectedItem().toString();
      return s;
   }

   public String getInput() {
      String s = selecttext.getText();
      return s;
   }
   public JTable getChevementJtable() {
	   JTable Jtable = stuinfoJtable;
	      return stuinfoJtable;
	   }
}