package cn.com.panel.chivementpanel;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import cn.com.action.chivementaction.OrdinaryPanelAction;
import cn.com.util.LogWriter;
import cn.com.util.MyTable;

public class OrdinaryPanel extends JPanel {
   // �½�������� ������ʾ��ѯ���ĳɼ�
   public static MyTable chevementJtable;

   protected JComboBox selectJbox;

   private JScrollPane examJScrollPane;

   private JTextField selecttext;

   private JLabel label = new JLabel("ѧ��ƽʱ�ɼ���ѯ", JLabel.LEFT);

   private JButton printButton;

   private JButton updateStuButton;

   private JButton updateClassButton;

   private JButton daochuButton;

   private JButton referrButton;

   private JButton highSelectButton;
   
   private JButton refresh;

   private PrintWriter pw;

   private LogWriter logWriter;

   public OrdinaryPanel() {
      Log();
      this.setLayout(new BorderLayout());
      this.add(creatNorthPanel(), "North");
      this.add(creatSouthPanel(), "South");
      this.add(creatTableCenterPanel(), "Center");
      this.setBorder(BorderFactory.createTitledBorder("ƽʱ�ɼ�����:"));
   }

   public void Log() {
      Properties dbProps = new Properties();
      InputStream is;
      try {
         is = new FileInputStream("io.properties");
         dbProps.load(is);
      } catch (IOException e) {
         e.printStackTrace();
      }
      String logfile = dbProps.getProperty("logfile");
      if (logfile != null) {
         try {
            pw = new PrintWriter(new FileWriter(logfile, true), true);
            logWriter = new LogWriter(pw, "examChivement");
            Calendar cal = Calendar.getInstance();
            SimpleDateFormat fromatter = new SimpleDateFormat("yyyy'��'MM'��'dd'��'HH:mm:ss");
            String time = fromatter.format(cal.getTime());
            logWriter.Log(time+"��������");
         } catch (IOException e) {
            e.printStackTrace();
         }
      }

   }

   public JPanel creatNorthPanel() {
      JPanel panel = new JPanel();
      panel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
      referrButton = creatButton(referrButton, "��ѯ");
      highSelectButton = creatButton(highSelectButton, "�߼���ѯ");
      refresh = creatButton(refresh, "ˢ��");
      panel.add(label);
      panel.add(creatSelectBox());
      panel.add(creatSelectText());
      panel.add(referrButton);
      panel.add(highSelectButton);
      panel.add(refresh);
      panel.setBorder(BorderFactory.createTitledBorder("��ѯ�ɼ�:"));
      return panel;
   }

   public JPanel creatSouthPanel() {
      JPanel panel = new JPanel();
      panel.setLayout(new FlowLayout());
      updateStuButton = creatButton(updateStuButton, "�޸�ѡ��ѧ���ɼ�");
      updateClassButton = creatButton(updateClassButton, "�޸�ƽʱ�ɼ�");
      printButton = creatButton(printButton, "��ӡ");
      daochuButton = creatButton(daochuButton, "����");
      panel.add(updateStuButton);
      panel.add(updateClassButton);
      panel.add(printButton);
      panel.add(daochuButton);
      return panel;
   }

   public JScrollPane creatTableCenterPanel() {
      examJScrollPane = new JScrollPane();
      examJScrollPane.setViewportView(creatJTable());
      examJScrollPane.setBorder(BorderFactory.createTitledBorder("��ѯ�����ʾ:"));
      return examJScrollPane;
   }

   public MyTable creatJTable() {
      if (chevementJtable == null) {
         Object[][] data = {};
         String[] str = { "ѧ��", "���", "ѧ������", "ƽʱ�ɼ�" };
         DefaultTableModel model = new DefaultTableModel(data, str);
         chevementJtable = new MyTable(model);
         chevementJtable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         chevementJtable.getTableHeader().setReorderingAllowed(false);
         // chevementJtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
      }
      return chevementJtable;
   }

   public JTextField creatSelectText() {
      selecttext = new JTextField(8);
      return selecttext;
   }

   public JComboBox creatSelectBox() {
      String[] s = { "��ѯȫ��ѧ���ɼ�", "����ѧ�Ų�ѯѧ��ƽʱ�ɼ�", "������Ų�ѯѧ��ƽʱ�ɼ�",
            "����������ѯѧ��ƽʱ�ɼ�" };
      selectJbox = new JComboBox(s);
      return selectJbox;
   }

   public JButton creatButton(JButton button, String name) {
      button = new JButton(name);
      OrdinaryPanelAction action = new OrdinaryPanelAction(this,logWriter);
      button.addActionListener(action);
      return button;

   }

   public String getSelect() {
      String s = selectJbox.getSelectedItem().toString();
      return s;
   }

   public String getInput() {
      String s = selecttext.getText();
      return s;
   }
   public JTable getChevementJtable() {
	   JTable Jtable = chevementJtable;
	      return chevementJtable;
	   }
}