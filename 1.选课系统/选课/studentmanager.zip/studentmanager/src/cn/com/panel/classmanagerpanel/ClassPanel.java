package cn.com.panel.classmanagerpanel;

import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;

import cn.com.action.classmanageraction.ClassInfoAction;
import cn.com.frame.Test;
import cn.com.util.GBC;

public class ClassPanel {
	JPanel panel;

	ActionListener action;

	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;
	
	private ImageIcon i1 = new ImageIcon("img//banji2.png");
	private ImageIcon i2 = new ImageIcon("img//banji22.png");
	private ImageIcon i3 = new ImageIcon("img//banji11.png");
	private ImageIcon i4 = new ImageIcon("img//banji3.png");

	public ClassPanel(TitledTabProperties titledTabProperties, Test test,
			TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	/**
	 * ����panel
	 * 
	 * @return
	 */
	public JPanel buildPanel() {
		if (panel == null) {
			panel = new TJPanel();
			panel.setLayout(new GridBagLayout());
			panel.add(buildButton("�γ�����",i1,i2), new GBC(0, 10, 10, 10).setInsets(30)
					.setFill(GBC.BOTH).setIpad(10, 10));
			panel.add(buildButton("�γ̹���",i3,i4), new GBC(50, 0, 50, 60).setInsets(
					30).setFill(GBC.BOTH).setIpad(10, 10));
		}
		return panel;
	}

	/***************************************************************************
	 * 
	 * �������ֲ�ͬ��ť�ķ���
	 * 
	 **************************************************************************/
	/**
	 * ���������ֵİ�ť
	 * 
	 * @param name��ť����
	 * @return
	 */
	public JButton buildButton(String name,ImageIcon i1,ImageIcon i2) {
		JButton button = new JButton(name,i1);
		button.setRolloverEnabled(true);
		button.setRolloverIcon(i2);
		action = new ClassInfoAction(this,titledTabProperties,test,tp);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ������ͼ��İ�ť
	 * 
	 * @param name
	 * @return
	 */
	private JButton buildButton(String name, String image) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		action = new ClassInfoAction(this,titledTabProperties,test,tp);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ����������仯ͼƬ�İ�ť����ť�����֣�
	 * 
	 * @param name��ť����
	 * @param image�����ǰ��ͼƬ
	 * @param scrimage��������ͼƬ
	 * @return
	 */

	private JButton buildButton(String name, String image, String scrimage) {
		JButton button = new JButton(new ImageIcon(image));
		button.setName(name);
		button.setRolloverEnabled(true);
		button.setRolloverIcon(new ImageIcon(scrimage));
		button.setMargin(new Insets(0, 0, 0, 0));
		action = new ClassInfoAction(this,titledTabProperties,test,tp);
		button.addActionListener(action);
		return button;
	}

	/**
	 * ����û�����ֵ��������ͼƬ�����仯�İ�ť
	 * 
	 * @param name
	 *            �����¼���
	 * @param image
	 *            �����ǰ��ͼƬ
	 * @param scrimage��������ͼƬ
	 * @return
	 */
	private JButton buildButton1(String name, String image, String scrimage) {
		JButton button = new JButton(new ImageIcon(image));
		button.setActionCommand(name);
		button.setRolloverEnabled(true);
		button.setRolloverIcon(new ImageIcon(scrimage));
		button.setMargin(new Insets(0, 0, 0, 0));
		action = new ClassInfoAction(this,titledTabProperties,test,tp);
		button.addActionListener(action);
		return button;
	}

	/**
	 * �ڲ��࣬��panel����ͼƬ����
	 * 
	 * @author Administrator
	 * 
	 */
	class TJPanel extends JPanel {
		ImageIcon icon;

		public TJPanel() {
			icon = new ImageIcon("img//classdesk1.jpg");
			setSize(icon.getIconWidth(), icon.getIconHeight());
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			Image i = icon.getImage();
			g.drawImage(i, 0, 0, this);
		}
	}
}
