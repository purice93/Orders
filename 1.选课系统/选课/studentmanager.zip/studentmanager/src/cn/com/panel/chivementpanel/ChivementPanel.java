package cn.com.panel.chivementpanel;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;
import cn.com.frame.Test;
import cn.com.util.GBC;

public class ChivementPanel implements ActionListener {
	private JPanel chivement;

	private ExamPanel exam;

	private OrdinaryPanel ordinary;

	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public ChivementPanel(TitledTabProperties titledTabProperties, Test test,
			TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public JPanel ChivementPanel() {
		if (chivement == null) {
			chivement = new ScorePanel();
			chivement.setLayout(new GridBagLayout());
			
			ImageIcon i1 = new ImageIcon("img//banji1.png");
			ImageIcon i2 = new ImageIcon("img//banji11.png");
			ImageIcon i3 = new ImageIcon("img//banji3.png");
			ImageIcon i4 = new ImageIcon("img//banji33.png");
			
			JButton b1 = new JButton("���Գɼ�����",i1);
			JButton b2 = new JButton("ƽʱ�ɼ�����",i2);
			
			b1.setRolloverEnabled(true);
			b2.setRolloverEnabled(true);
			
			b1.setRolloverIcon(i3);
			b2.setRolloverIcon(i4);
			
			b1.setBackground(new Color(130,192,245));
			b2.setBackground(new Color(130,192,245));
			
			chivement.add(b1, new GBC(50, 0, 10, 10).setInsets(30).setFill(
					GBC.BOTH).setIpad(10, 10));
			chivement.add(b2, new GBC(50, 50, 50, 60).setInsets(30).setFill(
					GBC.BOTH).setIpad(10, 10));
			b1.addActionListener(this);
			b2.addActionListener(this);
		}
		return chivement;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("���Գɼ�����")) {
			exam = new ExamPanel();
			TitledTab tab = new TitledTab(str, null, exam, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("ƽʱ�ɼ�����")) {
			ordinary = new OrdinaryPanel();
			TitledTab tab = new TitledTab(str, null, ordinary, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		}
	}
}
