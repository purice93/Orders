package cn.com.studentsystem.kaoqin;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import cn.com.studentsystem.exception.NumberOutException;
import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class AddRecord {
	JFrame jf;
	JDatePicker date_text;
	JTextField be_text;
	JTextField now_text;
	JTextField late_text;
	JTextField expalin_text;
	JButton add_button;
	JButton cancel_button;
	JOptionPane jop = new JOptionPane() ;
	public AddRecord(){
		
		init();
	}
	
	public void init(){
		
	    jf = new JFrame("���ڼ�¼");
		jf.setSize(420,480);
		jf.setLocationRelativeTo(null);
		
	    BorderLayout border = new BorderLayout();
	    FlowLayout flow = new FlowLayout(FlowLayout.CENTER,50,50);
		GridLayout grid = new GridLayout(5,1,10,10);
		ImageIcon i = new ImageIcon("image//title.png");
		jf.setIconImage(i.getImage());
		
		JSplitPane slipt_pane = new JSplitPane();
		JPanel up_pane = new JPanel();
		JPanel left_pane = new JPanel();
		JPanel right_pane = new JPanel();
		JPanel all_pane = new JPanel();
		
		up_pane.setBorder(BorderFactory.createTitledBorder("ʱ������"));
		left_pane.setBorder(BorderFactory.createTitledBorder("����ͳ��"));
		right_pane.setBorder(BorderFactory.createTitledBorder("�ٵ�Ե��"));
		
		left_pane.setLayout(flow);
		right_pane.setLayout(flow);
		all_pane.setLayout(border);
		
		JLabel date_label = new JLabel("ʱ������");
	    date_text  = new JDatePicker();
		
		JLabel be_label = new JLabel("Ӧ������");
		 be_text = new JTextField(10);
		
		JLabel now_label = new JLabel("ʵ������");
		now_text = new JTextField(10);
		
	    JLabel late_person = new JLabel("�ٵ���");
	    late_text = new JTextField(10);
		
		JLabel  explain = new JLabel("�ٵ�Ե��");
		 expalin_text = new JTextField(10);
		
		add_button = new JButton("����");
		cancel_button = new JButton("ȡ��");
		
		up_pane.add(date_label);
		up_pane.add(date_text);
		
		left_pane.add(be_label);
		left_pane.add(be_text);
		left_pane.add(late_person);
		left_pane.add(late_text);
		left_pane.add(add_button);
		
	    right_pane.add(now_label);
		right_pane.add(now_text);
		right_pane.add(explain);
		right_pane.add(expalin_text);
		right_pane.add(cancel_button);
		
		slipt_pane.setLeftComponent(left_pane);
		slipt_pane.setRightComponent(right_pane);
		slipt_pane.setAutoscrolls(true);
		slipt_pane.setDividerSize(2);
		slipt_pane.setDividerLocation(200);
		all_pane.add(up_pane,"North");
		all_pane.add(slipt_pane,"Center");
		
		jf.add(all_pane);
	
		class KaoqinAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try{
				if(arg0.getActionCommand().equals("����")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("AddRecord�����Ӱ�ť", pw, "���������ӵ����ݿ��JTable��");
					
					 if(Integer.parseInt(be_text.getText().toString())<Integer.parseInt(now_text.getText().toString())){
                    	 try {
							
                    	 throw new NumberOutException(Integer.parseInt(be_text.getText().toString()),Integer.parseInt(now_text.getText().toString()),
									 "Ӧ������С��ʵ��������");
						 }
                    	catch (NumberOutException e) {
							
							jop.showMessageDialog(null, "�������,Ӧ������С��ʵ��������");
						 }
                      }else {Connection con = DBConnection.getConnectionOracle();
 				      
                      try {
 						PreparedStatement ps = con.prepareStatement("insert into attendance values(?,?,?,?,?)");
 					    ps.setString(1,date_text.getSelectedItem().toString() );
 					    ps.setInt(2, Integer.parseInt(be_text.getText().toString()));
 					    ps.setInt(3, Integer.parseInt(now_text.getText().toString()));
 					    ps.setString(4,late_text.getText().toString() );
 					    ps.setString(5,expalin_text.getText().toString() );
 					    ps.executeUpdate();
 					    
 					    Object[] obj = {date_text.getSelectedItem().toString(),be_text.getText().toString(),
 					    		        now_text.getText().toString(),late_text.getText().toString(),
 					    		        expalin_text.getText().toString()};				  
 	                    
 					    int rows =  KaoQin.table_model.getRowCount();
 	                     for(int i = 0;i<rows;i++){
 	                    	 KaoQin.table_model.removeRow(i);
 	                     }
 					     KaoQin.table_model.addRow(obj);
 					     jop.showMessageDialog(null,  "���Ӽ�¼�ɹ�","��¼��ʾ", jop.INFORMATION_MESSAGE);
 					     jf.dispose();
 					   } catch (SQLException e) {
 						// TODO Auto-generated catch block
 						 jop.showMessageDialog(null, "�ü�¼�Ѵ���", "��¼��ʾ", jop.INFORMATION_MESSAGE);
 					    }catch(NumberFormatException e){
						   jop.showMessageDialog(null, "������Ĳ������֣�����������");
					}	
                
                }
				    
					
				}else if(arg0.getActionCommand().equals("ȡ��")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("AddRecord��ȡ����ť", pw, "ȡ�����������ӵ����ݿ��JTable�еĲ���");
					jf.dispose();
				}
				} catch (NumberFormatException e1) {
					 
					 jop.showMessageDialog(null, "������Ĳ������֣�����������");
						
				 }
				
			}
			
		}
		
		KaoqinAction kaoqin = new KaoqinAction();
		add_button.addActionListener(kaoqin);
		cancel_button.addActionListener(kaoqin);
		
		jf.setVisible(true);
		
		}

}
