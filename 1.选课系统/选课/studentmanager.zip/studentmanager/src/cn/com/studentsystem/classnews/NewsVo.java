package cn.com.studentsystem.classnews;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import cn.com.studentsystem.log.Log;

public class NewsVo {
	
	private String datetime ;//ʱ��
	private String title;//����
	private String author;//����
	
	public NewsVo( String datetime, String title,String author) {
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("NewsVo", pw, "������һ����Ϣ���ֵ����");
		this.author = author;
		this.datetime = datetime;
		this.title = title;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	
	
	
	

}
