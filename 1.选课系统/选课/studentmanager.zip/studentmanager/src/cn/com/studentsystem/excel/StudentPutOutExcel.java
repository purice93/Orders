package cn.com.studentsystem.excel;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class StudentPutOutExcel {

	public StudentPutOutExcel(){
		
	}
	
	public static WritableWorkbook buildWorkBook(String filename){
		File file = new  File(filename);
		WritableWorkbook excel = null;
		try {
			 excel = Workbook.createWorkbook(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return excel;
	}
	
	public static WritableSheet setExcel(WritableWorkbook excel,int row
			,Vector vector){
        WritableSheet sheet = excel.createSheet("��������29��ѧ��������Ϣ��", 0);
		
		WritableFont titleFont = new WritableFont(WritableFont.ARIAL, 20,
				WritableFont.NO_BOLD);
		WritableCellFormat titleFormat = new WritableCellFormat(titleFont);
		
		WritableFont headFont = new WritableFont(WritableFont.ARIAL, 12,
				WritableFont.NO_BOLD);
		WritableCellFormat headFormat = new WritableCellFormat(headFont);  		
		
		try {
			sheet.mergeCells(0, 0, 10, 1);
			titleFormat.setAlignment(Alignment.CENTRE);
			titleFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
			titleFormat.setBorder(Border.ALL, BorderLineStyle.THIN);
			Label title_name = new Label(0, 0, "��������29��ѧ��������Ϣ��"// ���õı���
					, titleFormat);
			sheet.addCell(title_name);
			
			headFormat.setAlignment(Alignment.CENTRE);
			headFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
			headFormat.setBorder(Border.ALL, BorderLineStyle.THIN);
			
			sheet.mergeCells(0, 2, 0, 2);
		    Label noCol = new Label(0, 2, "ѧ��", headFormat);
			sheet.addCell(noCol);
			
			sheet.mergeCells(1, 2, 1, 2);
		    Label rownoCol = new Label(1, 2, "���", headFormat);
			sheet.addCell(rownoCol);
			
			sheet.mergeCells(2, 2, 2, 2);
		    Label nameCol = new Label(2, 2, "����", headFormat);
			sheet.addCell(nameCol);
			
			sheet.mergeCells(3, 2, 3, 2);
		    Label sexCol = new Label(3, 2, "�Ա�", headFormat);
			sheet.addCell(sexCol);
			
			sheet.mergeCells(4, 2, 4, 2);
		    Label ageCol = new Label(4, 2, "����", headFormat);
			sheet.addCell(ageCol);
			
			sheet.mergeCells(5, 2, 5, 2);
		    Label schoolCol = new Label(5, 2, "ѧУ", headFormat);
			sheet.addCell(schoolCol);
			
			sheet.mergeCells(6, 2, 6, 2);
		    Label majorCol = new Label(6, 2, "רҵ", headFormat);
			sheet.addCell(majorCol);
			
			sheet.mergeCells(7, 2, 7, 2);
		    Label telCol = new Label(7, 2, "��ϵ�绰", headFormat);
			sheet.addCell(telCol);
			
			sheet.mergeCells(8, 2, 8, 2);
		    Label qqCol = new Label(8, 2, "QQ����", headFormat);
			sheet.addCell(qqCol);
			
			sheet.mergeCells(9, 2, 10, 2);
		    Label emailCol = new Label(9, 2, "email", headFormat);
			sheet.addCell(emailCol);
			
			for(int i=3;i<row+3;i++){
				sheet.mergeCells(0, i, 0, i);
				sheet.mergeCells(1, i, 1, i);
				sheet.mergeCells(2, i, 2, i);
				sheet.mergeCells(3, i, 3, i);
				sheet.mergeCells(4, i, 4, i);
				sheet.mergeCells(5, i, 5, i);
				sheet.mergeCells(6, i, 6, i);
				sheet.mergeCells(7, i, 7, i);
				sheet.mergeCells(8, i, 8, i);
				sheet.mergeCells(9, i, 10, i);
			}
			
			for(int j=0;j<row;j++){
				
		        sheet.addCell(new Label(0,j+3,vector.elementAt(j*10+0).toString(),headFormat));
				sheet.addCell(new Label(1,j+3,vector.elementAt(j*10+1).toString(),headFormat));
				sheet.addCell(new Label(2,j+3,vector.elementAt(j*10+2).toString(),headFormat));
				sheet.addCell(new Label(3,j+3,vector.elementAt(j*10+3).toString(),headFormat));
				sheet.addCell(new Label(4,j+3,vector.elementAt(j*10+4).toString(),headFormat));
				sheet.addCell(new Label(5,j+3,vector.elementAt(j*10+5).toString(),headFormat));
				sheet.addCell(new Label(6,j+3,vector.elementAt(j*10+6).toString(),headFormat));
				sheet.addCell(new Label(7,j+3,vector.elementAt(j*10+7).toString(),headFormat));
				sheet.addCell(new Label(8,j+3,vector.elementAt(j*10+8).toString(),headFormat));
				sheet.addCell(new Label(9,j+3,vector.elementAt(j*10+9).toString(),headFormat));
				
				
		}
			
				excel.write();
				excel.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (RowsExceededException e) {
			// TODO Auto-generated catch block
			    e.printStackTrace();
			}catch (WriteException e) {
			// TODO Auto-generated catch block
			    e.printStackTrace();
		}
		
		return sheet;
		
	}
	
	
}
