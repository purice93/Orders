package cn.com.studentsystem.debt;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class UpdateDebt {
	
	JFrame jf ;
	JDatePicker date_text;
	JTextField number_text;
	JComboBox io_box;
	JComboBox money_type ;
	JTextField money_text;
	JTextField reason_text;
	JTextField manager_text;
	JButton update_button;
	JButton cancel_button;
	JOptionPane jop = new JOptionPane();
	public UpdateDebt(){
		
		init();
	}
	
	public void init(){
		
		 jf = new JFrame("���񵥾�");
			jf.setSize(480,430);
			jf.setLocationRelativeTo(null);
		    BorderLayout border = new BorderLayout();
		    FlowLayout flow = new FlowLayout(FlowLayout.CENTER,50,50);
			GridLayout grid = new GridLayout(5,1,10,10);
			ImageIcon i = new ImageIcon("image//title.png");
			jf.setIconImage(i.getImage());
			
			JSplitPane slipt_pane = new JSplitPane();
			JPanel up_pane = new JPanel();
			JPanel left_pane = new JPanel();
			JPanel right_pane = new JPanel();
			JPanel all_pane = new JPanel();
			
			up_pane.setBorder(BorderFactory.createTitledBorder("ʱ������"));
			left_pane.setBorder(BorderFactory.createTitledBorder("������Ŀ"));
			right_pane.setBorder(BorderFactory.createTitledBorder("������ʽ"));
			
			left_pane.setLayout(flow);
			right_pane.setLayout(flow);
			all_pane.setLayout(border);
			
			JLabel date_label = new JLabel("ʱ������");
			 date_text  = new JDatePicker();
			
			JLabel io_label = new JLabel("��֧ѡ��");
			 io_box = new JComboBox();
			io_box.addItem("�����");
			io_box.addItem("֧����");
			JLabel number_label = new JLabel("��������");
			 number_text = new JTextField(10);
			 number_text.setEditable(false);
			
			JLabel left_label = new JLabel("��������");
			money_type = new JComboBox();
			money_type.addItem("RMB��");
			money_type.addItem("HK$");
			money_type.addItem("��Ԫ$");
			money_type.addItem("̨��");
			
			JLabel money_label = new JLabel("��֧���");
			 money_text = new JTextField(10);
			
			JLabel reason_label = new JLabel("��֧Ե��");
			 reason_text = new JTextField(10);
			
			JLabel  manager_label = new JLabel("������Ա");
			 manager_text = new JTextField(10);
			
			 update_button = new JButton("�޸�");
			 cancel_button = new JButton("ȡ��");
			
			up_pane.add(date_label);
			up_pane.add(date_text);
			
			left_pane.add(number_label);
			left_pane.add(number_text);
			left_pane.add(io_label);
			left_pane.add(io_box);
			left_pane.add(manager_label);
			left_pane.add(manager_text);
			left_pane.add(update_button);
			
			right_pane.add(left_label);
			right_pane.add(money_type);
		    right_pane.add(money_label);
			right_pane.add(money_text);
			right_pane.add(reason_label);
			right_pane.add(reason_text);
			right_pane.add(cancel_button);
			
			slipt_pane.setLeftComponent(left_pane);
			slipt_pane.setRightComponent(right_pane);
			slipt_pane.setAutoscrolls(true);
			slipt_pane.setDividerSize(2);
			slipt_pane.setDividerLocation(240);
			all_pane.add(up_pane,"North");
			all_pane.add(slipt_pane,"Center");
			
			jf.add(all_pane);
			
		
		class UpdateDebtAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(arg0.getActionCommand().equals("�޸�")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("UpdateDebt���޸İ�ť", pw, "�����ݽ����޸�");
					Connection con = DBConnection.getConnectionOracle();
					
					/** 
					 * �˴��¼����������ʽ����ƥ��
					 */
					Pattern pattern = Pattern.compile("[0-9]+[.]?+[0-9]*") ;
				    Matcher matcher = pattern.matcher(money_text.getText().toString());
				    if(matcher.matches()){
					try {
						PreparedStatement ps = con.prepareStatement("update debt set DATETIME=?,MONEYTYPE=?,ACTIONWAY=?,IOMONEY=?,IOPERSON=?,IOREASON=? where ITEMNUMBER=? ");
					    ps.setString(1,date_text.getSelectedItem().toString() );
						ps.setString(2,money_type.getSelectedItem().toString() );
						ps.setString(3,io_box.getSelectedItem().toString());
						ps.setString(4, money_text.getText().toString());//��ԭ����������ת����String����
						ps.setString(5,manager_text.getText().toString());
						ps.setString(6,reason_text.getText().toString() );
					    ps.setInt(7,Integer.parseInt(number_text.getText().toString() ));
					    ps.executeUpdate();
					 
					    Debt.jtable.setValueAt(date_text.getSelectedItem().toString().substring(0,10), Debt.select_row, 1);
					    Debt.jtable.setValueAt(money_type.getSelectedItem().toString(), Debt.select_row, 2);
					    Debt.jtable.setValueAt(io_box.getSelectedItem().toString(), Debt.select_row, 3);
					    Debt.jtable.setValueAt( money_text.getText().toString(), Debt.select_row, 4);
					    Debt.jtable.setValueAt(manager_text.getText().toString(), Debt.select_row, 5);
					    Debt.jtable.setValueAt(reason_text.getText().toString(), Debt.select_row, 6);
					    
					    jop.showMessageDialog(null, "���¼�¼�ɹ�", "������ʾ", jop.INFORMATION_MESSAGE);
					    jf.dispose();
					
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}catch(NumberFormatException e){
						   jop.showMessageDialog(null, "������Ĳ������֣�����������");
					   }
					  }else {
						  jop.showMessageDialog(null, "���������ֵ��ƥ��");
					  }
					
					
				}else if(arg0.getActionCommand().equals("ȡ��")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("UpdateDebt��ȡ����ť", pw, "ȡ�������ݵĸ���");
					jf.dispose();
				}
			}
			
		}
		
		UpdateDebtAction updatedebt_action = new UpdateDebtAction();
	    update_button.addActionListener(updatedebt_action);
		cancel_button.addActionListener(updatedebt_action);
	    jf.setVisible(true);
		
		}

}

