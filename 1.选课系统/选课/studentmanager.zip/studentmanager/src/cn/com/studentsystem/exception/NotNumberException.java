package cn.com.studentsystem.exception;

public class NotNumberException extends Exception {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public NotNumberException(String message) {
	
		this.message = message;
	}
	
	
}
