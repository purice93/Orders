package cn.com.studentsystem.exception;

public class ExistException extends Exception {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ExistException(String message) {
		super();
		this.message = message;
	}
	
	
}
