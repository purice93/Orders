package cn.com.studentsystem.classnews;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class ClassInfoJPanel extends JPanel {
	
ImageIcon i;
	
	public ClassInfoJPanel(){
		
		i = new ImageIcon("image//debt.png");
		setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	
	
	protected void paintComponent(Graphics arg0) {
		// TODO Auto-generated method stub
		super.paintComponent(arg0);
		Image image = i.getImage();
		arg0.drawImage(image, 0, 0, this);
		
		
	}


}
