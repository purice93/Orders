package cn.com.studentsystem.exception;

public class NoRowSelectedException extends Exception {
	
	private String message;
	
	public NoRowSelectedException(String message){
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
