package cn.com.studentsystem.login;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.OfficeBlue2007Skin;

public class Test {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
	

		SubstanceLookAndFeel.setSkin(new OfficeBlue2007Skin());	
		
		Login l = new Login();
		
        
	}

}
