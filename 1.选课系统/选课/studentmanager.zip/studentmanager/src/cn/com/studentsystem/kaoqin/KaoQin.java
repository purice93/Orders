package cn.com.studentsystem.kaoqin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import cn.com.studentsystem.excel.KaoQinExcelFrame;
import cn.com.studentsystem.excel.KaoQinPutOutExcel;
import cn.com.studentsystem.exception.NoRowSelectedException;
import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;


public class KaoQin extends JPanel{

	public static JDatePicker date_box;
	public static JTable jtable;
	public static DefaultTableModel  table_model ;
	public static int select_row;
	JOptionPane jop = new JOptionPane();
	
	public KaoQin(){
		
		init();
	
	}
	
	public void init(){
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("KaoQin", pw, "�����˰༶���ڱ���������");
		this.setSize(740, 500);
		this.setLayout(new BorderLayout());
	    
		GridLayout grid = new GridLayout(4,1,10,10);
	    Font f = new Font("",Font.HANGING_BASELINE,40);
	    Font f1 = new Font("",Font.TYPE1_FONT,20);
		
		KaoQinJPanel kaoqin_panel = new KaoQinJPanel();
		JPanel left_panel = new JPanel();
		
//		JSplitPane split_panel = new JSplitPane();
//		split_panel.setAutoscrolls(true);
		JPanel button_panel = new JPanel();
		button_panel.setBorder(BorderFactory.createTitledBorder("������ť"));
		
//		left_panel.setLayout(grid);
		kaoqin_panel.setLayout(new BorderLayout());
		
		JLabel jl = new JLabel("����29�࿼�ڱ�",JLabel.CENTER);
		jl.setFont(f);
		jl.setForeground(Color.BLACK);
		
		/**
		 * ���������ð�ť/////////////////////////////////////////////////////////
		 */
//		ImageIcon i1 = new ImageIcon("image//tr.png");
//		ImageIcon i2 = new ImageIcon("image//sr.png");
//		ImageIcon i3 = new ImageIcon("image//cr.png");
//		ImageIcon i4 = new ImageIcon("image//gr.png");
//		ImageIcon i5 = new ImageIcon("image//trr.png");
//		ImageIcon i6 = new ImageIcon("image//srr.png");
//		ImageIcon i7 = new ImageIcon("image//crr.png");
//		ImageIcon i8 = new ImageIcon("image//grr.png");
//		
		
		JButton jb1 = new JButton("���Ӽ�¼");
		JButton jb2 = new JButton("ɾ����¼");
		JButton jb3 = new JButton("���Ҽ�¼");
		JButton jb4 = new JButton("�޸ļ�¼");
//		
//		jb1.setRolloverEnabled(true);
//		jb2.setRolloverEnabled(true);
//		jb3.setRolloverEnabled(true);
//		jb4.setRolloverEnabled(true);
//		
//		jb1.setRolloverIcon(i5);
//		jb2.setRolloverIcon(i6);
//		jb3.setRolloverIcon(i7);
//		jb4.setRolloverIcon(i8);
		
//		jb1.setHorizontalTextPosition(JButton.CENTER);
//		jb2.setHorizontalTextPosition(JButton.CENTER);
//		jb3.setHorizontalTextPosition(JButton.CENTER);
//		jb4.setHorizontalTextPosition(JButton.CENTER);
//		
//		jb1.setVerticalTextPosition(JButton.CENTER);
//		jb2.setVerticalTextPosition(JButton.CENTER);
//		jb3.setVerticalTextPosition(JButton.CENTER);
//		jb4.setVerticalTextPosition(JButton.CENTER);
//		
//		jb1.setFont(f1);
//		jb2.setFont(f1);
//		jb3.setFont(f1);
//		jb4.setFont(f1);
		
		button_panel.add(jb1);
		button_panel.add(jb2);
		button_panel.add(jb3);
		button_panel.add(jb4);
		
/////////���������ð�ť		//////////////////////////////////////////////////////////////////////////////
		
		Object[] column_name = {"����ʱ��","Ӧ������","ʵ������","�ٵ���","�ٵ�Ե��"};
		Object[][] row_name = {};
		
		JScrollPane jsp = new JScrollPane();
	    table_model = new DefaultTableModel(row_name,column_name);
	    jtable = new JTable(table_model);
		jtable.setRowHeight(20);
		TableColumnModel columnModel = jtable.getColumnModel();
        date_box = new JDatePicker();
        jtable.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(date_box));
        jtable.setShowVerticalLines(true);
		jsp.setViewportView(jtable);
		
		JButton excel = new JButton("����Excel��");
		kaoqin_panel.add(jsp);
		kaoqin_panel.add(jl,"North");
		button_panel.add(excel);
//		kaoqin_panel.add(excel,"South");
//		split_panel.setLeftComponent(left_panel);
//		split_panel.setRightComponent(kaoqin_panel);
		
		this.add(button_panel,"South");
		this.add(kaoqin_panel,"Center");
		this.setVisible(true);
		
		class KaoqinAction implements ActionListener{

			
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(arg0.getActionCommand().equals("���Ӽ�¼")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("KaoQin�����Ӽ�¼��ť", pw, "�������Ӽ�¼�Ľ���");
					AddRecord add = new AddRecord();
				}else if(arg0.getActionCommand().equals("ɾ����¼")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("KaoQin��ɾ����¼��ť", pw, "����ɾ����¼�Ľ���");
					
					int row = -1;
					row= jtable.getSelectedRow();
					
					if(row==-1){
						
					try {
							throw new NoRowSelectedException("û��ѡ���κ���");
						} catch (NoRowSelectedException e) {
							// TODO Auto-generated catch block
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
						}
					 }
				    else{Connection con = DBConnection.getConnectionOracle();
				         String select_date = (String) table_model.getValueAt(row, 0);
				     try {
				    	 int close = jop.showConfirmDialog(null, "�Ƿ�ɾ����¼", "��¼��ʾ", jop.YES_NO_CANCEL_OPTION);
						 if(close == jop.YES_OPTION){
				    	 table_model.removeRow(row);
				    	 PreparedStatement ps = con.prepareStatement("delete from attendance where datetime = ?");
					     ps.setString(1, select_date);
					     ps.executeUpdate();
						 }
					     } catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					  }
					  
				   }
					
	             }else if(arg0.getActionCommand().equals("���Ҽ�¼")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("KaoQin�Ĳ��Ҽ�¼��ť", pw, "������Ҽ�¼�Ľ���");
					
					SelectRecord select = new SelectRecord();
			
				}else if(arg0.getActionCommand().equals("�޸ļ�¼")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("KaoQin���޸ļ�¼��ť", pw, "�����޸ļ�¼�Ľ���");
				    
					int rows = -1;
				    rows = jtable.getSelectedRow();
					if(rows == -1){
						try {
							throw new NoRowSelectedException("û���κ���ѡ����в���");
						} catch (NoRowSelectedException e) {
							
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
							
						}
					 }else{
						 UpdateRecord update = new UpdateRecord();
							String date =(String) table_model.getValueAt(rows, 0);
							String all = table_model.getValueAt(rows, 1).toString();
							String  part =table_model.getValueAt(rows, 2).toString();
					        String later = (String)table_model.getValueAt(rows, 3);
						    String reason = (String)table_model.getValueAt(rows, 4);
						    update.date_text.setSelectedItem(date.substring(0,10));
						    update.be_text.setText(all);
						    update.now_text.setText(part);
						    update.late_text.setText(later);
						    update.expalin_text.setText(reason);
						 
					 }
				   
				    
				  } else if(arg0.getActionCommand().equals("����Excel��")){
					  KaoQinExcelFrame excel_frame = new KaoQinExcelFrame();
//					    String filename = "f:\\kaoqin.xls";
//						int row_count = jtable.getRowCount();
//						Vector vector = new Vector();
//						for(int i=0;i<row_count;i++){
//							vector.add(table_model.getValueAt(i, 0));
//							vector.add(table_model.getValueAt(i, 1));
//							vector.add(table_model.getValueAt(i, 2));
//							vector.add(table_model.getValueAt(i, 3));
//							vector.add(table_model.getValueAt(i, 4));
//						}
//						
////						System.out.println(vector.elementAt(0));
//						WritableWorkbook workbook = KaoQinPutOutExcel.buildWorkBook(filename);
////						WritableSheet  sheet = KaoQinPutOutExcel.setTitle(workbook);
//						WritableSheet sheet = KaoQinPutOutExcel.setExcel(workbook, row_count,vector);
////						try {
////							workbook.write();
////						} catch (IOException e) {
////							// TODO Auto-generated catch block
////							e.printStackTrace();
////						}
//					  jop.showMessageDialog(null, "���ѵ���,�����"+filename);
				 }
			}
			
		}
		
		KaoqinAction kaoqin_action = new KaoqinAction();
		jb1.addActionListener(kaoqin_action);
		jb2.addActionListener(kaoqin_action);
		jb3.addActionListener(kaoqin_action);
		jb4.addActionListener(kaoqin_action);
		excel.addActionListener(kaoqin_action);
		
		
	}
	
}
