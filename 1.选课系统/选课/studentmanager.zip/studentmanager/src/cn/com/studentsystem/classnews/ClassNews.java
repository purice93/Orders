package cn.com.studentsystem.classnews;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import cn.com.studentsystem.excel.NewsExcelFrame;
import cn.com.studentsystem.excel.NewsPutOutExcel;
import cn.com.studentsystem.exception.NoRowSelectedException;
import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class ClassNews extends JPanel{
	
	public static JTable jt1;
    public static  DefaultTableModel dtm;
    public static int selected_row ;
    JOptionPane jop = new JOptionPane();
	
	public ClassNews(){
		init();
	}
	public void init(){
		/**
		 *�����ǽ��ö���д����־�ļ�/////////////////////////////////////////
		 */
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("ClassNews", pw, "�����˰༶��Ϣ����������");
		
		
		this.setSize(740, 500);
		this.setLayout(new BorderLayout());
//		JCalendarPanel j = new JCalendarPanel();//����һ��ʱ���
//	    j.setSize(50,500);
		GridLayout grid = new GridLayout(4,1,10,10);
	    Font f = new Font("",Font.HANGING_BASELINE,40);
	    Font f1 = new Font("",Font.TYPE1_FONT,20);
	    Color c = new Color(240,179,22);
		
		ClassInfoJPanel news_panel = new ClassInfoJPanel();
		JPanel left_panel = new JPanel();
		left_panel.setLayout(grid);
	
//		JSplitPane split_panel = new JSplitPane();
//		split_panel.setAutoscrolls(true);
		JPanel button_panel = new JPanel();
		
		news_panel.setLayout(new BorderLayout());
		
		JLabel jl = new JLabel("����29����Ϣ��",JLabel.CENTER);
		jl.setFont(f);
		jl.setForeground(Color.BLACK);
		
//		ImageIcon i1 = new ImageIcon("image//tr.png");
//		ImageIcon i2 = new ImageIcon("image//sr.png");
//		ImageIcon i3 = new ImageIcon("image//cr.png");
//		ImageIcon i4 = new ImageIcon("image//gr.png");
//		ImageIcon i5 = new ImageIcon("image//trr.png");
//		ImageIcon i6 = new ImageIcon("image//srr.png");
//		ImageIcon i7 = new ImageIcon("image//crr.png");
//		ImageIcon i8 = new ImageIcon("image//grr.png");
//		
		
		JButton jb1 = new JButton("������Ϣ");
		JButton jb2 = new JButton("ɾ����Ϣ");
		JButton jb3 = new JButton("��ѯ��Ϣ");
		JButton jb4 = new JButton("�޸���Ϣ");
		
//		jb1.setRolloverEnabled(true);
//		jb2.setRolloverEnabled(true);
//		jb3.setRolloverEnabled(true);
//		jb4.setRolloverEnabled(true);
//		
//		jb1.setRolloverIcon(i5);
//		jb2.setRolloverIcon(i6);
//		jb3.setRolloverIcon(i7);
//		jb4.setRolloverIcon(i8);
		
//		jb1.setHorizontalTextPosition(JButton.CENTER);
//		jb2.setHorizontalTextPosition(JButton.CENTER);
//		jb3.setHorizontalTextPosition(JButton.CENTER);
//		jb4.setHorizontalTextPosition(JButton.CENTER);
//		
//		jb1.setVerticalTextPosition(JButton.CENTER);
//		jb2.setVerticalTextPosition(JButton.CENTER);
//		jb3.setVerticalTextPosition(JButton.CENTER);
//		jb4.setVerticalTextPosition(JButton.CENTER);
		
//		jb1.setFont(f1);
//		jb2.setFont(f1);
//		jb3.setFont(f1);
//		jb4.setFont(f1);
		
		button_panel.add(jb1);
		button_panel.add(jb2);
		button_panel.add(jb3);
		button_panel.add(jb4);
		
		button_panel.setBorder(BorderFactory.createTitledBorder("������ť"));
		
		Object[] column_name = {"ʱ������","��Ϣ����","��Ϣ������"};
		Object[][] row_name = {};
		
		JScrollPane jsp = new JScrollPane();
		
		dtm = new DefaultTableModel(row_name,column_name);
		jt1 = new JTable(dtm);
		jt1.setRowHeight(20);
		TableColumnModel columnModel = jt1.getColumnModel();
	    JDatePicker date_box = new JDatePicker();
	    jt1.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(date_box));
	    jt1.setShowVerticalLines(true);
		jsp.setViewportView(jt1);
		
		JButton excel = new JButton("����Excel��");
		news_panel.add(jsp);
		news_panel.add(jl,"North");
		button_panel.add(excel);
//		split_panel.setLeftComponent(left_panel);
//		split_panel.setRightComponent( news_panel);
		
        this.add(news_panel,"Center");
        this.add(button_panel,"South");

        
        /**
         * �����Ƕ����¼�����
         * @author Administrator
         *
         */
        class NewsAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(arg0.getActionCommand().equals("������Ϣ")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("ClassNews�����Ӱ�ť", pw, "���������������Ϣ�Ľ���");
					
					AddTopic add = new AddTopic();
					
				}else if(arg0.getActionCommand().equals("ɾ����Ϣ")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("ClassNews��ɾ����ť", pw, "ѡ���Ƿ�Լ�¼����ɾ��");
					
					int row = -1;
					row = jt1.getSelectedRow();
					if(row == -1){
						try {
							throw new NoRowSelectedException("û���κ���ѡ����в���");
						} catch (NoRowSelectedException e) {
							
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
							
						}
					}else{
					int close = jop.showConfirmDialog(null, "�Ƿ�ɾ������Ϣ", "��Ϣ��ʾ", JOptionPane.YES_NO_OPTION);
				    if(close == jop.YES_OPTION){
					String title = dtm.getValueAt(row, 1).toString();
					dtm.removeRow(row);
					Connection con = DBConnection.getConnectionOracle();
				    try {
						PreparedStatement ps = con.prepareStatement("delete from news where title = ?" );
					    ps.setString(1, title);
					    ps.executeUpdate();
				   
				    } catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				    }
				  }
					
				    
				}else if(arg0.getActionCommand().equals("��ѯ��Ϣ")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("ClassNews�Ĳ�ѯ��Ϣ��ť", pw, "��������ѯ��Ϣ�Ľ���");
					
					SelectTopic select = new SelectTopic();
					
				 }else if(arg0.getActionCommand().equals("�޸���Ϣ")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("ClassNews���޸İ�ť", pw, "����������޸���Ϣ�Ľ���");
					 
					int row = -1;
					  row = jt1.getSelectedRow();
					if(row == -1){
						try {
							throw new NoRowSelectedException("û���κ���ѡ����в���");
						} catch (NoRowSelectedException e) {
							
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
							
						}
					}
					else{
						UpdateTopic update = new UpdateTopic();
						update.jf.setVisible(true);	
					  
						UpdateTopic.author_text.setText(dtm.getValueAt(row, 2).toString()) ;
						UpdateTopic.title_text.setText(dtm.getValueAt(row, 1).toString()) ;
						UpdateTopic.date_text.setSelectedItem(dtm.getValueAt(row, 0).toString().substring(0, 10));
						Connection  con = DBConnection.getConnectionOracle();
						try {
							PreparedStatement ps  = con.prepareStatement("select topic from news where title = ?");
						    ps.setString(1, dtm.getValueAt(row, 1).toString());
							ResultSet rs = ps.executeQuery();
							while(rs.next()){
								UpdateTopic.topic_area.setText(rs.getString(1));
							}
							
							} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
					
					
				}else if(arg0.getActionCommand().equals("����Excel��")){
					NewsExcelFrame excel = new NewsExcelFrame();
//					String filename = "f:\\news.xls";
//					int row_count = jt1.getRowCount();
//					Vector vector = new Vector();
//					for(int i=0;i<row_count;i++){
//						vector.add(dtm.getValueAt(i, 0));
//						vector.add(dtm.getValueAt(i, 1));
//						vector.add(dtm.getValueAt(i, 2));
//					}
////					System.out.println(vector.get(3));
//					WritableWorkbook workbook = NewsPutOutExcel.buildWorkBook(filename);
//					WritableSheet sheet = NewsPutOutExcel.setExcel(workbook, row_count,vector);
//						
////					try {
//////						workbook.write();
//////					    workbook.close();
////						} catch (WriteException e) {
////							// TODO Auto-generated catch block
////							e.printStackTrace();
////						}
////					catch (IOException e) {
////						// TODO Auto-generated catch block
////						e.printStackTrace();
////					}
//					jop.showMessageDialog(null, "��Ϣ���ѵ���,�����"+filename);
				}
				
			}
			
        }
        
        NewsAction news_action = new NewsAction();
        
        jb1.addActionListener(news_action);
        jb2.addActionListener(news_action);
        jb3.addActionListener(news_action);
        jb4.addActionListener(news_action);
        excel.addActionListener(news_action);
        
     	
	}

}
