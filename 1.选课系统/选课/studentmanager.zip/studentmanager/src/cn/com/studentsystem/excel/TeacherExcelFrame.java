package cn.com.studentsystem.excel;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.panel.studentmanagerpanel.TeacherPanel;
import cn.com.studentsystem.classnews.ClassNews;
import cn.com.studentsystem.debt.Debt;

public class TeacherExcelFrame  {
	JFrame jf;
	JButton jb1;
	JButton jb2 ;
	JTextField jt1 ;
	public TeacherExcelFrame(){
		init();
		
	}
	
	public void init(){
	    jf = new JFrame();
		jf.setTitle("��������");
		jf.setSize(250, 150);
		jf.setLocationRelativeTo(null);
		
		
		JPanel jp = new JPanel();
		jp.setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
		jb1 = new JButton("����");
	    jb2 = new JButton("ȡ��");
		
		JLabel jl1 = new JLabel("���������");
	    jt1 = new JTextField(10);
		
	    jp.add(jl1);
	    jp.add(jt1);
	    jp.add(jb1);
	    jp.add(jb2);
	    
	    jf.add(jp);
	    jf.setVisible(true);
		
		class ExcelAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				
				if(arg0.getActionCommand().equals("����")){
                 String filename = "f:\\"+jt1.getText()+".xls";
                 int row_count = TeacherPanel.stuinfoJtable.getRowCount();
                 Vector vector = new Vector();
					
						for(int i=0;i<row_count;i++){
							
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 0));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 1));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 2));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 3));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 4));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 5));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 6));
							vector.add(TeacherPanel.stuinfoJtable.getValueAt(i, 7));
							
						}
					
			
//					System.out.println(vector.get(3));
					WritableWorkbook workbook = TeacherPutOutExcel.buildWorkBook(filename);
					WritableSheet sheet = TeacherPutOutExcel.setExcel(workbook, row_count,vector);
						
//					try {
////						workbook.write();
////					    workbook.close();
//						} catch (WriteException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					JOptionPane.showMessageDialog(null, "��Ϣ���ѵ���,�����"+filename);
				    jf.dispose();
				}else if(arg0.getActionCommand().equals("ȡ��")){
					jf.dispose();
				}
				
				
			}
			
		}
		ExcelAction excel_action = new   ExcelAction();
		jb1.addActionListener(excel_action);
		jb2.addActionListener(excel_action);
		
	}

}
