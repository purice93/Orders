package cn.com.studentsystem.classmanager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;

import cn.com.frame.Test;
import cn.com.panel.chivementpanel.ExamPanel;
import cn.com.studentsystem.classnews.ClassNews;
import cn.com.studentsystem.debt.Debt;
import cn.com.studentsystem.kaoqin.KaoQin;
import cn.com.studentsystem.log.Log;

public class ClassDesk extends JPanel {

	/**
	 * ����һ���༶������JPanel����
	 * 
	 * @return
	 */
	public JPanel classpanel;

	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public ClassDesk(TitledTabProperties titledTabProperties, Test test,
			TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public JPanel init() {
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(new FileWriter(file, true), true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("�༶������ģ��", pw, "����༶������ģ��");

		classpanel = new JPanel();
		 classpanel.setSize(740, 500);
		classpanel.setLayout(new BorderLayout());
		ClassDeskJPanel jp1 = new ClassDeskJPanel();
		// JPanel jp1 = new JPanel();
		FlowLayout flow = new FlowLayout(FlowLayout.CENTER, 110, 110);
		jp1.setLayout(flow);

		ImageIcon i1 = new ImageIcon("img//banji1.png");
		ImageIcon i2 = new ImageIcon("img//banji2.png");
		ImageIcon i3 = new ImageIcon("img//banji3.png");
		ImageIcon i11 = new ImageIcon("img//banji11.png");
		ImageIcon i22 = new ImageIcon("img//banji22.png");
		ImageIcon i33 = new ImageIcon("img//banji33.png");

		JButton jb1 = new JButton("�༶������", i1);
		JButton jb2 = new JButton("�༶���ڱ�", i2);
		JButton jb3 = new JButton("�༶����", i3);

		jb1.setRolloverEnabled(true);
		jb2.setRolloverEnabled(true);
		jb3.setRolloverEnabled(true);

		jb1.setRolloverIcon(i11);
		jb2.setRolloverIcon(i22);
		jb3.setRolloverIcon(i33);

		jb1.setHorizontalTextPosition(JButton.CENTER);
		jb2.setHorizontalTextPosition(JButton.CENTER);
		jb3.setHorizontalTextPosition(JButton.CENTER);

		jb1.setVerticalTextPosition(JButton.BOTTOM);
		jb2.setVerticalTextPosition(JButton.BOTTOM);
		jb3.setVerticalTextPosition(JButton.BOTTOM);

		jb1.setMargin(new Insets(0, 0, 0, 0));
		jb2.setMargin(new Insets(0, 0, 0, 0));
		jb3.setMargin(new Insets(0, 0, 0, 0));

		// ImageIcon i4 = new ImageIcon("image//biaoshi1.gif");
		// ImageIcon i5 = new ImageIcon("image//biaoshi2.gif");

		String s = "If not now,when?If not me,who?";
		JLabel jl1 = new JLabel(s, JLabel.RIGHT);
		Font f = new Font("", Font.HANGING_BASELINE, 40);
		jl1.setFont(f);
		jl1.setForeground(Color.blue);

		jp1.add(jb1);
		jp1.add(jb2);
		jp1.add(jb3);
		jp1.add(jl1);

		classpanel.add(jp1);

		class ClassDeckAction implements ActionListener {

			public void actionPerformed(ActionEvent e) {
                String str = e.getActionCommand();
				if (str.equals("�༶������")) {
					TitledTab tab = new TitledTab(str, null, new ClassNews(), null);
					tab.setHighlightedStateTitleComponent(test
							.createCloseTabButton(tab));
					tab.getProperties().addSuperObject(titledTabProperties);
					tp.addTab(tab);
					tp.setSelectedTab(tab);
				} else if (str.equals("�༶���ڱ�")) {
					TitledTab tab = new TitledTab(str, null, new KaoQin(), null);
					tab.setHighlightedStateTitleComponent(test
							.createCloseTabButton(tab));
					tab.getProperties().addSuperObject(titledTabProperties);
					tp.addTab(tab);
					tp.setSelectedTab(tab);
				} else if (str.equals("�༶����")) {
					TitledTab tab = new TitledTab(str, null, new Debt(), null);
					tab.setHighlightedStateTitleComponent(test
							.createCloseTabButton(tab));
					tab.getProperties().addSuperObject(titledTabProperties);
					tp.addTab(tab);
					tp.setSelectedTab(tab);
				}

			}

		}

		ClassDeckAction classdesk_action = new ClassDeckAction();
		jb1.addActionListener(classdesk_action);
		jb2.addActionListener(classdesk_action);
		jb3.addActionListener(classdesk_action);
		return classpanel;

	}

}
