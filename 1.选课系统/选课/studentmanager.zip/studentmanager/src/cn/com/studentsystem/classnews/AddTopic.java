package cn.com.studentsystem.classnews;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class AddTopic {
	JFrame jf;
	JOptionPane jop = new JOptionPane();
	 public static JTextField title_text ;
	 public static JTextField date_text;
	 public static JTextField author_text;
	 public static JTextArea topic_area;
	
	public AddTopic(){
		
		init();
	}
	
	public void init(){
		jf = new JFrame("��Ϣ������");
		jf.setSize(460, 500);
		jf.setLocationRelativeTo(null);
		
		ImageIcon i = new ImageIcon("image//title.png");
		jf.setIconImage(i.getImage());
		
		JLabel title_label = new JLabel("����",JLabel.CENTER);
	    title_text = new JTextField(53);
		
		JLabel date_label = new JLabel("����",JLabel.CENTER);
		final JDatePicker date_text  = new JDatePicker();
		
		JLabel author_label = new JLabel("����",JLabel.CENTER);
		 final JTextField author_text = new JTextField(15);
		
		JLabel topic_label = new JLabel("����",JLabel.CENTER);
		 final JTextArea topic_area = new JTextArea();
		
		Font f = new Font("",Font.BOLD,15);
		title_label.setFont(f);
		date_label.setFont(f);
		author_label.setFont(f);
		topic_label.setFont(f);
		
		JButton add_button = new JButton("����");
		JButton cancel_button = new JButton("ȡ��");
		
		add_button.setFont(f);
		cancel_button.setFont(f);
		
//		TopicJPanel jp = new TopicJPanel();
//		TopicJPanel jp1 = new TopicJPanel();
//		TopicJPanel jp2 = new TopicJPanel();
//		TopicJPanel jp3 = new TopicJPanel();
		JPanel jp = new JPanel();
		JPanel jp1 = new JPanel();
		JPanel jp2= new JPanel();
		JPanel jp3= new JPanel();
		
		jp.setBorder(BorderFactory.createTitledBorder("���ں�����:"));
		jp1.setBorder(BorderFactory.createTitledBorder("���ݱ���:"));
     	jp2.setBorder(BorderFactory.createTitledBorder("��ť��:"));
		
		jp.setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
//		jp1.setLayout(new FlowLayout(FlowLayout.CENTER,20,40));
		jp3.setLayout(new GridLayout(2,1,0,0));
		
		jp.add(date_label);
		jp.add(date_text);
		jp.add(author_label);
		jp.add(author_text);
		
		jp1.add(title_label);
		jp1.add(title_text);
//		jp1.add(topic_label);
		
		jp2.add(add_button);
		jp2.add(cancel_button);
		
		jp3.add(jp,"Center");
		jp3.add(jp1,"South");
	    
	    jf.add(jp3,"North");
	    jf.add(topic_area,"Center");
	    jf.add(jp2,"South");
	    
		
		
		class TopicAction implements ActionListener{

	
    	public void actionPerformed(ActionEvent arg0) {
		
    		if(arg0.getActionCommand().equals("����")){
    			File file = new File("logdiary.txt");
    			PrintWriter pw = null;
    			try {
    				 pw = new PrintWriter(new FileWriter(file,true),true);
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    			Log.log("���Ӱ�ť", pw, "������Ӱ�ť���뽫��Ϣд�����ݿ��JTable");
    		    
    			
    			Connection con = DBConnection.getConnectionOracle();
    		    try {
    			  DefaultTableModel model = (DefaultTableModel)ClassNews.jt1.getModel();
      			int now_row = model.getRowCount();
      			for(int i=now_row-1;i>=0;i--){
  					model.removeRow(i);	
      				
    			}
				PreparedStatement ps = con.prepareStatement("insert into news values(?,?,?,?)");
			    ps.setString(1, date_text.getSelectedItem().toString() );
    		    ps.setString(2, title_text.getText().toString());
			    ps.setString(3, topic_area.getText().toString());
			    ps.setString(4, author_text.getText().toString());
			    ps.executeUpdate();
			    
			    jop.showMessageDialog(null, "�������ųɹ�","����������ʾ", JOptionPane.INFORMATION_MESSAGE);
			    DefaultTableModel dem = (DefaultTableModel)ClassNews.jt1.getModel();
				Object[] obj={date_text.getSelectedItem().toString(),title_text.getText().toString(),author_text.getText().toString()}; 
				
			    dem.addRow(obj);
			    
			    jf.dispose();
			    
    		  } catch (SQLException e) {
				
    			  jop.showMessageDialog(null, "�ü�¼�Ѵ���");
			} 
    		
    			
    		}else if(arg0.getActionCommand().equals("ȡ��")){
    			File file = new File("logdiary.txt");
    			PrintWriter pw = null;
    			try {
    				 pw = new PrintWriter(new FileWriter(file,true),true);
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    			Log.log("ȡ����ť", pw, "���ȡ����ť��ȡ������Ϣ�������ݿ��JTable�Ĳ���");
    		  
                jf.dispose();
    		}
		
	  }
			
			
		}
		
		TopicAction topic_action = new TopicAction();
		add_button.addActionListener(topic_action);
		cancel_button.addActionListener(topic_action);
		
		jf.setVisible(true);
		
		
		
		
		
		
		
		
	}

}
