package cn.com.studentsystem.debt;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class AddDebt {
	JFrame jf;
	JDatePicker date_text;
	JTextField number_text;
	JComboBox io_box;
	JComboBox money_type ;
	JTextField money_text;
	JTextField reason_text;
	JTextField manager_text;
	JButton add_button;
	JButton cancel_button;
	JOptionPane jop = new JOptionPane();
	public AddDebt(){
		
		init();
	}
	
	public void init(){
		
	    jf = new JFrame("���񵥾�");
		jf.setSize(480,430);
		jf.setLocationRelativeTo(null);
	    BorderLayout border = new BorderLayout();
	    FlowLayout flow = new FlowLayout(FlowLayout.CENTER,50,50);
		GridLayout grid = new GridLayout(5,1,10,10);
		ImageIcon i = new ImageIcon("image//title.png");
		jf.setIconImage(i.getImage());
		
		JSplitPane slipt_pane = new JSplitPane();
		JPanel up_pane = new JPanel();
		JPanel left_pane = new JPanel();
		JPanel right_pane = new JPanel();
		JPanel all_pane = new JPanel();
		
		up_pane.setBorder(BorderFactory.createTitledBorder("ʱ������"));
		left_pane.setBorder(BorderFactory.createTitledBorder("������Ŀ"));
		right_pane.setBorder(BorderFactory.createTitledBorder("������ʽ"));
		
		left_pane.setLayout(flow);
		right_pane.setLayout(flow);
		all_pane.setLayout(border);
		
		JLabel date_label = new JLabel("ʱ������");
		date_text  = new JDatePicker();
		
		JLabel io_label = new JLabel("��֧ѡ��");
		io_box = new JComboBox();
		io_box.addItem("�����");
		io_box.addItem("֧����");
		JLabel number_label = new JLabel("��������");
		number_text = new JTextField(10);
		
		JLabel left_label = new JLabel("��������");
		money_type = new JComboBox();
		money_type.addItem("RMB��");
		money_type.addItem("HK$");
		money_type.addItem("��Ԫ$");
		money_type.addItem("̨��");
		
		JLabel money_label = new JLabel("��֧���");
		money_text = new JTextField(10);
		
		JLabel reason_label = new JLabel("��֧Ե��");
		reason_text = new JTextField(10);
		
		JLabel  manager_label = new JLabel("������Ա");
		manager_text = new JTextField(10);
		
		add_button = new JButton("����");
		cancel_button = new JButton("ȡ��");
		
		up_pane.add(date_label);
		up_pane.add(date_text);
		
		left_pane.add(number_label);
		left_pane.add(number_text);
		left_pane.add(io_label);
		left_pane.add(io_box);
		left_pane.add(manager_label);
		left_pane.add(manager_text);
		left_pane.add(add_button);
		
		right_pane.add(left_label);
		right_pane.add(money_type);
	    right_pane.add(money_label);
		right_pane.add(money_text);
		right_pane.add(reason_label);
		right_pane.add(reason_text);
		right_pane.add(cancel_button);
		
		slipt_pane.setLeftComponent(left_pane);
		slipt_pane.setRightComponent(right_pane);
		slipt_pane.setAutoscrolls(true);
		slipt_pane.setDividerSize(2);
		slipt_pane.setDividerLocation(230);
		all_pane.add(up_pane,"North");
		all_pane.add(slipt_pane,"Center");
		
		jf.add(all_pane);
		
		class AddDebtAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(arg0.getActionCommand().equals("����")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("AddDebt�����Ӱ�ť", pw, "���¼�¼�������ݿ��JTable");
					
					Connection con = DBConnection.getConnectionOracle();
//					
					/** 
					 * �˴��¼����������ʽ����ƥ��
					 */
					  Pattern pattern = Pattern.compile("[0-9]+[.]?+[0-9]*") ;
					  Matcher matcher = pattern.matcher(money_text.getText().toString());
					  if(matcher.matches()){
					  try {
							PreparedStatement ps = con.prepareStatement("insert into debt values(?,?,?,?,?,?,?)");
					        ps.setInt(1,Integer.parseInt(number_text.getText().toString()) );
						    ps.setString(2, date_text.getSelectedItem().toString().substring(0, 10));
						    ps.setString(3, money_type.getSelectedItem().toString());
						    ps.setString(4, io_box.getSelectedItem().toString());//��ԭ����������ת����String����
						    ps.setString(5, money_text.getText().toString());
						    ps.setString(6, manager_text.getText().toString());
						    ps.setString(7, reason_text.getText().toString());
						    ps.executeUpdate();
						    
                           int rows = Debt.table_model.getRowCount();
						    for(int i =rows-1;i>=0;i--){
						    	Debt.table_model.removeRow(i);
						    	
						    }
						    
					         Object[] obj = {number_text.getText().toString(), date_text.getSelectedItem().toString().substring(0, 10),
						                    money_type.getSelectedItem().toString(),io_box.getSelectedItem().toString(),money_text.getText().toString(),
						                    manager_text.getText().toString(),reason_text.getText().toString()};
						  
						  
						    Debt.table_model.addRow(obj);
						    jop.showMessageDialog(null, "��������ɹ�", "�˵�ҵ����ʾ", jop.INFORMATION_MESSAGE);
						     jf.dispose();
						
						} catch (SQLException e) {
							jop.showMessageDialog(null, "�ü�¼�Ѵ���");
					   } catch(NumberFormatException e){
						   jop.showMessageDialog(null, "������Ĳ������֣�����������");
					   }	
					   
					     }else{
					    	 jop.showMessageDialog(null, "���������ֵ��ƥ��");
						   
					     }		
					
			  }
					else if(arg0.getActionCommand().equals("ȡ��")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("AddDebt��ȡ����ť", pw, "ȡ�������ݲ������ݿ��JTable�Ĳ���");
					
					jf.dispose();
				}
				
			}
			
		}
		
		AddDebtAction adddebt_action = new AddDebtAction();
		cancel_button.addActionListener(adddebt_action);
		add_button.addActionListener(adddebt_action);
	    jf.setVisible(true);
		
	}

}

