package cn.com.studentsystem.login;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class RegistJPanel extends JPanel {
	ImageIcon i;
	
	public RegistJPanel() {
		i = new ImageIcon("img//desk88.jpg");
		setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Image image = i.getImage();
		g.drawImage(image, 0, 0, this);
		
	}

}


