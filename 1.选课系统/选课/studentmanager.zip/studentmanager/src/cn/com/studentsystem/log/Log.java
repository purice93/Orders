package cn.com.studentsystem.log;

import java.io.PrintWriter;
import java.util.Date;

public class Log {
	
	
	public Log( ){
	
	}
	
	public static void log(String sourse,PrintWriter pw,String topic){
		pw.println("["+new Date()+"],"+"��־��Ϣ��Դ��"+sourse+","+"������:"+topic);
	}
	
	

}
