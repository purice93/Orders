package cn.com.studentsystem.classnews;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import cn.com.util.studentsystemcommon.JDatePicker;

public class SelectTopic {
	public static JFrame jf ;
	public SelectTopic(){
		init();
	}
	
	public void init(){
		
		 jf = new JFrame("��¼��ѯ");
		 jf.setSize(350, 150);
		 jf.setLocationRelativeTo(null);
		 
		 
		 DateJPanel date_panel = new DateJPanel();
		 TitleJPanel title_panel = new TitleJPanel();
		 AuthorJPanel author_panel = new AuthorJPanel();	 
		 
		 
		 JTabbedPane select_pane = new JTabbedPane();
		 
		 select_pane.addTab("��ʱ�����", date_panel);
		 select_pane.addTab("���������",title_panel );
		 select_pane.addTab("�����߲���", author_panel);
		 
		 jf.add(select_pane);
		 
		 jf.setVisible(true);
		 
		 
	}
	
	

}
