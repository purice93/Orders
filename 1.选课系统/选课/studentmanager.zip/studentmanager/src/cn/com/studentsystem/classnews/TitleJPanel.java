package cn.com.studentsystem.classnews;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import cn.com.util.DBConnection;

public class TitleJPanel extends JPanel {
	Vector vector = new Vector();
	JTextField title_text;
	JButton titleselect_button ;
	JButton titlerefresh_button ;
	JButton titlecancel_button;
	public TitleJPanel(){
		init();
	}
	public void init(){
		 
		 JLabel title_label = new JLabel("���������");
		 title_text = new JTextField(50);
		 titleselect_button = new JButton("����");
		 titlerefresh_button = new JButton("ˢ��");
		 titlecancel_button = new JButton("ȡ��");
		 
		 this.add(title_label);
		 this.add(title_text);
		 this.add(titleselect_button);
		 this.add(titlerefresh_button);
		 this.add(titlecancel_button);
		 
		 class TitleAction implements ActionListener{

		
			public void actionPerformed(ActionEvent arg0) {
				
				if(arg0.getActionCommand().equals("����")){

	    			DefaultTableModel model = (DefaultTableModel)ClassNews.jt1.getModel();
	    			int now_row = model.getRowCount();
	    			for(int i=now_row-1;i>=0;i--){
						model.removeRow(i);	
	    			}
	                
				    Connection con = DBConnection.getConnectionOracle();
				    try {
					   PreparedStatement ps = con.prepareStatement("select datetime,title,author from news where title like ?");
					   ps.setString(1, "%"+title_text.getText()+"%");
					   ResultSet rs = ps.executeQuery();
					   while(rs.next()){
						   String date = rs.getString(1);
						   String title = rs.getString(2);
						   String author = rs.getString(3);
						   NewsVo vo = new NewsVo(date,title,author);
						   vector.add(vo);
					   }
					   Iterator ite = vector.iterator();
					    
						while(ite.hasNext()){
						NewsVo nv = (NewsVo)ite.next();
						Object[] obj = {nv.getDatetime(),nv.getTitle(),nv.getAuthor()};
						ClassNews.dtm.addRow(obj);
					}
						SelectTopic.jf.dispose();
				    
				    
				    
				    } catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				}else if(arg0.getActionCommand().equals("ˢ��")){
					DefaultTableModel model = (DefaultTableModel)ClassNews.jt1.getModel();
	    			int now_row = model.getRowCount();
	    			for(int i=now_row-1;i>=0;i--){
						model.removeRow(i);	
	    			}
	                
				    Connection con = DBConnection.getConnectionOracle();
							
					try {
							
						PreparedStatement ps = con.prepareStatement("select datetime,title,author from news order by datetime ");
						ResultSet rs = ps.executeQuery();
							    
					    while(rs.next()){
											    		 
						String date = rs.getString(1);
						String title = rs.getString(2);
					    String author = rs.getString(3);
					    NewsVo vo = new NewsVo(date,title,author);
						vector.add(vo);
							 }
					
						Iterator ite = vector.iterator();
							    
						while(ite.hasNext()){
						NewsVo nv = (NewsVo)ite.next();
						Object[] obj = {nv.getDatetime(),nv.getTitle(),nv.getAuthor()};
						ClassNews.dtm.addRow(obj);
							    	 
							 }
						SelectTopic.jf.dispose();
							     
					
				    } catch (SQLException e) {
					    e.printStackTrace();
				    }
					
				    }else if(arg0.getActionCommand().equals("ȡ��")){
					
					 SelectTopic.jf.dispose();
			      
				}else if(arg0.getActionCommand().equals("ȡ��")){
					
					SelectTopic.jf.dispose();
				 
				   }
				
			   }
			 
	      } 
		 TitleAction title_action = new TitleAction();

		 titleselect_button.addActionListener(title_action);
		 titlerefresh_button.addActionListener(title_action);
		 titlecancel_button.addActionListener(title_action);
		 
	
	}

}
