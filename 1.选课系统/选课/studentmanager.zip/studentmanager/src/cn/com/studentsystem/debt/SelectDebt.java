package cn.com.studentsystem.debt;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;


public class SelectDebt {
	public static JFrame jf;
	public SelectDebt(){
		init();
	}
	
	public void init(){
		jf = new JFrame("�����ѯ");
		jf.setSize(350, 150);
		jf.setLocationRelativeTo(null);
		
		DateJPanel date_panel = new DateJPanel();
		MoneyTypeJPanel moneytype_panel = new MoneyTypeJPanel();
		ActionWayJPanel actionway_panel = new ActionWayJPanel();
		
		JTabbedPane select_pane = new JTabbedPane();
		select_pane.addTab("��ʱ�����", date_panel);
		select_pane.addTab("�����Ҳ���", moneytype_panel);
		select_pane.addTab("����֧����", actionway_panel);
		
	
		jf.add(select_pane);
		jf.setVisible(true);
	}

}
