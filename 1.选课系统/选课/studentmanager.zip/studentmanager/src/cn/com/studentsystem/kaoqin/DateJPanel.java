package cn.com.studentsystem.kaoqin;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class DateJPanel extends JPanel{
	 JDatePicker from_date;
	 JDatePicker to_date;
	 JButton select_button;
	 JButton refresh_button ;
	 JButton cancel_button;
	 Vector vector = new Vector();
	
	public DateJPanel(){
		init();
	}

	public void init(){
		 JLabel from_label = new JLabel("From");
		 JLabel to_label = new JLabel("to");
		 from_date  = new JDatePicker();
		 to_date  = new JDatePicker();
		 select_button = new JButton("����");
		 refresh_button = new JButton("ˢ��");
		 cancel_button = new JButton("ȡ��");
		 
		 this.add(from_label);
		 this.add(from_date);
		 this.add(to_label);
		 this.add(to_date);
		 this.add(select_button);
		 this.add(refresh_button); 
		 this.add(cancel_button);
		 FlowLayout flow = new FlowLayout(FlowLayout.CENTER,20,20);
		 this.setLayout(flow);
		 
		  class DateAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
					
			if(arg0.getActionCommand().equals("����")){
				
    			DefaultTableModel model = (DefaultTableModel)KaoQin.jtable.getModel();
    			int now_row = model.getRowCount();
    			for(int i=now_row-1;i>=0;i--){
					model.removeRow(i);	
    			}
                
			    Connection con = DBConnection.getConnectionOracle();
						
				try {
											
					PreparedStatement ps = con.prepareStatement("select datetime,all_person,now_person,unattender,reason from attendance where datetime>? and datetime<? order by datetime");
				    ps.setString(1, from_date.getSelectedItem().toString());
					ps.setString(2, to_date.getSelectedItem().toString());
					ResultSet rs = ps.executeQuery();
						    
				    while(rs.next()){
										    		 
					String date = rs.getString(1);
					int allperson = rs.getInt(2);
				    int partperson = rs.getInt(3);
				    String lateperson = rs.getString(4);
				    String reason = rs.getString(5);
				    RecordVo vo = new RecordVo(date,allperson,partperson,lateperson,reason);
					vector.add(vo);
						 }
				
					Iterator ite = vector.iterator();
						    
					while(ite.hasNext()){
					RecordVo nv = (RecordVo)ite.next();
					Object[] obj = {nv.getDatetime(),nv.getAllperson(),nv.getPartperson(),nv.getLateperson(),nv.getLatereason()};
					KaoQin.table_model.addRow(obj);
				
					}
					SelectRecord.jf.dispose();
						     
			    } catch (SQLException e) {
				
					e.printStackTrace();
					
			    }
						
				}else if(arg0.getActionCommand().equals("ˢ��")){
					DefaultTableModel model = (DefaultTableModel)KaoQin.jtable.getModel();
	    			int now_row = model.getRowCount();
	    			for(int i=now_row-1;i>=0;i--){
						model.removeRow(i);	
	    			}
	                
				    Connection con = DBConnection.getConnectionOracle();
							
					try {
							
						PreparedStatement ps = con.prepareStatement("select datetime,all_person,now_person,unattender,reason from attendance order by datetime");
						ResultSet rs = ps.executeQuery();
						    
					    while(rs.next()){
					  				    		 
					    String date = rs.getString(1);
						int allperson = rs.getInt(2);
						int partperson = rs.getInt(3);
						String lateperson = rs.getString(4);
						String reason = rs.getString(5);
						RecordVo vo = new RecordVo(date,allperson,partperson,lateperson,reason);
						vector.add(vo);
							 }
					
						Iterator ite = vector.iterator();
							    
						while(ite.hasNext()){
						RecordVo nv = (RecordVo)ite.next();
						Object[] obj = {nv.getDatetime(),nv.getAllperson(),nv.getPartperson(),nv.getLateperson(),nv.getLatereason()};
						KaoQin.table_model.addRow(obj);
							    	 
							 }
						SelectRecord.jf.dispose();
							     
					
				    } catch (SQLException e) {
					    e.printStackTrace();
				    }
					
				    }else if(arg0.getActionCommand().equals("ȡ��")){
					
				    	SelectRecord.jf.dispose();
			}
					
		}
				  
  }
		  
		    DateAction date_action = new DateAction();
		    select_button.addActionListener(date_action);
		    cancel_button.addActionListener(date_action);
		    refresh_button.addActionListener(date_action);
	
	
	}
	
}
