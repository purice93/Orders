package cn.com.studentsystem.debt;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import cn.com.studentsystem.excel.DebtExcelFrame;
import cn.com.studentsystem.exception.NoRowSelectedException;
import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class Debt extends JPanel {

	public static DefaultTableModel table_model;
	public static int select_row;
	public static JTable jtable;
	JOptionPane jop = new JOptionPane();
	public Debt(){
		init();
	}
	
	public void init(){
		/**
		 * �����ǽ��ö���д����־�ļ�/////////////////////////////////
		 */
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("Debt", pw, "�����˰༶���񲾵�������");
		
		
		this.setSize(740, 500);
		this.setLayout(new BorderLayout());
//		JCalendarPanel j = new JCalendarPanel();//����һ��ʱ���
//	    j.setSize(50,500);
		GridLayout grid = new GridLayout(4,1,10,10);
	    Font f = new Font("",Font.HANGING_BASELINE,40);
	    Font f1 = new Font("",Font.TYPE1_FONT,20);
	    Color c = new Color(240,179,22);
		
		DebtJPanel debt_panel = new DebtJPanel();
		JPanel left_panel = new JPanel();
		left_panel.setLayout(grid);
	
//		JSplitPane split_panel = new JSplitPane();
//		split_panel.setAutoscrolls(true);
		
		JPanel button_panel = new JPanel();
		button_panel.setBorder(BorderFactory.createTitledBorder("������ť"));
		
		debt_panel.setLayout(new BorderLayout());
		
		JLabel jl = new JLabel("����29������",JLabel.CENTER);
		jl.setFont(f);
		jl.setForeground(Color.BLACK);
//		
//		ImageIcon i1 = new ImageIcon("image//tr.png");
//		ImageIcon i2 = new ImageIcon("image//sr.png");
//		ImageIcon i3 = new ImageIcon("image//cr.png");
//		ImageIcon i4 = new ImageIcon("image//gr.png");
//		ImageIcon i5 = new ImageIcon("image//trr.png");
//		ImageIcon i6 = new ImageIcon("image//srr.png");
//		ImageIcon i7 = new ImageIcon("image//crr.png");
//		ImageIcon i8 = new ImageIcon("image//grr.png");
		
		
		JButton jb1 = new JButton("���ӿ���");
		JButton jb2 = new JButton("ɾ������");
		JButton jb3 = new JButton("���ҿ���");
		JButton jb4 = new JButton("�޸Ŀ���");
		
//		jb1.setRolloverEnabled(true);
//		jb2.setRolloverEnabled(true);
//		jb3.setRolloverEnabled(true);
//		jb4.setRolloverEnabled(true);
//		
//		jb1.setRolloverIcon(i5);
//		jb2.setRolloverIcon(i6);
//		jb3.setRolloverIcon(i7);
//		jb4.setRolloverIcon(i8);
		
		jb1.setHorizontalTextPosition(JButton.CENTER);
		jb2.setHorizontalTextPosition(JButton.CENTER);
		jb3.setHorizontalTextPosition(JButton.CENTER);
		jb4.setHorizontalTextPosition(JButton.CENTER);
		
		jb1.setVerticalTextPosition(JButton.CENTER);
		jb2.setVerticalTextPosition(JButton.CENTER);
		jb3.setVerticalTextPosition(JButton.CENTER);
		jb4.setVerticalTextPosition(JButton.CENTER);
		
//		jb1.setFont(f1);
//		jb2.setFont(f1);
//		jb3.setFont(f1);
//		jb4.setFont(f1);
		
		button_panel.add(jb1);
		button_panel.add(jb2);
		button_panel.add(jb3);
		button_panel.add(jb4);
		
		Object[] column_name = {"��������","ʱ������","��������","��֧ѡ��","��֧���","������Ա","��֧Ե��"};
		Object[][] row_name = {};
		
		JScrollPane jsp = new JScrollPane();
		table_model = new DefaultTableModel(row_name,column_name);
		jtable = new JTable(table_model);
		jtable.setRowHeight(20);
		TableColumnModel columnModel = jtable.getColumnModel();
	    JDatePicker date_box = new JDatePicker();
        jtable.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(date_box));
        jtable.setShowVerticalLines(true);
		jsp.setViewportView(jtable);
		
		JButton excel = new JButton("����Excel��"); 
		debt_panel.add(jsp);
		debt_panel.add(jl,"North");
		button_panel.add(excel);
//		debt_panel.add(excel,"South");
		
//		split_panel.setLeftComponent(left_panel);
//		split_panel.setRightComponent( debt_panel);

		this.add(button_panel,"South");
		this.add(debt_panel,"Center");
		
		class DebtAction implements ActionListener{

		
			public void actionPerformed(ActionEvent arg0) {
				
				if(arg0.getActionCommand().equals("���ӿ���")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("Debt�����ӿ��ť", pw, "���������ӿ���Ľ���");
					AddDebt add_debt = new AddDebt();
					
				}else if(arg0.getActionCommand().equals("ɾ������")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("Debt��ɾ�����ť", pw, "������ɾ������Ľ���");
					
					int row = -1;
					row = jtable.getSelectedRow();
					if(row == -1){
						try {
							throw new NoRowSelectedException("û���κ���ѡ����в���");
						} catch (NoRowSelectedException e) {
							
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
							
						}
					}else{Connection con = DBConnection.getConnectionOracle();
					
					try {
						int close = jop.showConfirmDialog(null, "�Ƿ�ɾ����¼", "ҵ����ʾ", jop.YES_NO_OPTION);
					    if(close==jop.YES_OPTION){
						PreparedStatement ps =con.prepareStatement("delete from debt where itemnumber = ?");
					    ps.setInt(1, Integer.parseInt(jtable.getValueAt(row, 0).toString()));
					    ps.executeUpdate();
					    table_model.removeRow(row);
					  
					    }
					
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
					
					
				}else if(arg0.getActionCommand().equals("���ҿ���")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("Debt�Ĳ��ҿ��ť", pw, "�����˲��ҿ���Ľ���");
					SelectDebt select_debt = new SelectDebt();
				}else if(arg0.getActionCommand().equals("�޸Ŀ���")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("Debt���޸Ŀ��ť", pw, "�������޸Ŀ���Ľ���");
					
					int row = -1;
					row = Debt.jtable.getSelectedRow();
					if(row == -1){
						try {
							throw new NoRowSelectedException("û���κ���ѡ����в���");
						} catch (NoRowSelectedException e) {
							
							jop.showMessageDialog(null, "��û��ѡ���κ��н��в�������ѡ��");
							
						}
					}else{UpdateDebt update_debt = new UpdateDebt();
			        update_debt.number_text.setText( Debt.table_model.getValueAt(row, 0).toString());
					update_debt.date_text.setSelectedItem(Debt.table_model.getValueAt(row, 1).toString().substring(0,10));
					update_debt.money_type.setSelectedItem(Debt.table_model.getValueAt(row, 2).toString());
					update_debt.io_box.setSelectedItem(Debt.table_model.getValueAt(row, 3).toString());
					update_debt.money_text.setText(Debt.table_model.getValueAt(row, 4).toString());
					update_debt.manager_text.setText(Debt.table_model.getValueAt(row, 5).toString());
					update_debt.reason_text.setText(Debt.table_model.getValueAt(row, 6).toString());
						
					}
					
				}else if(arg0.getActionCommand().equals("����Excel��")){
					    DebtExcelFrame excel_frame = new DebtExcelFrame();//�����ӵİѱ�����10.7�����޸�
//					    String filename = "f:\\debt.xls";
//						int row_count = jtable.getRowCount();
//						Vector vector = new Vector();
//						for(int i=0;i<row_count;i++){
//							vector.add(table_model.getValueAt(i, 0));
//							vector.add(table_model.getValueAt(i, 1));
//							vector.add(table_model.getValueAt(i, 2));
//							vector.add(table_model.getValueAt(i, 3));
//							vector.add(table_model.getValueAt(i, 4));    //ȫע�͵� ��10.7�����޸�
//							vector.add(table_model.getValueAt(i, 5));
//							vector.add(table_model.getValueAt(i, 6));
//						}
//
//						WritableWorkbook workbook = DebtPutOutExcel.buildWorkBook(filename);
//						WritableSheet  sheet = DebtPutOutExcel.setExcel(workbook, row_count,vector);
////						try {
////							workbook.write();
////						} catch (IOException e) {
////							// TODO Auto-generated catch block
////							e.printStackTrace();
////						}
//					jop.showMessageDialog(null, "���ѵ���,�����"+filename);
				}
			}
			
		}
		
		DebtAction debt_action = new DebtAction();
		jb1.addActionListener(debt_action);
		jb2.addActionListener(debt_action);
		jb3.addActionListener(debt_action);
		jb4.addActionListener(debt_action);
		excel.addActionListener(debt_action);
		this.setVisible(true);
	}
	
}
