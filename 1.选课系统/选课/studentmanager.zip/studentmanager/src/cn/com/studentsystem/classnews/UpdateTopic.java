package cn.com.studentsystem.classnews;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class UpdateTopic {
	
	    JFrame jf;
		JOptionPane jop = new JOptionPane();
		public static JTextField title_text;
		public static JDatePicker date_text ;
		public static JTextField author_text;
		public static JTextArea topic_area;
		public UpdateTopic(){
			
			init();
		}
		
		public void init(){
			
		    jf = new JFrame("��������");
			jf.setSize(460, 500);
			jf.setLocationRelativeTo(null);
			
			ImageIcon i = new ImageIcon("image//title.png");
			jf.setIconImage(i.getImage());
			
			JLabel title_label = new JLabel("����",JLabel.CENTER);
			 title_text = new JTextField(53);
			 title_text.setEnabled(false);
			
			JLabel date_label = new JLabel("����",JLabel.CENTER);
			 date_text = new JDatePicker();
			
			JLabel author_label = new JLabel("����",JLabel.CENTER);
			 author_text = new JTextField(15);
			
			JLabel topic_label = new JLabel("����",JLabel.CENTER);
			 topic_area = new JTextArea();
		
//			title_label.setForeground(new Color(96,142,240));
//			date_label.setForeground(new Color(96,142,240));
//			author_label.setForeground(new Color(96,142,240));
//			topic_label.setForeground(new Color(96,142,240));
			
			Font f = new Font("",Font.BOLD,15);
			title_label.setFont(f);
			date_label.setFont(f);
			author_label.setFont(f);
			topic_label.setFont(f);
			
			JButton update_button = new JButton("����");
			JButton cancel_button = new JButton("ȡ��");
			
			update_button.setFont(f);
			cancel_button.setFont(f);
			
			TopicJPanel jp = new TopicJPanel();
			TopicJPanel jp1 = new TopicJPanel();
			TopicJPanel jp2 = new TopicJPanel();
			TopicJPanel jp3 = new TopicJPanel();
			
			jp.setBorder(BorderFactory.createTitledBorder("���ں�����:"));
			jp1.setBorder(BorderFactory.createTitledBorder("���ݱ���:"));
	     	jp2.setBorder(BorderFactory.createTitledBorder("��ť��:"));
			
			jp.setLayout(new FlowLayout(FlowLayout.CENTER,20,20));
			jp1.setLayout(new FlowLayout(FlowLayout.CENTER,20,40));
			jp3.setLayout(new GridLayout(2,1,0,0));
			
			jp.add(date_label);
			jp.add(date_text);
			jp.add(author_label);
			jp.add(author_text);
			
			jp1.add(title_label);
			jp1.add(title_text);
//			jp1.add(topic_label);
			
			jp2.add(update_button);
			jp2.add(cancel_button);
			
			jp3.add(jp,"Center");
			jp3.add(jp1,"South");
			
			
//		    JPanel jp1 = new JPanel();
//		    GridBagLayout gridbag = new GridBagLayout();
//		    jp1.setLayout(gridbag);
//		    
//		    jp1.add(date_label,new GBC(0, 0).setFill(GBC.WEST));
//		    jp1.add(date_text,new GBC(1, 0).setInset(7).setWeight(8, 0).setFill(
//		            GBC.HORIZONTAL));
//		    jp1.add(author_label,new GBC(2, 0).setFill(GBC.WEST));
//		    jp1.add(author_text,new GBC(3, 0).setInset(3).setWeight(3, 0).setFill(
//		            GBC.HORIZONTAL));
//		    jp1.add(title_label,new GBC(2, 1).setFill(GBC.CENTER));
//		    jp1.add(title_text,new GBC(4, 1).setInset(7).setWeight(3, 0).setFill(
//		            GBC.BOTH));
//		    jp1.add(topic_label,new GBC(3, 0).setFill(GBC.CENTER));
//		    jp1.add(topic_area,new GBC(4, 0).setInset(7).setWeight(3, 0).setFill(
//		            GBC.BOTH));
		    
		    jf.add(jp3,"North");
		    jf.add(topic_area,"Center");
		    jf.add(jp2,"South");
		    
			
			
//			jf.pack();
			
			class TopicAction implements ActionListener{

		
	    	public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
	    		if(arg0.getActionCommand().equals("����")){
	    			File file = new File("logdiary.txt");
	    			PrintWriter pw = null;
	    			try {
	    				 pw = new PrintWriter(new FileWriter(file,true),true);
	    			} catch (IOException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			}
	    			Log.log("UpdateTopic�ĸ��°�ť", pw, "�����ݽ��и����޸�");
	    			try {
//	    		    int row = ClassNews.jt1.getSelectedRow();
					ClassNews.dtm.setValueAt(date_text.getSelectedItem().toString(), ClassNews.selected_row, 0);
					ClassNews.dtm.setValueAt(author_text.getText().toString(),ClassNews.selected_row, 2);
	    		    
					Connection con = DBConnection.getConnectionOracle();
	    		    PreparedStatement ps = con.prepareStatement("update news set datetime = ?,topic = ?,author = ? where title = ?");
					ps.setString(1, date_text.getSelectedItem().toString().substring(0, 10));
					ps.setString(2, topic_area.getText().toString());
					ps.setString(3, author_text.getText().toString());
					ps.setString(4, title_text.getText().toString());
					ps.executeUpdate();
					jop.showMessageDialog(null, "���³ɹ�","��Ϣ��ʾ",jop.INFORMATION_MESSAGE);
					jf.dispose();
	    		} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    		
	    		
				 }else if(arg0.getActionCommand().equals("ȡ��")){
					 File file = new File("logdiary.txt");
						PrintWriter pw = null;
						try {
							 pw = new PrintWriter(new FileWriter(file,true),true);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Log.log("UpdateTopic��ȡ����ť", pw, "ȡ�������ݽ����޸�");
	    			jf.dispose();
	    		}
			
		    }
				
				
			}
			
			TopicAction topic_action = new TopicAction();
			update_button.addActionListener(topic_action);
			cancel_button.addActionListener(topic_action);
			
//			jf.setVisible(true);
			
			
			
			
			
			
			
			
		}

	}



