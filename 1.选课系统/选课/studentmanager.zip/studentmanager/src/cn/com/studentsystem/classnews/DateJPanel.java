package cn.com.studentsystem.classnews;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import cn.com.studentsystem.log.Log;
import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class DateJPanel extends JPanel{
	 JDatePicker from_date;
	 JDatePicker to_date;
	 JButton select_button;
	 JButton refresh_button ;
	 JButton cancel_button;
	 Vector vector = new Vector();
	
	public DateJPanel(){
		init();
	}

	public void init(){
		
		 JLabel from_label = new JLabel("From");
		 JLabel to_label = new JLabel("to");
		 from_date  = new JDatePicker();
		 to_date  = new JDatePicker();
		 select_button = new JButton("����");
		 refresh_button = new JButton("ˢ��");
		 cancel_button = new JButton("ȡ��");
		 
		 this.add(from_label);
		 this.add(from_date);
		 this.add(to_label);
		 this.add(to_date);
		 this.add(select_button);
		 this.add(refresh_button); 
		 this.add(cancel_button);
		 FlowLayout flow = new FlowLayout(FlowLayout.CENTER,20,20);
		 this.setLayout(flow);
		 
		  class DateAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
					
			if(arg0.getActionCommand().equals("����")){
				File file = new File("logdiary.txt");
				PrintWriter pw = null;
				try {
					 pw = new PrintWriter(new FileWriter(file,true),true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Log.log("DateJPanel�Ĳ�ѯ��ť", pw, "ͨ��ʱ����м�¼��ѯ");
    			DefaultTableModel model = (DefaultTableModel)ClassNews.jt1.getModel();
    			int now_row = model.getRowCount();
    			for(int i=now_row-1;i>=0;i--){
					model.removeRow(i);	
    			}
                
			    Connection con = DBConnection.getConnectionOracle();
						
				try {
											
					PreparedStatement ps = con.prepareStatement("select datetime,title,author from news where datetime>? and datetime<? order by datetime");
				    ps.setString(1, from_date.getSelectedItem().toString());
					ps.setString(2, to_date.getSelectedItem().toString());
					ResultSet rs = ps.executeQuery();
						    
				    while(rs.next()){
										    		 
					String date = rs.getString(1);
					String title = rs.getString(2);
				    String author = rs.getString(3);
				    NewsVo vo = new NewsVo(date,title,author);
					vector.add(vo);
						 }
				
					Iterator ite = vector.iterator();
						    
					while(ite.hasNext()){
					NewsVo nv = (NewsVo)ite.next();
					Object[] obj = {nv.getDatetime(),nv.getTitle(),nv.getAuthor()};
					ClassNews.dtm.addRow(obj);
				}
					SelectTopic.jf.dispose();
						     
			    } catch (SQLException e) {
				
					e.printStackTrace();
					
			    }
						
				}else if(arg0.getActionCommand().equals("ˢ��")){
					File file = new File("logdiary.txt");
					PrintWriter pw = null;
					try {
						 pw = new PrintWriter(new FileWriter(file,true),true);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.log("DateJPanel��ˢ�°�ť", pw, "�������ݿ������м�¼�Ĳ�ѯ");
					DefaultTableModel model = (DefaultTableModel)ClassNews.jt1.getModel();
	    			int now_row = model.getRowCount();
	    			for(int i=now_row-1;i>=0;i--){
						model.removeRow(i);	
	    			}
	                
				    Connection con = DBConnection.getConnectionOracle();
							
					try {
							
						PreparedStatement ps = con.prepareStatement("select datetime,title,author from news order by datetime ");
						ResultSet rs = ps.executeQuery();
							    
					    while(rs.next()){
											    		 
						String date = rs.getString(1);
						String title = rs.getString(2);
					    String author = rs.getString(3);
					    NewsVo vo = new NewsVo(date,title,author);
						vector.add(vo);
							 }
					
						Iterator ite = vector.iterator();
							    
						while(ite.hasNext()){
						NewsVo nv = (NewsVo)ite.next();
						Object[] obj = {nv.getDatetime(),nv.getTitle(),nv.getAuthor()};
						ClassNews.dtm.addRow(obj);
							    	 
							 }
						SelectTopic.jf.dispose();
							     
					
				    } catch (SQLException e) {
					    e.printStackTrace();
				    }
					
				    }else if(arg0.getActionCommand().equals("ȡ��")){
				    	File file = new File("logdiary.txt");
						PrintWriter pw = null;
						try {
							 pw = new PrintWriter(new FileWriter(file,true),true);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Log.log("DateJPanel��ȡ����ť", pw, "ȡ���˶��κ����ݵĲ�ѯ");
					    SelectTopic.jf.dispose();
			}
					
		}
				  
  }
		  
		    DateAction date_action = new DateAction();
		    select_button.addActionListener(date_action);
		    cancel_button.addActionListener(date_action);
		    refresh_button.addActionListener(date_action);
	
	
	}
	
}
