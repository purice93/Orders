package cn.com.studentsystem.kaoqin;

import javax.swing.JFrame;
import javax.swing.JTabbedPane;

public class SelectRecord {
	
	public static JFrame jf;
	public SelectRecord(){
		init();
	}
	
	public void init(){
		jf = new JFrame("���Ҽ�¼");
		jf.setSize(350, 150);
		jf.setLocationRelativeTo(null);
		
		DateJPanel date_panel = new DateJPanel();
		JTabbedPane select_pane = new JTabbedPane();
		select_pane.addTab("��ʱ�����", date_panel);
        jf.add(select_pane);
	    jf.setVisible(true);
		
		
	}

}
