package cn.com.studentsystem.exception;

public class NumberOutException extends Exception {
	
	private int allnumber;
	private int partnumber;
	private String message;
	
	public NumberOutException(int allnumber, int partnumber,String message ) {
		this.allnumber = allnumber;
		this.message = message;
		this.partnumber = partnumber;
	}

	public int getAllnumber() {
		return allnumber;
	}

	public void setAllnumber(int allnumber) {
		this.allnumber = allnumber;
	}

	public int getPartnumber() {
		return partnumber;
	}

	public void setPartnumber(int partnumber) {
		this.partnumber = partnumber;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
	

}
