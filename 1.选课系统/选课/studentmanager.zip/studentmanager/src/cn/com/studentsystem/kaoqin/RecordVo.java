package cn.com.studentsystem.kaoqin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import cn.com.studentsystem.log.Log;

public class RecordVo {
	
	private String datetime;
	private int allperson;
	private int partperson;
	private String lateperson;
	private String latereason;
	public RecordVo( String datetime,int allperson, int partperson, String lateperson,
			String latereason) {
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("RecordVo", pw, "����һ�����ڼ�¼��ֵ����");
		this.allperson = allperson;
		this.datetime = datetime;
		this.lateperson = lateperson;
		this.latereason = latereason;
		this.partperson = partperson;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public int getAllperson() {
		return allperson;
	}
	public void setAllperson(int allperson) {
		this.allperson = allperson;
	}
	public int getPartperson() {
		return partperson;
	}
	public void setPartperson(int partperson) {
		this.partperson = partperson;
	}
	public String getLateperson() {
		return lateperson;
	}
	public void setLateperson(String lateperson) {
		this.lateperson = lateperson;
	}
	public String getLatereason() {
		return latereason;
	}
	public void setLatereason(String latereason) {
		this.latereason = latereason;
	}
	
	
	
	

}
