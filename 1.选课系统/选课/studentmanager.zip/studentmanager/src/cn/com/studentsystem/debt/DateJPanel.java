package cn.com.studentsystem.debt;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import cn.com.util.DBConnection;
import cn.com.util.studentsystemcommon.JDatePicker;

public class DateJPanel extends JPanel{
	 JDatePicker from_date;
	 JDatePicker to_date;
	 JButton select_button;
	 JButton refresh_button ;
	 JButton cancel_button;
	 Vector vector = new Vector();
	
	public DateJPanel(){
		init();
	}

	public void init(){
		 JLabel from_label = new JLabel("From");
		 JLabel to_label = new JLabel("to");
		 from_date  = new JDatePicker();
		 to_date  = new JDatePicker();
		 select_button = new JButton("����");
		 refresh_button = new JButton("ˢ��");
		 cancel_button = new JButton("ȡ��");
		 
		 this.add(from_label);
		 this.add(from_date);
		 this.add(to_label);
		 this.add(to_date);
		 this.add(select_button);
		 this.add(refresh_button); 
		 this.add(cancel_button);
		 FlowLayout flow = new FlowLayout(FlowLayout.CENTER,20,20);
		 this.setLayout(flow);
		 
		  class DateAction implements ActionListener{

			public void actionPerformed(ActionEvent arg0) {
					
			if(arg0.getActionCommand().equals("����")){
				
    			DefaultTableModel model = (DefaultTableModel)Debt.jtable.getModel();
    			int now_row = model.getRowCount();
    			for(int i=now_row-1;i>=0;i--){
					model.removeRow(i);	
    			}
                
			    Connection con = DBConnection.getConnectionOracle();
						
				try {
											
					PreparedStatement ps = con.prepareStatement("select itemnumber,datetime,moneytype,actionway,iomoney,ioperson,ioreason from debt where datetime>? and datetime<? order by itemnumber");
				    ps.setString(1, from_date.getSelectedItem().toString());
					ps.setString(2, to_date.getSelectedItem().toString());
					ResultSet rs = ps.executeQuery();
						    
				    while(rs.next()){
										    		 
					int no = rs.getInt(1);
					String date = rs.getString(2);
				    String moneytype = rs.getString(3);
				    String ioway = rs.getString(4);
				    String iomoney = rs.getString(5);
				    String ioperson = rs.getString(6);
				    String ioreason = rs.getString(7);
				    DebtVo vo = new DebtVo(no,date,moneytype,ioway,iomoney,ioperson,ioreason);
					vector.add(vo);
						 }
				
					Iterator ite = vector.iterator();
						    
					while(ite.hasNext()){
						DebtVo nv = (DebtVo)ite.next();
					Object[] obj = {nv.getItemnumber(),nv.getDatetime(),nv.getMoneytype(),nv.getActionway(),
							nv.getIomoney(),nv.getIoperson(),nv.getIoreason()};
					Debt.table_model.addRow(obj);
				}
					SelectDebt.jf.dispose();
						     
			    } catch (SQLException e) {
				
					e.printStackTrace();
					
			    }
						
				}else if(arg0.getActionCommand().equals("ˢ��")){
					DefaultTableModel model = (DefaultTableModel)Debt.jtable.getModel();
	    			int now_row = model.getRowCount();
	    			for(int i=now_row-1;i>=0;i--){
						model.removeRow(i);	
	    			}
	                
				    Connection con = DBConnection.getConnectionOracle();
							
					try {
							
						PreparedStatement ps = con.prepareStatement("select itemnumber,datetime,moneytype,actionway,iomoney,ioperson,ioreason from debt order by itemnumber");
						ResultSet rs = ps.executeQuery();
							    
					    while(rs.next()){
											    		 
					    	int no = rs.getInt(1);
							String date = rs.getString(2);
						    String moneytype = rs.getString(3);
						    String ioway = rs.getString(4);
						    String iomoney = rs.getString(5);//��ԭ����int��ת��ΪString
						    String ioperson = rs.getString(6);
						    String ioreason = rs.getString(7);
					   
						    DebtVo vo = new DebtVo(no,date,moneytype,ioway,iomoney,ioperson,ioreason);
						    vector.add(vo);
							 }
					
						Iterator ite = vector.iterator();
							    
						while(ite.hasNext()){
						DebtVo nv = (DebtVo)ite.next();
						Object[] obj = {nv.getItemnumber(),nv.getDatetime(),nv.getMoneytype(),nv.getActionway(),
								nv.getIomoney(),nv.getIoperson(),nv.getIoreason()};
						Debt.table_model.addRow(obj);
							    	 
							 }
						SelectDebt.jf.dispose();
							     
					
				    } catch (SQLException e) {
					    e.printStackTrace();
				    }
					
				    }else if(arg0.getActionCommand().equals("ȡ��")){
					
				    	SelectDebt.jf.dispose();
			}
					
		}
				  
  }
		  
		    DateAction date_action = new DateAction();
		    select_button.addActionListener(date_action);
		    cancel_button.addActionListener(date_action);
		    refresh_button.addActionListener(date_action);
	
	
	}
	
}

