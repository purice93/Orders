
package cn.com.studentsystem.login;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class FirstJPanel extends JPanel {
	
	ImageIcon i;
	
	public FirstJPanel(){
		
		i = new ImageIcon("img//l3.jpg");
		setSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width,java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	}
	
	
	protected void paintComponent(Graphics arg0) {
		// TODO Auto-generated method stub
		super.paintComponent(arg0);
		Image image = i.getImage();
		arg0.drawImage(image, 0, 0, this);
		
		
	}

}
