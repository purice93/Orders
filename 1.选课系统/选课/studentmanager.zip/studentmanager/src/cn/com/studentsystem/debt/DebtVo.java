package cn.com.studentsystem.debt;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import cn.com.studentsystem.log.Log;

public class DebtVo {
	
	private int itemnumber;
	private String datetime;
	private String moneytype;
	private String actionway;
	private String iomoney;//��ԭ����int��ת��ΪString
	private String ioperson;
	private String ioreason;
	
	public DebtVo(int itemnumber,String datetime, String moneytype,String actionway,  String iomoney,
			String ioperson, String ioreason) {
		File file = new File("logdiary.txt");
		PrintWriter pw = null;
		try {
			 pw = new PrintWriter(new FileWriter(file,true),true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.log("DebtVo", pw, "������һ�����񲾵�ֵ����");
		this.actionway = actionway;
		this.datetime = datetime;
		this.iomoney = iomoney;
		this.ioperson = ioperson;
		this.ioreason = ioreason;
		this.itemnumber = itemnumber;
		this.moneytype = moneytype;
	}

	public int getItemnumber() {
		return itemnumber;
	}

	public void setItemnumber(int itemnumber) {
		this.itemnumber = itemnumber;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public String getMoneytype() {
		return moneytype;
	}

	public void setMoneytype(String moneytype) {
		this.moneytype = moneytype;
	}

	public String getActionway() {
		return actionway;
	}

	public void setActionway(String actionway) {
		this.actionway = actionway;
	}

	public String getIomoney() {
		return iomoney;
	}

	public void setIomoney(String iomoney) {
		this.iomoney = iomoney;
	}

	public String getIoperson() {
		return ioperson;
	}

	public void setIoperson(String ioperson) {
		this.ioperson = ioperson;
	}

	public String getIoreason() {
		return ioreason;
	}

	public void setIoreason(String ioreason) {
		this.ioreason = ioreason;
	}
	
	
	
	

}
