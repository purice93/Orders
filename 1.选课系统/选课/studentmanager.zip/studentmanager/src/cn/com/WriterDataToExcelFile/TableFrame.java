package cn.com.WriterDataToExcelFile;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
public class TableFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JLabel jLabel = null;

	private JScrollPane jScrollPane1 = null;

	private JTable jTable1 = null;

	static JTable jTable2 = null;

	private JButton jButton = null;

	/**
	 * This is the default constructor
	 */

	public TableFrame(JTable jTable2) throws HeadlessException {
		super();
		this.jTable2 = jTable2;
		initialize();;
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(800, 601);
		this.add(getJContentPane());
		this.add(getBtnPanel(), "South");
		this.add(getJPanel());
		this.setTitle("JFrame");
		this.setVisible(true);
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel = new JLabel();
			jLabel.setBounds(new java.awt.Rectangle(0, 1, 775, 49));
			jLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			jLabel.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 16));
			jLabel.setText("�׶�ҽ�ƴ�ѧ��ͥ��������ѧ�����ͳ�Ʊ�");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jLabel, null);
			jContentPane.add(getJScrollPane1(), null);
		}
		return jContentPane;
	}

	public JPanel getBtnPanel() {
		JPanel panel = new JPanel();
		panel.add(getJButton());
		return panel;
	}

	/**
	 * This method initializes jScrollPane1
	 * 
	 * @return javax.swing.JScrollPane
	 */
	private JScrollPane getJScrollPane1() {
		if (jScrollPane1 == null) {
			jScrollPane1 = new JScrollPane();
			jScrollPane1.setBounds(new java.awt.Rectangle(1, 50, 800, 100));
			jScrollPane1.setViewportView(getJTable1());
		}
		return jScrollPane1;
	}

	/**
	 * This method initializes jTable1
	 * 
	 * @return javax.swing.JTable
	 */
	private JTable getJTable1() {
		if (jTable1 == null) {
			jTable1 = jTable2;
			// ���ñ�����п��Ȳ��໥Ӱ��
		}
		return jTable1;
	}

	/**
	 * This method initializes jButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setBounds(new java.awt.Rectangle(205, 201, 349, 53));
			jButton.setFont(new java.awt.Font("����", java.awt.Font.BOLD, 18));
			jButton.setText("����");
			jButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					DifferetStudentTable tt = new DifferetStudentTable();

					// ����
					Vector veDta = DifferetStudentTable.getVectorData();

					// Excel�ļ�������
					String argFileName = "c:\\Documents and Settings\\Administrator\\����\\new.xls";
					// ���ý�����д��Excel�ļ��еķ���
					tt.writeExcelOfFile(argFileName, veDta, null);
					JOptionPane.showMessageDialog(null, "�ļ�������" + argFileName);
				}
			});
		}
		return jButton;
	}

	public JPanel getJPanel() {
		JPanel panel = new JPanel();
		return panel;
	}


}
