package cn.com.vo.chivementvo;

public class ChivementVo {
	private int s_id;

	private int g_id;

	private int c_id;

	private int classExamChivement;
	
	private String s_name;

	private String class_name;

	private int[] classNum;

	private String[] classNumString;

	private String[] className;

	private int[] Sid;

	private String[] Sname;

	private int[] classExam;

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getClass_name() {
		return class_name;
	}

	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}

	public int[] getClassExam() {
		return classExam;
	}

	public void setClassExam(int[] classExam) {
		this.classExam = classExam;
	}

	public int getClassExamChivement() {
		return classExamChivement;
	}

	public void setClassExamChivement(int classExamChivement) {
		this.classExamChivement = classExamChivement;
	}

	public String[] getClassName() {
		return className;
	}

	public void setClassName(String[] className) {
		this.className = className;
	}

	public int[] getClassNum() {
		return classNum;
	}

	public void setClassNum(int[] classNum) {
		this.classNum = classNum;
	}

	public String[] getClassNumString() {
		return classNumString;
	}

	public void setClassNumString(String[] classNumString) {
		this.classNumString = classNumString;
	}

	public int getG_id() {
		return g_id;
	}

	public void setG_id(int g_id) {
		this.g_id = g_id;
	}

	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public int[] getSid() {
		return Sid;
	}

	public void setSid(int[] sid) {
		Sid = sid;
	}

	public String[] getSname() {
		return Sname;
	}

	public void setSname(String[] sname) {
		Sname = sname;
	}


}