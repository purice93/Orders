package cn.com.vo.classmanagervo;

public class ClassVO {
	private int classID;// �γ̱��

	private String classname;// �γ���

	private String classestate;// �γ�״̬

	private String teachername;// ��ʦ����

	private int teacherID;// ��ʦ���

	private String classtime;// �γ�ʱ��

	private int totaltime;// �ܿ�ʱ

	private int credithour;// ѧ��

	private String classremark;// �γ̱�ע

	private String teachersex;// ��ʦ�Ա�

	private String teacherduty;// ��ʦְ��

	public String getTeacherduty() {
		return teacherduty;
	}

	public void setTeacherduty(String teacherduty) {
		this.teacherduty = teacherduty;
	}

	public String getTeachersex() {
		return teachersex;
	}

	public void setTeachersex(String teachersex) {
		this.teachersex = teachersex;
	}
	
	public ClassVO(){
		
	}

	/**
	 * "�γ̱��", "�γ�����", "��ʱ", "�γ�ʱ��", "ѧ��", "�γ�״̬", "ִ����ʦ���", "ִ����ʦ����", "ְ��"����
	 */

	public ClassVO(int classID, String classname, int totaltime,
			String classtime, int credithour, String classestate,
			int teacherID, String teachername, String teacherduty,
			String classremake) {
		super();
		this.classID = classID;
		this.classname = classname;
		this.classestate = classestate;
		this.teachername = teachername;
		this.teacherID = teacherID;
		this.classtime = classtime;
		this.totaltime = totaltime;
		this.credithour = credithour;
		this.teacherduty = teacherduty;
		this.classremark = classremake;
	}

	public ClassVO(int classID, String classname, String classestate,
			String teachername, int teacherID, String classtime, int totaltime,
			int credithour, String classremark) {
		super();
		this.classID = classID;
		this.classname = classname;
		this.classestate = classestate;
		this.teachername = teachername;
		this.teacherID = teacherID;
		this.classtime = classtime;
		this.totaltime = totaltime;
		this.credithour = credithour;
		this.classremark = classremark;
	}

	public ClassVO(int classID, String classname, String classestate,
			int teacherID, String classtime, int totaltime, int credithour,
			String classremark) {
		super();
		this.classID = classID;
		this.classname = classname;
		this.classestate = classestate;
		this.teacherID = teacherID;
		this.classtime = classtime;
		this.totaltime = totaltime;
		this.credithour = credithour;
		this.classremark = classremark;
	}

	public String getClassestate() {
		return classestate;
	}

	public void setClassestate(String classestate) {
		this.classestate = classestate;
	}

	public int getClassID() {
		return classID;
	}

	public void setClassID(int classID) {
		this.classID = classID;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public String getClassremark() {
		return classremark;
	}

	public void setClassremark(String classremark) {
		this.classremark = classremark;
	}

	public String getClasstime() {
		return classtime;
	}

	public void setClasstime(String classtime) {
		this.classtime = classtime;
	}

	public int getCredithour() {
		return credithour;
	}

	public void setCredithour(int credithour) {
		this.credithour = credithour;
	}

	public int getTeacherID() {
		return teacherID;
	}

	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public int getTotaltime() {
		return totaltime;
	}

	public void setTotaltime(int totaltime) {
		this.totaltime = totaltime;
	}

}
