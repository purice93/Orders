package cn.com.vo.studentmanagervo;

public class StudentVo {
	private int s_id;

	private int g_id;

	private int c_id;

	private int classExamChivement;

	private String s_name;

	private String class_name;

	private int[] classNum;

	private String[] classNumString;

	private String[] className;

	private int[] Sid;

	private String[] Sname;

	private int[] classExam;

	private String s_sex;// ѧ���Ա�

	private String s_grade;// ѧ�������꼶

	private String s_school;// ѧ������ѧУ

	private String s_professional;// ѧ����ѧרҵ

	private Long s_tel;// ѧ����ϵ����(�ֻ�����)

	private Long s_qq;// ѧ��QQ����

	private String s_emali;// ѧ�������ʼ�

	private String s_introduction;// ѧ�����

	private int s_classnum = 0;// ȱʡ�γ̱��

	public int getC_id() {
		return c_id;
	}

	public void setC_id(int c_id) {
		this.c_id = c_id;
	}

	public String getClass_name() {
		return class_name;
	}

	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}

	public int[] getClassExam() {
		return classExam;
	}

	public void setClassExam(int[] classExam) {
		this.classExam = classExam;
	}

	public int getClassExamChivement() {
		return classExamChivement;
	}

	public void setClassExamChivement(int classExamChivement) {
		this.classExamChivement = classExamChivement;
	}

	public String[] getClassName() {
		return className;
	}

	public void setClassName(String[] className) {
		this.className = className;
	}

	public int[] getClassNum() {
		return classNum;
	}

	public void setClassNum(int[] classNum) {
		this.classNum = classNum;
	}

	public String[] getClassNumString() {
		return classNumString;
	}

	public void setClassNumString(String[] classNumString) {
		this.classNumString = classNumString;
	}

	public int getG_id() {
		return g_id;
	}

	public void setG_id(int g_id) {
		this.g_id = g_id;
	}

	public String getS_emali() {
		return s_emali;
	}

	public void setS_emali(String s_emali) {
		this.s_emali = s_emali;
	}

	public String getS_grade() {
		return s_grade;
	}

	public void setS_grade(String s_grade) {
		this.s_grade = s_grade;
	}

	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public String getS_introduction() {
		return s_introduction;
	}

	public void setS_introduction(String s_introduction) {
		this.s_introduction = s_introduction;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_professional() {
		return s_professional;
	}

	public void setS_professional(String s_professional) {
		this.s_professional = s_professional;
	}

	public Long getS_qq() {
		return s_qq;
	}

	public void setS_qq(Long s_qq) {
		this.s_qq = s_qq;
	}

	public String getS_school() {
		return s_school;
	}

	public void setS_school(String s_school) {
		this.s_school = s_school;
	}

	public String getS_sex() {
		return s_sex;
	}

	public void setS_sex(String s_sex) {
		this.s_sex = s_sex;
	}

	public Long getS_tel() {
		return s_tel;
	}

	public void setS_tel(Long s_tel) {
		this.s_tel = s_tel;
	}

	public int[] getSid() {
		return Sid;
	}

	public void setSid(int[] sid) {
		Sid = sid;
	}

	public String[] getSname() {
		return Sname;
	}

	public void setSname(String[] sname) {
		Sname = sname;
	}

	public int getS_classnum() {
		return s_classnum;
	}

}