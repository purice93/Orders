package cn.com.vo.classmanagervo;

public class ClassStudentVo {
	private int stu_ID;// ѧ��

	private String stu_name;// ѧ������

	private String stu_sex;// ѧ���Ա�

	private int qqNo;// qq����

	private int stu_tel;// �绰����

	private String stu_email;// ��������

	private String grade;// �꼶

	private String school;// ѧУ

	private String speciality;// רҵ

	private int g_No;// ���
	
	public ClassStudentVo(){
		
	}

	public ClassStudentVo(int stu_ID, String stu_name, String stu_sex, int qqNo,
			int stu_tel, String stu_email, String grade, String school,
			String speciality, int no) {
		super();
		this.stu_ID = stu_ID;
		this.stu_name = stu_name;
		this.stu_sex = stu_sex;
		this.qqNo = qqNo;
		this.stu_tel = stu_tel;
		this.stu_email = stu_email;
		this.grade = grade;
		this.school = school;
		this.speciality = speciality;
		g_No = no;
	}

	public int getG_No() {
		return g_No;
	}

	public void setG_No(int no) {
		g_No = no;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getQqNo() {
		return qqNo;
	}

	public void setQqNo(int qqNo) {
		this.qqNo = qqNo;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getStu_email() {
		return stu_email;
	}

	public void setStu_email(String stu_email) {
		this.stu_email = stu_email;
	}

	public int getStu_ID() {
		return stu_ID;
	}

	public void setStu_ID(int stu_ID) {
		this.stu_ID = stu_ID;
	}

	public String getStu_name() {
		return stu_name;
	}

	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}

	public String getStu_sex() {
		return stu_sex;
	}

	public void setStu_sex(String stu_sex) {
		this.stu_sex = stu_sex;
	}

	public int getStu_tel() {
		return stu_tel;
	}

	public void setStu_tel(int stu_tel) {
		this.stu_tel = stu_tel;
	}

}
