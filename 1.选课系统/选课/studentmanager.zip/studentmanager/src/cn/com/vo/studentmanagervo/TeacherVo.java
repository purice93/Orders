package cn.com.vo.studentmanagervo;

public class TeacherVo {
	private int t_id;// ��ʦID

	private String t_name;// ��ʦ����

	private String t_sex;// ��ʦ�Ա�

	private int t_age;//��ʦ����

	private String t_duty;// ��ʦְ��

	private long t_tel;// ��ʦ��ϵ����

	private long t_qq;// ��ʦQQ

	private String t_email;// ��ʦ�����ʼ�

	

	public String getT_email() {
		return t_email;
	}

	public void setT_email(String t_email) {
		this.t_email = t_email;
	}

	public String getT_duty() {
		return t_duty;
	}

	public void setT_duty(String t_duty) {
		this.t_duty = t_duty;
	}

	public int getT_id() {
		return t_id;
	}

	public void setT_id(int t_id) {
		this.t_id = t_id;
	}

	public String getT_name() {
		return t_name;
	}

	public void setT_name(String t_name) {
		this.t_name = t_name;
	}

	public long getT_qq() {
		return t_qq;
	}

	public void setT_qq(long t_qq) {
		this.t_qq = t_qq;
	}

	public String getT_sex() {
		return t_sex;
	}

	public void setT_sex(String t_sex) {
		this.t_sex = t_sex;
	}

	public long getT_tel() {
		return t_tel;
	}

	public void setT_tel(long t_tel) {
		this.t_tel = t_tel;
	}

	public int getT_age() {
		return t_age;
	}

	public void setT_age(int t_age) {
		this.t_age = t_age;
	}

}
