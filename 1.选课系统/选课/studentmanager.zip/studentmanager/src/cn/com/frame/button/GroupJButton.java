package cn.com.frame.button;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;

public class GroupJButton extends JButton {
	public GroupJButton() {
		super();
	}

	public GroupJButton(Action a) {
		super();
	}

	public GroupJButton(Icon icon) {
		super(icon);
	}

	public GroupJButton(String text) {
		super(text);
	}

	public GroupJButton(String text, Icon icon) {
		super(text, icon);
	}

	public void setBorderPainted(boolean arg0) {
		super.setBorderPainted(false);
	}
}
