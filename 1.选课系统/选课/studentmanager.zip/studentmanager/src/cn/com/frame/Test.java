package cn.com.frame;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.List;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;

import net.infonode.tabbedpanel.TabAdapter;
import net.infonode.tabbedpanel.TabEvent;
import net.infonode.tabbedpanel.TabRemovedEvent;
import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.theme.ShapedGradientTheme;
import net.infonode.tabbedpanel.theme.TabbedPanelTitledTabTheme;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;
import net.infonode.util.Direction;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.OfficeBlue2007Skin;

import cn.com.frame.action.ChangeSkinListener;
import cn.com.frame.action.FrameToolBarAction;
import cn.com.frame.action.ItemAction;
import cn.com.frame.action.ListAction;
import cn.com.frame.button.IsaleJButton;

public class Test extends JFrame {

	/**
	 * @param args
	 */
	ActionListener action = null;

	private TitledTabProperties titledTabProperties = new TitledTabProperties();

	// ��ǩҳ���������
	private TabbedPanelTitledTabTheme activeTheme = new ShapedGradientTheme();

	// ������ǩҳ���
	private TabbedPanel tabbedPanel = new TabbedPanel();;

	private int tabId;

	// ����group����Ĺ�����
	private JScrollPane sp;

	// ����JSplitPane���
	private JSplitPane splitPane;

	// ��������ɾ����ť��dialog

	private List list1;

	private List list2;

	// ����������
	private JToolBar jt = CreatJToolBar();

	// ���ӹ�������jpanel

	private JPanel jpa;

	// private JList list1;
	//	
	// private JList list2;
	private TrayIcon trayIcon = null; // ����ͼ��

	private SystemTray tray = null; // ������ϵͳ���̵�ʵ��

	public JToolBar getJt() {
		return jt;
	}

	public void setJt(JToolBar jt) {
		this.jt = jt;
	}

	public static void main(String[] args) {

//		AlloyLookAndFeel.setProperty("alloy.theme", "default");
//		AlloyLookAndFeel.setProperty("alloy.isLookAndFeelFrameDecoration",
//				"true");
//		// ����Ƥ�����
//		try {
//			UIManager.setLookAndFeel(new AlloyLookAndFeel());
//		} catch (UnsupportedLookAndFeelException e) {
//			e.printStackTrace();
//		}
		SubstanceLookAndFeel.setSkin(new OfficeBlue2007Skin());
		new Test();

	}

	/**
	 * frame
	 * 
	 */
	public Test() {
		JPanel jp = new JPanel();
		jp.setLayout(new BorderLayout());
		// ��panel ����frame������ ������߽����
		JPanel jps = new JPanel();
		// �����˵���
		JMenuBar jb = CreatJMenuBar();

		
		SubstanceLookAndFeel.setSkin(new OfficeBlue2007Skin());
//		SubstanceLookAndFeel.setSkin(new FieldOfWheatSkin());
		this.ChangeSkin();
		// ���������� ���ѹ������ӵ�jpa�����
		jpa = new JPanel();
		jpa.setLayout(new BorderLayout());

		jpa.add(jt, "North");
		// ��splitPane�͹������ӵ�jp��
		jp.add(jpa, "North");
		jp.add(buildSplitPane(), "Center");
		// ���ȫ��
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
/////////////////////////////////////////////////////////
//		���޸�
		this.setTitle("ѧ������ϵͳ");
		//////////////////////////////////////////////////////////
		this.setSize(d.width,d.height-20);
		this.setJMenuBar(jb);
		this.setLayout(new BorderLayout());
		this.add(jp, "Center");
		this.add(jps, "South");
		// this.setSize(960, 700);
		ImageIcon icon = new ImageIcon("img/mainframe/icon.PNG"); 
		setIconImage(icon.getImage()); 
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		Tray();
		closeWindow(this);
	}

	/**
	 * ��������Ƥ��
	 */
	public JMenu ChangeSkin() {
		JMenu menu = new JMenu("����Ƥ��");
		String[] skin = { "��ɫ����", "������", "Ĭ��Ƥ��", "���ʷ��" };
		JMenuItem[] item = new JMenuItem[skin.length];
		ChangeSkinListener changeSkinListener = new ChangeSkinListener();
		for (int i = 0; i < skin.length; i++) {
			item[i] = new JMenuItem(skin[i]);
			item[i].addActionListener(changeSkinListener);
			menu.add(item[i]);
		}
		return menu;

	}
///////////////////////////////////
	//////////���޸�
	public void Tray() {
		tray = SystemTray.getSystemTray(); // ��ñ�����ϵͳ���̵�ʵ��
		ImageIcon icon = new ImageIcon("img/mainframe/icon.PNG"); // ��Ҫ��ʾ�������е�ͼ��
		PopupMenu pop = new PopupMenu(); // ����һ���Ҽ�����ʽ�˵�
		MenuItem show = new MenuItem("��ʾ��ҳ��");
		MenuItem exit = new MenuItem("�˳�ϵͳ");
		trayIcon = new TrayIcon(icon.getImage(), "ѧ����Ϣ����ϵͳ", pop);

		trayIcon.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) { // ���˫��
					tray.remove(trayIcon); // ��ϵͳ������ʵ�����Ƴ�����ͼ��
					setVisible(true); // ��ʾ����
				}
			}
		});
		show.addActionListener(new ActionListener() { // �������ʾ���ڡ��˵��󽫴�����ʾ����
					public void actionPerformed(ActionEvent e) {
						tray.remove(trayIcon); // ��ϵͳ������ʵ�����Ƴ�����ͼ��
						setVisible(true); // ��ʾ����
					}
				});
		exit.addActionListener(new ActionListener() { // ������˳���ʾ���˵����Ƴ�����
					public void actionPerformed(ActionEvent e) {
						System.exit(0); // �˳�����
					}
				});
		pop.add(show);
		pop.add(exit);

	}

	/**
	 * ���ڹر�
	 */
	public void closeWindow(Test test) {
		test.addWindowListener(new WindowAdapter() {

			public void windowDeiconified(WindowEvent e) {
			}

			public void windowIconified(WindowEvent e) {
				try {
					if (getState() == 1) {// ��С��״̬
						tray.add(trayIcon);
						setVisible(false); // ʹ���ڲ�����
						setState(0);// �л�������״̬
					}
				} catch (AWTException e1) {
					e1.printStackTrace();
				} // ������ͼ�����ӵ�ϵͳ������ʵ����
			}

			public void windowClosing(WindowEvent e) {
				int ch = JOptionPane.showConfirmDialog(null, "���Ƿ����Ҫ�˳�ϵͳ",
						"�ر�ȷ����", JOptionPane.YES_NO_OPTION);
				if (ch == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}

		});
	}
/////////////////////////////////////////
	/**
	 * listdialog
	 * 
	 */
	/*
	 * 
	 * 
	 * 
	 * gbc ���²���
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	public JDialog creatdialog() {
		list1 = new List(5, true);

		list2 = new List(5, true);
		JDialog listdialog = new JDialog(this, "����ɾ����ݰ�ť", true);

		Panel panel1 = new Panel();
		Panel panel2 = new Panel();
		Panel panel3 = new Panel();
		Panel panel4 = new Panel();
		Panel panel5 = new Panel();

		JButton button1 = new JButton("  ����-->");
		JButton button2 = new JButton("ȫ������");
		JButton button3 = new JButton("<--����  ");
		JButton button4 = new JButton("ȫ������");
		JButton button5 = new JButton("�ύ");
		JButton button6 = new JButton("ȡ��");

		// button1.setSize(50, 50);
		// button2.setSize(50, 50);
		// button3.setSize(50, 50);
		// button4.setSize(50, 50);

		String[] str = new String[] { "1.ѧ��������Ϣ����", "2.��ʦ������Ϣ����", "3.�γ̻�����Ϣ����",
				"4.�ɼ�������Ϣ����", "5.�༶��־��Ϣ����" };

		for (int i = 0; i < str.length; i++) {
			list1.add(str[i]);
		}

		list1.setSize(200, 200);
		list2.setSize(200, 200);

		ListAction listaction = new ListAction(list1, list2, listdialog, jt,
				this, jpa, tabbedPanel, titledTabProperties);
		button1.addActionListener(listaction);
		button2.addActionListener(listaction);
		button3.addActionListener(listaction);
		button4.addActionListener(listaction);
		button5.addActionListener(listaction);
		button6.addActionListener(listaction);

		panel1.add(list1);
		panel3.add(list2);
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(button3);
		panel2.add(button4);
		panel5.setLayout(new FlowLayout());
		panel5.add(button5);
		panel5.add(button6);
		panel2.setLayout(new GridLayout(5, 1));
		panel4.add(panel1);
		panel4.add(panel2);
		panel4.add(panel3);
		panel4.setLayout(new GridLayout(1, 3));
		// panel4.setLayout(new FlowLayout());
		listdialog.setLayout(new BorderLayout());
		listdialog.add(panel4, "Center");
		listdialog.add(panel5, "South");
		// listdialog.pack();
		listdialog.setSize(420, 200);
		return listdialog;
	}

	/**
	 * ����SplitPane ��������������
	 * 
	 */
	public JSplitPane buildSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setOneTouchExpandable(true);
			splitPane.setLeftComponent(buildGroupPanel());
			splitPane.setRightComponent(CreatJTabbedPane1());
			splitPane.setDividerLocation(200);

		}
		return splitPane;
	}

	/**
	 * SplitPane�е������� group
	 * 
	 */
	public JScrollPane buildGroupPanel() {
		// ����������group���
		sp = new JScrollPane(new JGroupPanel(titledTabProperties, this,
				tabbedPanel));
		return sp;

	}

	/**
	 * �����˵���
	 * 
	 * @return
	 */

	public JMenuBar CreatJMenuBar() {
		JMenuBar jb = new JMenuBar();

		action = new ItemAction(this);
		JMenu jm = new JMenu("���ݿ����");
		JMenu softhelp = new JMenu("��������");

		JMenuItem out = new JMenuItem("����");
		out.addActionListener(action);
		JMenuItem in = new JMenuItem("����");
		in.addActionListener(action);
//		JMenuItem help = new JMenuItem("��������");
//		help.addActionListener(action);
		JMenuItem about_us = new JMenuItem("��������");
		about_us.addActionListener(action);

		jm.add(out);
		jm.add(in);
//		softhelp.add(help);
		softhelp.add(about_us);

		// jm.setMnemonic('f');
		// new1.setMnemonic('n');
		// open.setMnemonic('o');
		// save.setMnemonic('s');
		// exit.setMnemonic('e');
		jb.add(ChangeSkin());
		jb.add(createTabbedPanelMenu());
		jb.add(jm);
		jb.add(softhelp);
		return jb;
	}
///////////////////////////////////////////////
//	���޸�
	/**
	 * ����������
	 * 
	 * @return
	 */
	public JToolBar CreatJToolBar() {
		jt = new JToolBar();
		jt.setFloatable(false);
		FrameToolBarAction ftaction = new FrameToolBarAction(
				titledTabProperties, this, tabbedPanel);

		ImageIcon a1 = new ImageIcon("img/mainframe/001ѧ��������Ϣ����.png");
		ImageIcon a2 = new ImageIcon("img/mainframe/002��ʦ������Ϣ����.png");
		ImageIcon a3 = new ImageIcon("img/mainframe/003�γ̻�����Ϣ����.png");
		ImageIcon a4 = new ImageIcon("img/mainframe/004�ɼ�������Ϣ����.png");
		ImageIcon a5 = new ImageIcon("img/mainframe/005�༶��־��Ϣ����.png");
		ImageIcon a6 = new ImageIcon("img/mainframe/006����ɾ����ݰ�ť.png");
		ImageIcon a7 = new ImageIcon("img/mainframe/007�˳�ϵͳ.png");

		IsaleJButton b1 = new IsaleJButton("ѧ��������Ϣ����", a1);
		b1.addActionListener(ftaction);
		b1.setRolloverEnabled(true);
		b1.setRolloverIcon(a1);
		b1.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b2 = new IsaleJButton("��ʦ������Ϣ����", a2);
		b2.addActionListener(ftaction);
		b2.setRolloverEnabled(true);
		b2.setRolloverIcon(a2);
		b2.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b3 = new IsaleJButton("�γ̻�����Ϣ����", a3);
		b3.addActionListener(ftaction);
		b3.setRolloverEnabled(true);
		b3.setRolloverIcon(a3);
		b3.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b4 = new IsaleJButton("�ɼ�������Ϣ����", a4);
		b4.addActionListener(ftaction);
		b4.setRolloverEnabled(true);
		b4.setRolloverIcon(a4);
		b4.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b5 = new IsaleJButton("�༶��־��Ϣ����", a5);
		b5.addActionListener(ftaction);
		b5.setRolloverEnabled(true);
		b5.setRolloverIcon(a5);
		b5.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b6 = new IsaleJButton("����ɾ����ݰ�ť", a6);
		b6.addActionListener(ftaction);
		b6.setRolloverEnabled(true);
		b6.setRolloverIcon(a6);
		b6.setMargin(new Insets(0, 0, 0, 0));

		IsaleJButton b7 = new IsaleJButton("�˳�ϵͳ", a7);
		b7.addActionListener(ftaction);
		b7.setRolloverEnabled(true);
		b7.setRolloverIcon(a7);
		b7.setMargin(new Insets(0, 0, 0, 0));

		jt.add(b1);
		jt.add(b2);
		jt.add(b3);
		jt.add(b4);
		jt.add(b5);
		jt.add(b6);
		jt.add(b7);
		return jt;
	}
/////////////////////////////////////////////
	/**
	 * ��ǩҳ
	 * 
	 * @return
	 */

	public TabbedPanel CreatJTabbedPane1() {
		tabbedPanel
				.setTabAreaComponents(new JComponent[] { createCloseAllTabsButton(tabbedPanel) });
		tabbedPanel.addTab(createTab());
		tabbedPanel.getProperties().addSuperObject(
				activeTheme.getTabbedPanelProperties());
		titledTabProperties
				.addSuperObject(activeTheme.getTitledTabProperties());
		return tabbedPanel;

	}


	private JMenu createTabbedPanelMenu() {
		JMenu tabbedPanelMenu = new JMenu("��ǩѡ��");

		tabbedPanelMenu.add(createMenuItem("�򿪻�ӭ����",
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						TitledTab tab = createTab();
						tabbedPanel.addTab(tab);
						tabbedPanel.setSelectedTab(tab);
					}
				}));

		tabbedPanelMenu.add(new JSeparator());

		// ��ǩ��λ��ѡ��
		Direction[] directions = Direction.getDirections();
		for (int i = 0; i < directions.length; i++) {
			final Direction direction = directions[i];
			tabbedPanelMenu.add(createMenuItem("��ǩ��λ��: "
					+ direction.getName(), new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					tabbedPanel.getProperties()
							.setTabAreaOrientation(direction);
				}
			}));
		}

		return tabbedPanelMenu;
	}

	private JMenuItem createMenuItem(String text, ActionListener listener) {
		JMenuItem item = new JMenuItem(text);
		item.addActionListener(listener);
		return item;
	}

	private TitledTab createTab() {
		Example p1 = new Example();
		TitledTab tab = new TitledTab("ѧ������ϵͳ", null, p1.showWelcome(), null);
		tabId++;
		tab.setHighlightedStateTitleComponent(createCloseTabButton(tab));
		tab.getProperties().addSuperObject(titledTabProperties);
		return tab;
	}

	private JButton createXButton() {
		JButton closeButton = new JButton("X");
		closeButton.setOpaque(false);
		closeButton.setMargin(null);
		closeButton.setFont(closeButton.getFont().deriveFont(Font.BOLD)
				.deriveFont((float) 10));
		closeButton.setBorder(new EmptyBorder(1, 1, 1, 1));
		return closeButton;
	}

	public JButton createCloseTabButton(final TitledTab tab) {
		JButton closeButton = createXButton();
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Closing the tab by removing it from the tabbed panel it is a
				// member of
				tab.getTabbedPanel().removeTab(tab);
			}
		});
		return closeButton;
	}

	private JButton createCloseAllTabsButton(final TabbedPanel tabbedPanel) {
		final JButton closeButton = createXButton();
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Iterate over all tabs and remove them.
				int tabCount = tabbedPanel.getTabCount();
				for (int i = 0; i < tabCount; i++)
					tabbedPanel.removeTab(tabbedPanel.getTabAt(0));
			}
		});

		// Add a tab listener to the tabbed panel so that we know when tabs are
		// added
		// and removed so that the close button can be hidden when the tabbed
		// panel
		// doesn't contain any tabs.
		tabbedPanel.addTabListener(new TabAdapter() {
			public void tabAdded(TabEvent event) {
				closeButton.setVisible(true);
			}

			public void tabRemoved(TabRemovedEvent event) {
				// Hide the close button when there are no tabs in the tabbed
				// panel
				closeButton
						.setVisible(event.getTabbedPanel().getTabCount() > 0);
			}
		});
		return closeButton;
	}

}
