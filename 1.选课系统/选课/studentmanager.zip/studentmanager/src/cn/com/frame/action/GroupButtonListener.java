package cn.com.frame.action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalate;
import cn.com.dialog.classmanagerdialog.classmanager.ClassManager;
import cn.com.frame.Test;
import cn.com.panel.chivementpanel.ExamPanel;
import cn.com.panel.chivementpanel.OrdinaryPanel;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.panel.studentmanagerpanel.TeacherPanel;
import cn.com.studentsystem.classnews.ClassNews;
import cn.com.studentsystem.debt.Debt;
import cn.com.studentsystem.kaoqin.KaoQin;

public class GroupButtonListener implements ActionListener {
	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public GroupButtonListener(TitledTabProperties titledTabProperties,
			Test test, TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public void actionPerformed(ActionEvent e) {
		String str = e.getActionCommand();
		if (str.equals("")) {
		} else if (str.equals("ѧ��������Ϣ����")) {
			StudentPanel student = new StudentPanel();
			TitledTab tab = new TitledTab("ѧ��������Ϣ����", null, student, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("��ʦ������Ϣ����")) {
			TeacherPanel teacher = new TeacherPanel();
			TitledTab tab = new TitledTab("��ʦ������Ϣ����", null, teacher, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("        �γ�����        ")) {
			ClassIntercalate inter = new ClassIntercalate();
			inter.buildDialog("        �γ�����        ");
			TitledTab tab = new TitledTab("        �γ�����        ", null, inter.buildDialog("        �γ�����        "), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("        �γ̹���        ")) {
//			ClassManager manager = new ClassManager();
//			manager.buildPanel("        �γ̹���        ");
//			TitledTab tab = new TitledTab("        �γ̹���        ", null,manager.buildPanel("        �γ̹���        "), null);
//			tab.setHighlightedStateTitleComponent(test
//					.createCloseTabButton(tab));
//			tab.getProperties().addSuperObject(titledTabProperties);
//			tp.addTab(tab);
//			tp.setSelectedTab(tab);
         ClassManager panel1 = new ClassManager();
         JDialog panel2 = panel1.buildPanel("�γ̹���");
         panel2.setModal(true);
		} else if (str.equals("   ƽʱ�ɼ�����   ")) {
			OrdinaryPanel ordinary = new OrdinaryPanel();
			TitledTab tab = new TitledTab("ƽʱ�ɼ�����", null, ordinary, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("   ���Գɼ�����   ")) {
			ExamPanel exam = new ExamPanel();
			TitledTab tab = new TitledTab("���Գɼ�����", null, exam, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("   �༶������   ")) {
			TitledTab tab = new TitledTab("�༶������", null, new ClassNews(), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("   �༶���ڱ�   ")) {
			TitledTab tab = new TitledTab("�༶���ڱ�", null, new KaoQin(), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (str.equals("   �༶����   ")) {
			TitledTab tab = new TitledTab("�༶����", null, new Debt(), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		}
	}

}
