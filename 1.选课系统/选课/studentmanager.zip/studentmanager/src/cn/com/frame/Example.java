package cn.com.frame;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.io.*;
import com.jpackages.jflashplayer.*;

/**
 * Example code using JFlashPlayer
 * Copyright (c) 2001-2007
 * Company: VersaEdge Software, LLC
 */

public class Example extends JFrame implements FlashPanelListener {  
  // handle to main FlashPanel
  FlashPanel flashPanel;
  JPanel jPanelWelcome;

  // FlashPanelListener event method from Flash
  public void FSCommand(String command, String arg) {
    System.out.println("java FSCommand " + command + " " + arg);

    if (command.equals("javaLink")) {
      try {
        Runtime.getRuntime().exec("explorer " + arg);
      } catch (Exception e) {}
    }
    else if (command.equals("javaExecute")) {
      JOptionPane.showMessageDialog(this, "Flash events can be passed along to java");
    }
    
  }


  // display a welcome flash animation in a JDialog
  JPanel showWelcome() {
    // if the required flash version is not available, try to install one
    // Flash.ocx is not provided.  See documentation on where you can locate it.
    try {
      if (!FlashPanel.hasFlashVersion("6")) {
        boolean b = FlashPanel.installFlash(new File("Flash9b.ocx"));
        System.out.println("installed flash: " + b);
      }
    } catch (JFlashLibraryLoadFailedException e) {
      System.out.println(e);
    }

    // before constructing a FlashPanel, specify the required flash version for the flash animation
    FlashPanel.setRequiredFlashVersion("5");
    // create an alternate image to display on any errors
    Image imageWelcome = getImageOfString("Welcome", Color.blue);
    // construct a FlashPanel displaying the welcome.swf flash animation
    FlashPanel welcomePanel = new FlashPanel(new File("swf/main.swf"), imageWelcome);
    // disable animation looping
    welcomePanel.setLoop(false);
    jPanelWelcome = new JPanel(new BorderLayout());
    jPanelWelcome.add(welcomePanel, BorderLayout.CENTER);
    jPanelWelcome.setPreferredSize(new Dimension(740, 500));
//    JOptionPane.showMessageDialog(null, jPanelWelcome, "Welcome To JFlashPlayer", JOptionPane.PLAIN_MESSAGE);
	return jPanelWelcome;
  }

  // creates an Image displaying a String s of Color c
  static Image getImageOfString(String s, Color c) {
      BufferedImage myDemoImage = new BufferedImage(300,200,BufferedImage.TYPE_INT_ARGB);
      Graphics2D mygD = (Graphics2D)myDemoImage.getGraphics();
      mygD.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
      mygD.setColor(c);
      Font DemoTopFont = new Font("Dialog",Font.BOLD,60);
      mygD.setFont(DemoTopFont);
      mygD.drawString(s,20,120);

      return myDemoImage;
  }


  //Main method
//  public static void main(String[] args) {
//    showWelcome();
//
//  }

}