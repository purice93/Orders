package cn.com.frame.button;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.Action;
import javax.swing.ImageIcon;
@SuppressWarnings("serial")
public class IsaleJButton extends JButton{
     public IsaleJButton(Action a){
    }
    public IsaleJButton(Icon icon){
        super(icon);
    }
    public IsaleJButton(String text){
        super(text);
    }   
    public IsaleJButton(String text,Icon iconimage){
        super(text,iconimage);
        setHorizontalTextPosition(SwingConstants.CENTER);
        setVerticalTextPosition(SwingConstants.BOTTOM);
    }
    public IsaleJButton(String text,String iconimageName){
        super(text);
        Icon noSelectImage=new ImageIcon(iconimageName);
        setIcon(noSelectImage);
        setHorizontalTextPosition(SwingConstants.CENTER);
        setVerticalTextPosition(SwingConstants.BOTTOM);
    }
    
}