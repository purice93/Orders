package cn.com.frame.action;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import net.infonode.tabbedpanel.TabbedPanel;
import net.infonode.tabbedpanel.titledtab.TitledTab;
import net.infonode.tabbedpanel.titledtab.TitledTabProperties;
import cn.com.frame.Test;
import cn.com.panel.chivementpanel.ChivementPanel;
import cn.com.panel.classmanagerpanel.ClassPanel;
import cn.com.panel.studentmanagerpanel.StudentPanel;
import cn.com.panel.studentmanagerpanel.TeacherPanel;
import cn.com.studentsystem.classmanager.ClassDesk;

public class FrameToolBarAction implements ActionListener {

	
	private Test test;

	private TabbedPanel tp;

	private TitledTabProperties titledTabProperties;

	public FrameToolBarAction(TitledTabProperties titledTabProperties,
			Test test, TabbedPanel tp) {
		this.titledTabProperties = titledTabProperties;
		this.test = test;
		this.tp = tp;
	}

	public void actionPerformed(ActionEvent e) {
		String s = e.getActionCommand();
		StudentPanel student = null;
		if (s.equals("ѧ��������Ϣ����")) {
			TitledTab tab = null;
			if(student == null){
			 student = new StudentPanel();
			 tab = new TitledTab(s, null, student, null);
				tab.setHighlightedStateTitleComponent(test
						.createCloseTabButton(tab));
				tab.getProperties().addSuperObject(titledTabProperties);
				tp.addTab(tab);
			}
			
			// ��ǰ��ʾ�����ı�ǩҳ
			tp.setSelectedTab(tab);

		} else if (s.equals("��ʦ������Ϣ����")) {
			TeacherPanel teacher = new TeacherPanel();
			TitledTab tab = new TitledTab(s, null, teacher, null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (s.equals("�γ̻�����Ϣ����")) {
			ClassPanel classes = new ClassPanel(titledTabProperties,test,tp);
			TitledTab tab = new TitledTab(s, null, classes.buildPanel(), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (s.equals("�ɼ�������Ϣ����")) {
			ChivementPanel chivement = new ChivementPanel(titledTabProperties,test,tp);
			JPanel p = chivement.ChivementPanel();
			
			TitledTab tab = new TitledTab(s, null,p , null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (s.equals("�༶��־��Ϣ����")) {
			ClassDesk classdesk = new ClassDesk(titledTabProperties,test,tp);
			TitledTab tab = new TitledTab(s, null, classdesk.init(), null);
			tab.setHighlightedStateTitleComponent(test
					.createCloseTabButton(tab));
			tab.getProperties().addSuperObject(titledTabProperties);
			tp.addTab(tab);
			tp.setSelectedTab(tab);
		} else if (s.equals("����ɾ����ݰ�ť")) {
			JDialog dialog=test.creatdialog();
			dialog.setLocationRelativeTo(null);
			dialog.setVisible(true);
		} else if (s.equals("�˳�ϵͳ")) {
			int ch = JOptionPane.showConfirmDialog(null, "���Ƿ����Ҫ�˳�ϵͳ",
					"�ر�ȷ����", JOptionPane.YES_NO_OPTION);
			if (ch == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		} else {
			javax.swing.JOptionPane.showMessageDialog(null, "�����Ƿ���");
		}

	}

}
