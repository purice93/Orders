package cn.com.dao.studentmanagerdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import cn.com.util.DBConnection;
import cn.com.util.DBSql;
import cn.com.vo.studentmanagervo.TeacherVo;

public class TeacherHighSelectDao {
	private Connection conn = DBConnection.getConnectionOracle();

	private TeacherVo teacherVo;

	public TeacherHighSelectDao() {

	}

	public TeacherHighSelectDao(TeacherVo teacherVo) {
		this.teacherVo = teacherVo;
	}
	
	public Object[][] select011 () {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_TEACHER_011);
			ps.setInt(1, teacherVo.getT_id());
			ps.setString(2, teacherVo.getT_duty());
			ps.setString(3, "%" + teacherVo.getT_duty() + "%");
			ps.setString(4, "%" + teacherVo.getT_duty());
			ps.setString(5, teacherVo.getT_duty() + "%");
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	public Object[][] select101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_TEACHER_101);
			ps.setString(1, teacherVo.getT_name());
			ps.setString(2, "%" + teacherVo.getT_name() + "%");
			ps.setString(3, "%" + teacherVo.getT_name());
			ps.setString(4, teacherVo.getT_name() + "%");
			ps.setInt(5, teacherVo.getT_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public Object[][] select110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_TEACHER_110);
			ps.setString(1, teacherVo.getT_name());
			ps.setString(2, "%" + teacherVo.getT_name() + "%");
			ps.setString(3, "%" + teacherVo.getT_name());
			ps.setString(4, teacherVo.getT_name() + "%");
			ps.setString(5, teacherVo.getT_duty());
			ps.setString(6, "%" + teacherVo.getT_duty() + "%");
			ps.setString(7, "%" + teacherVo.getT_duty());
			ps.setString(8, teacherVo.getT_duty() + "%");
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	public Object[][] select111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_TEACHER_111);
			ps.setString(1, teacherVo.getT_name());
			ps.setString(2, "%" + teacherVo.getT_name() + "%");
			ps.setString(3, "%" + teacherVo.getT_name());
			ps.setString(4, teacherVo.getT_name() + "%");
			ps.setString(5, teacherVo.getT_duty());
			ps.setString(6, "%" + teacherVo.getT_duty() + "%");
			ps.setString(7, "%" + teacherVo.getT_duty());
			ps.setString(8, teacherVo.getT_duty() + "%");
			ps.setInt(9, teacherVo.getT_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	

}
