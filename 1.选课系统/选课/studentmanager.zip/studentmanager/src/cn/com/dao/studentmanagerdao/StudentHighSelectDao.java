package cn.com.dao.studentmanagerdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import cn.com.util.DBConnection;
import cn.com.util.DBSql;
import cn.com.vo.studentmanagervo.StudentVo;

public class StudentHighSelectDao {
	private Connection conn = DBConnection.getConnectionOracle();

	private StudentVo examVo;

	public StudentHighSelectDao() {

	}

	public StudentHighSelectDao(StudentVo examVo) {
		this.examVo = examVo;
	}

	public Object[][] select011() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		int k = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Vector vo = new Vector();
		try {
			ps = conn.prepareStatement(DBSql.SELECT_STU_011);
			ps.setInt(1, examVo.getG_id());
			ps.setInt(2, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if (vo.size() > 0) {
				date = new Object[vo.size() / max][max];
				for (i = 0; i < vo.size() / max; i++) {
					for (int j = 0; j < max; j++) {
						date[i][j] = vo.get(k);
						k++;
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	public Object[][] select101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		int k = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Vector vo = new Vector();
		try {
			ps = conn.prepareStatement(DBSql.SELECT_STU_101);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if (vo.size() > 0) {
				date = new Object[vo.size() / max][max];
				for (i = 0; i < vo.size() / max; i++) {
					for (int j = 0; j < max; j++) {
						date[i][j] = vo.get(k);
						k++;
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	public Object[][] select110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_STU_110);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if (vo.size() > 0) {
				date = new Object[vo.size() / max][max];
				for (i = 0; i < vo.size() / max; i++) {
					for (int j = 0; j < max; j++) {
						date[i][j] = vo.get(k);
						k++;
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	public Object[][] select111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_STU_111);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if (vo.size() > 0) {
				date = new Object[vo.size() / max][max];
				for (i = 0; i < vo.size() / max; i++) {
					for (int j = 0; j < max; j++) {
						date[i][j] = vo.get(k);
						k++;
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

}
