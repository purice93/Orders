package cn.com.dao.chivementdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import cn.com.util.DBConnection;
import cn.com.util.DBSql;
import cn.com.vo.chivementvo.ChivementVo;

public class ExamHighSelectDao {
	private Connection conn = DBConnection.getConnectionOracle();

	private ChivementVo examVo;

	public ExamHighSelectDao() {

	}

	public ExamHighSelectDao(ChivementVo examVo) {
		this.examVo = examVo;
	}
	
	
	
	
	
	
	public Object[][] select00011() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_00011);
			ps.setInt(1, examVo.getS_id());
			ps.setInt(2, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select00101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_00101);
			ps.setInt(1, examVo.getG_id());
			ps.setInt(2, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select00110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_00110);
			ps.setInt(1, examVo.getG_id());
			ps.setInt(2, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select00111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_00111);
			ps.setInt(1, examVo.getG_id());
			ps.setInt(2, examVo.getS_id());
			ps.setInt(3, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select01001() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01001);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select01010() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01010);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select01011() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01011);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getS_id());
			ps.setInt(6, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select01100() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01100);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	public Object[][] select01101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01101);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select01110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01110);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	public Object[][] select01111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_01111);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getS_id());
			ps.setInt(7, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select10001() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10001);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	

	
	
	public Object[][] select10010() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10010);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	
	public Object[][] select10011() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10011);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getS_id());
			ps.setInt(6, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	
	public Object[][] select10100() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10100);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getG_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	
	public Object[][] select10101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10101);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	
	public Object[][] select10110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10110);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getS_id());
			ps.setInt(6, examVo.getG_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	
	public Object[][] select10111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_10111);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getS_id());
			ps.setInt(7, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	
	public Object[][] select11000() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11000);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(5, examVo.getG_id());
			ps.setInt(6, examVo.getS_id());
			ps.setInt(7, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}


	
	
	
	public Object[][] select11001() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11001);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11010() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11010);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11011() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11011);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getS_id());
			ps.setInt(10, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11100() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11100);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getG_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11101() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11101);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getG_id());
			ps.setInt(10, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11110() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11110);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getG_id());
			ps.setInt(10, examVo.getS_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	
	public Object[][] select11111() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_11111);
			ps.setString(1, examVo.getClass_name());
			ps.setString(2, "%" + examVo.getClass_name() + "%");
			ps.setString(3, "%" + examVo.getClass_name());
			ps.setString(4, examVo.getClass_name() + "%");
			ps.setString(5, examVo.getS_name());
			ps.setString(6, "%" + examVo.getS_name() + "%");
			ps.setString(7, "%" + examVo.getS_name());
			ps.setString(8, examVo.getS_name() + "%");
			ps.setInt(9, examVo.getG_id());
			ps.setInt(10, examVo.getS_id());
			ps.setInt(11, examVo.getC_id());
			rs = ps.executeQuery();
			max = rs.getMetaData().getColumnCount();
			int k = 0;
			Vector vo = new Vector();
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					vo.add(rs.getObject(j + 1));
				}
				i++;
			}
			if(vo.size()>0){
				date = new Object[vo.size()/max][max];
				for(i=0;i<vo.size()/max;i++){
					for (int j = 0; j < max; j++) {
						date[i][j]=vo.get(k);
						k++;
					}
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	
	
	
	

}
