package cn.com.dao.classmanagerdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import cn.com.dialog.classmanagerdialog.classintercalate.ClassIntercalateAdd;
import cn.com.dialog.classmanagerdialog.classintercalate.ClassUpdate;
import cn.com.util.DBConnection;
import cn.com.util.calsssystemcommon.ClassSystemDBsql;
import cn.com.vo.classmanagervo.ClassStudentVo;
import cn.com.vo.classmanagervo.ClassVO;

public class Impl {
	/**
	 * �����µĿγ�
	 * 
	 * @param vo
	 * @return
	 */
	public boolean appendClass(ClassVO vo) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		if (checkClassExit(conn, vo.getClassID())) {
			JOptionPane.showMessageDialog(null, "�γ̱���Ѿ����ڣ�����������!");
		}
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_APPEND);
			pstmt.setInt(1, vo.getClassID());
			pstmt.setString(2, vo.getClassname());
			pstmt.setInt(3, vo.getCredithour());
			pstmt.setInt(4, vo.getTotaltime());
			pstmt.setString(5, vo.getClassestate());
			pstmt.setString(6, vo.getClasstime());
			pstmt.setInt(7, vo.getTeacherID());
			pstmt.setString(8, vo.getClassremark());
			int count = pstmt.executeUpdate();
			if (count != 0) {
				flag = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 * �޸Ŀγ���Ϣ
	 */
	public boolean updateClass(ClassVO vo) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.C_T_UPDATE);
			pstmt.setString(1, vo.getClassname());
			pstmt.setInt(2, vo.getCredithour());
			pstmt.setInt(3, vo.getTotaltime());
			pstmt.setString(4, vo.getClassestate());
			pstmt.setInt(5, vo.getTeacherID());
			pstmt.setString(6, vo.getClasstime());
			pstmt.setString(7, vo.getClassremark());
			pstmt.setInt(8, vo.getClassID());
			int count = pstmt.executeUpdate();
			if (count != 0) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 * ɾ����ѡ��Ŀγ���Ϣ
	 */
	public boolean classDelete(int classNo) {
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_DELETE);
			pstmt.setInt(1, classNo);
			int count = pstmt.executeUpdate();
			if (count != 0) {
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 * ����ѧ�Ų���ѧ����Ϣ
	 */
	public ResultSet stuFind(int stuNo) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.STU_FIND);
			pstmt.setInt(1, stuNo);
			set = pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return set;

	}

	/**
	 * ����ѧ�Ų�����ѡ�γ�
	 */
	public Object[][] FindC_TByNo(int stuNo) {
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn
					.prepareStatement(" select c.classnum,classname,totaltime,classtime,credithour,classestate,t.t_id,t_name,t_duty,classremake from studentinfotable s,"
							+ " classtable c,studentexamchivement e,teacherinfotable t "
							+ "where s.s_id = e.s_id and e.classnum = c.classnum and c.t_id = t.t_id and s.s_id = ? order by s.s_id");
			pstmt.setInt(1, stuNo);
			set = pstmt.executeQuery();
			int i = 0;
			int number = getNumberByNo(stuNo);
			int max = set.getMetaData().getColumnCount();
			data = new Object[number][max];
			while (set.next()) {
				for (int j = 0; j < max; j++) {
					data[i][j] = set.getObject(j + 1);
				}
				i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;

	}

	/**
	 * ������ʦ��Ų���������������
	 * 
	 * @param teacherNo
	 * @return
	 */
	public static String findTeacherByNo(int teacherNo) {
		String name = null;

		PreparedStatement pstmt = null;
		Connection con = null;
		ResultSet set = null;
		try {
			con = DBConnection.getConnectionOracle();
			pstmt = con.prepareStatement(ClassSystemDBsql.T_NAME_FIND);
			pstmt.setInt(1, teacherNo);
			set = pstmt.executeQuery();
			if (set.next()) {
				name = set.getString(1);
			}

		} catch (Exception e) {
			System.out.println("���ݱ�Ų�����ʦdao�쳣��" + e.getMessage());
		}
		return name;
	}

	/**
	 * �������Ŀγ̱���Ƿ����
	 * 
	 * @param con
	 * @param classNo
	 * @return
	 */
	private boolean checkClassExit(Connection coon, int classNo) {
		boolean flag = false;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		try {
			pstmt = coon.prepareStatement(ClassSystemDBsql.CLASS_SELECT);
			pstmt.setInt(1, classNo);
			set = pstmt.executeQuery();
			while (set.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}
	/**
	 * �������Ŀγ̱���Ƿ����
	 * 
	 * @param con
	 * @param classNo
	 * @return
	 */
	public boolean checkClassEx( int classNo) {
		boolean flag = false;
		Connection coon = DBConnection.getConnectionOracle();
		PreparedStatement pstmt = null;
		ResultSet set = null;
		try {
			pstmt = coon.prepareStatement(ClassSystemDBsql.CLASS_SELECT);
			pstmt.setInt(1, classNo);
			set = pstmt.executeQuery();
			while (set.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return flag;
	}

	/**
	 * ѧ��ѡ��
	 * @param stuNo
	 * @param classNo
	 * @return
	 */
	public boolean classChooseByStu(int stuNo,int classNo){
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_CHOOSE);
			pstmt.setInt(1, stuNo);
			pstmt.setInt(2, classNo);
			int count = pstmt.executeUpdate();
			if(count != 0){
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
		
	}
	/**
	 * 
	 * @param classNo
	 * @return
	 */
	public static ResultSet classinfo(int classNo) {
		PreparedStatement pstmt = null;
		Connection conn = null;
		ResultSet set = null;
		try {
			conn = DBConnection.getConnectionOracle();
			pstmt = conn.prepareStatement(ClassSystemDBsql.C_T_FIND);
			pstmt.setInt(1, classNo);
			set = pstmt.executeQuery();
		} catch (Exception e) {
			System.out.println("���ݱ�Ų�����ʦdao�쳣��" + e.getMessage());
		}
		return set;
	}

	/**
	 * �������еĿγ���Ϣ��ִ����ʦ��Ϣ
	 * 
	 * @return
	 */
	public Object[][] getClassInfo() {
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.ALLCLASS_INFO);
			set = pstmt.executeQuery();
			int max = set.getMetaData().getColumnCount();
			int number = getNumber();
			System.out.println(number);
			int i = 0;
			data = new Object[number][max];
			while (set.next()) {
				for (int j = 0; j < max; j++) {
					data[i][j] = set.getObject(j + 1);
				}
				i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

	/**
	 * ��ÿγ̵�����Ŀ
	 */
	public int getNumber() {
		int number = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_DATA);
			set = pstmt.executeQuery();
			set.next();
			number = set.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * ������ʦ��Ż�ÿγ̵�����Ŀ
	 */
	public int getNumberByTNo(int t_id) {
		int number = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.T_COUNT);
			pstmt.setInt(1, t_id);
			set = pstmt.executeQuery();
			set.next();
			number = set.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * ����ѧ�Ż�ÿγ̵�����Ŀ
	 */
	public int getNumberByNo(int stuNo) {
		int number = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn
					.prepareStatement("select count(*) from studentinfotable s, classtable c,studentexamchivement e,"
							+ "teacherinfotable t where s.s_id = e.s_id and e.classnum = c.classnum and "
							+ "c.t_id = t.t_id and s.s_id = ? order by s.s_id");
			pstmt.setInt(1, stuNo);
			set = pstmt.executeQuery();
			set.next();
			number = set.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * ������ʦ��Ų�ѯ�����̿γ�
	 */
	public Object[][] ClassFindByTNo(int t_id) {
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.FINDCLASS_BYTNO);
			pstmt.setInt(1, t_id);
			set = pstmt.executeQuery();
			int number = getNumberByTNo(t_id);
			int max = set.getMetaData().getColumnCount();
			data = new Object[number][max];
			int i = 0;
			while (set.next()) {
				for (int j = 0; j < max; j++) {
					data[i][j] = set.getObject(j + 1);
				}
				i++;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
	}

	/**
	 * ��ѯ���еĿγ�
	 */
	public Object[][] allClassFind() {
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.ALLCLASS_FIND);
			set = pstmt.executeQuery();
			int max = set.getMetaData().getColumnCount();
			int row = getNumber();
			int i = 0;
			data = new Object[row][max];
			while (set.next()) {
				for (int j = 0; j < max; j++) {
					data[i][j] = set.getObject(j + 1);
				}
				i++;

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
	}
	
	/**
	 * �����״εǼ�
	 */
	public boolean classBook(int classNo,int stuNo,String className){
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_BOOK);
			pstmt.setInt(1, classNo);
			pstmt.setInt(2, stuNo);
			pstmt.setString(3,className);
			pstmt.setInt(4, 1);
			int count = pstmt.executeUpdate();
			if(count != 0){
			}flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 *һ��ѧ�����пγ̳������
	 */
	public Object[][] momerizeABookTime(int stuNo){
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.BRETRAY_FIND);
			pstmt.setInt(1, stuNo);
			set = pstmt.executeQuery();
			int number = getNumberBySNo(stuNo);
			data = new Object[number][3];
			int i= 0;
			while(set.next()){
				for(int j= 0;j< 3;j++){
					data[i][j] = set.getObject(j+1);
				}
				i++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	/**
	 * ��¼�ǼǴ���
	 */
	public boolean momerizeBookTime(int stuNo,int classNo){
		boolean flag = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASS_BOOKTIME);
			pstmt.setInt(1, stuNo);
			pstmt.setInt(2, classNo);
			int count = pstmt.executeUpdate();
			if(count != 0){
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * �����ѡѧ�������������Ϣ
	 */
	public Object[][] classBookInfo(int stuNo, int classNo){
		Object[][] data = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.BOOKTIME_FIND);
			pstmt.setInt(1, stuNo);
			pstmt.setInt(2, classNo);
			set = pstmt.executeQuery();
			System.out.println(stuNo+"����"+classNo);
			int row = getClassCount(stuNo,classNo);
			System.out.println(row);
			int i = 0;
			int column = set.getMetaData().getColumnCount();
			data = new Object[row][column];
			while(set.next()){
				for(int j = 0;j<column;j++){
					data[i][j] = set.getObject(j+1);
				}
				i++;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
	/**
	 * һ��ѧ��ѡ�Ŀγ���
	 * @param s_id
	 * @return
	 */
	public int getNumberBySNo(int s_id) {
		int number = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASSCOUNT);
			pstmt.setInt(1, s_id);
			set = pstmt.executeQuery();
			set.next();
			number = set.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
	}
	/**
	 * �õ��еǼǼ�¼�Ŀγ�����
	 */
	public int getClassCount(int stuNo,int classNo){
		int number  = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet set = null;
		conn = DBConnection.getConnectionOracle();
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASSBOOK_COUNT);
			System.out.println("stuNo =����"+stuNo);
			pstmt.setInt(1,stuNo);
			pstmt.setInt(2, classNo);
			set = pstmt.executeQuery();
			set.next();
			number = set.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return number;
		
	}
	/**
	 * �ѻ�õ���Ϣ����StudentVo��
	 * 
	 * @param set
	 * @return
	 * @throws SQLException
	 */

	public ClassStudentVo setLableInfo(ResultSet set) throws SQLException {
		ClassStudentVo vo = new ClassStudentVo();
		while (set.next()) {
			vo.setStu_ID(set.getInt(1));
			vo.setG_No(set.getInt(2));
			vo.setStu_name(set.getString(3));
			vo.setStu_sex(set.getString(4));
			vo.setGrade(set.getString(5));
			vo.setSchool(set.getString(6));
			vo.setSpeciality(set.getString(7));
			vo.setStu_tel(set.getInt(8));
			vo.setQqNo(set.getInt(9));
			vo.setStu_email(set.getString(10));
		}
		return vo;
	}
	
	/**
	 * �����γ̵Ĳ�����Ϣ
	 */
	public ClassVO classPInfo(int classNo){
		ClassVO vo = new ClassVO();
		Connection conn = DBConnection.getConnectionOracle();
		PreparedStatement pstmt = null;
		ResultSet set = null;
		try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.CLASSINFO_PART);
			pstmt.setInt(1, classNo);
			set = pstmt.executeQuery();
			while(set.next()){
				vo.setClassID(set.getInt(1));
				vo.setClassname(set.getString(2));
				vo.setClasstime(set.getString(3));
				vo.setCredithour(set.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return vo;
	}
	/**
	 * ���γ��Ƿ��й��״εǼ�
	 * @param classNo
	 * @param stuNo
	 * @return
	 */
	 public boolean checkClassBook(int stuNo, int classNo){
		    boolean flag = false;
		    Connection conn = DBConnection.getConnectionOracle();
		    PreparedStatement pstmt = null;
		    ResultSet set = null;
		    try{
		      pstmt = conn.prepareStatement(ClassSystemDBsql.BOOKTIME_FIND);
		      pstmt.setInt(1,stuNo);
		      pstmt.setInt(2,classNo);
		      set = pstmt.executeQuery();
		      if(set.next()){
		        flag = true;
		      }
		    }catch(SQLException e){
		      System.out.println(e.getMessage());
		    }
		    return flag;
		  }
	 /**
	  * �����ʦ�Ƿ����
	  */
	 public boolean checkTeacher(int t_id){
		 boolean flag =  false;
		 Connection conn = DBConnection.getConnectionOracle();
		 PreparedStatement pstmt = null;
		 ResultSet set = null;
		 try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.TEA_CHECK);
			pstmt.setInt(1, t_id);
			set = pstmt.executeQuery();
			while(set.next()){
				flag = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return flag;
	 }
	 /**
	  * ���ѧ���Ƿ����
	  */
	 public boolean checkStudent(int s_id){
		 boolean flag =  false;
		 Connection conn = DBConnection.getConnectionOracle();
		 PreparedStatement pstmt = null;
		 ResultSet set = null;
		 try {
			 pstmt = conn.prepareStatement(ClassSystemDBsql.STU_CHECK);
			 pstmt.setInt(1, s_id);
			 set = pstmt.executeQuery();
			 while(set.next()){
				 flag = true;
			 }
		 } catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return flag;
	 }
	 
	 /**
	  * �������е���ʦ���,��żӵ����������
	  */
	 public void findTeacherNo(){
		 Connection conn = DBConnection.getConnectionOracle();
		 PreparedStatement pstmt = null;
		 ResultSet set = null;
		 try {
			pstmt = conn.prepareStatement(ClassSystemDBsql.TEA_N_N_FIND);
			set = pstmt.executeQuery();
			while(set.next()){
				ClassIntercalateAdd.c4.addItem(set.getInt(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 /**
	  * �������е���ʦ���,��żӵ��޸������
	  */
	 public void findTeacherNo1(){
		 Connection conn = DBConnection.getConnectionOracle();
		 PreparedStatement pstmt = null;
		 ResultSet set = null;
		 try {
			 pstmt = conn.prepareStatement(ClassSystemDBsql.TEA_N_N_FIND);
			 set = pstmt.executeQuery();
			 while(set.next()){
				 ClassUpdate.c4.addItem(set.getInt(1));
			 }
		 } catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
	 }
	 public boolean classDeleteChoose(int stuNo,int classNo){
		 boolean flag =  false;
		 Connection conn = DBConnection.getConnectionOracle();
		 PreparedStatement pstmt = null;
		
		 try {
			 pstmt = conn.prepareStatement(ClassSystemDBsql.CLASSDELETE_CHOOSE);
			 pstmt.setInt(1, stuNo);
			 pstmt.setInt(2, classNo);
			 int count = pstmt.executeUpdate();
			 if(count != 0){
				 flag = true;
			 }
		 } catch (SQLException e) {
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		 }
		 return flag;
	 }
}
