package cn.com.dao.chivementdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.com.util.DBConnection;
import cn.com.util.DBSql;
import cn.com.vo.chivementvo.ChivementVo;

public class OrdinaryDao {

	private Connection conn = DBConnection.getConnectionOracle();

	private ChivementVo examVo;

	public OrdinaryDao() {

	}

	public OrdinaryDao(ChivementVo examVo) {
		super();
		this.examVo = examVo;
	}

	/**
	 * ȫ����ѯ
	 */
	public Object[][] selectAll() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_OR_ALL);
			rs = ps.executeQuery();
			// �õ�����
			max = rs.getMetaData().getColumnCount();
			date = new Object[getnumberAll(DBSql.SELECT_OR_ALL_COUNT)][max];
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					date[i][j] = rs.getObject(j + 1);
				}
				i++;
			}
			// rs.close();
			// ps.close();
			// conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * ����ѧ�Ų�ѯ
	 */
	public Object[][] selectBySid() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_OR_BY_S_ID);
			ps.setInt(1, examVo.getS_id());
			rs = ps.executeQuery();
			// �õ�����
			max = rs.getMetaData().getColumnCount();
			date = new Object[getnumber(DBSql.SELECT_OR_BY_S_ID_COUNT, examVo
					.getS_id())][max];
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					date[i][j] = rs.getObject(j + 1);
				}
				i++;
			}
			// rs.close();
			// ps.close();
			// conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	/**
	 * ������Ų�ѯ
	 */
	public Object[][] selectByGid() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_OR_BY_G_ID);
			ps.setInt(1, examVo.getG_id());
			rs = ps.executeQuery();
			// �õ�����
			max = rs.getMetaData().getColumnCount();
			date = new Object[getnumber(DBSql.SELECT_OR_BY_G_ID_COUNT, examVo
					.getG_id())][max];
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					date[i][j] = rs.getObject(j + 1);
				}
				i++;
			}
			// rs.close();
			// ps.close();
			// conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}


	/**
	 * ��������ģ����ѯ
	 * 
	 * @return
	 */
	public Object[][] selectByName() {
		Object date[][] = null;
		int max = 0;
		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.SELECT_OR_BY_S_NAME);
			ps.setString(1, examVo.getS_name());
			ps.setString(2, "%" + examVo.getS_name() + "%");
			ps.setString(3, "%" + examVo.getS_name());
			ps.setString(4, examVo.getS_name() + "%");
			rs = ps.executeQuery();
			// �õ�����
			max = rs.getMetaData().getColumnCount();
			date = new Object[getnumberByName(DBSql.SELECT_OR_BY_S_NAME_COUNT,
					examVo.getS_name())][max];
			while (rs.next()) {
				for (int j = 0; j < max; j++) {
					date[i][j] = rs.getObject(j + 1);
				}
				i++;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}

	

	/**
	 * �޸�ѡ��ѧ���ĳɼ�
	 * 
	 */
	public void updatSelectClass() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(DBSql.UPDATE_OR_BY_STUID);
			ps.setInt(1, examVo.getClassExamChivement());
			ps.setInt(2, examVo.getS_id());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	


	/**
	 * �޸�����ѧ��ƽʱ�ɼ� ��ѯѧ�� ���� �ɼ�
	 * 
	 */
	public void SelectClassStuName() {

		int i = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int j = getnumberAll(
				DBSql.SELECT_OR_STU_SNO_SNAME_EXAM_COUNT);
		int[] sNum = new int[j];
		String[] sName = new String[j];
		int[] ordinary = new int[j];
		try {
			ps = conn.prepareStatement(DBSql.SELECT_OR_STU_SNO_SNAME_EXAM);

			rs = ps.executeQuery();
			while (rs.next()) {
				sNum[i] = rs.getInt(1);
				sName[i] = rs.getString(2);
				ordinary[i] = rs.getInt(3);
				i++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		examVo.setSid(sNum);
		examVo.setSname(sName);
		examVo.setClassExam(ordinary);

	}

	/**
	 * �޸�����ѧ��ƽʱ�ɼ�
	 * 
	 */
	//////////////////////////////////////////////////////////////////
	public void UpdateClassStuName() {
		PreparedStatement ps = null;
		int j = getnumberAll(
				DBSql.SELECT_OR_STU_SNO_SNAME_EXAM_COUNT);
		try {
			ps = conn.prepareStatement(DBSql.UPDATE_OR_BY_CLASS);
			for(int i =0;i<j;i++){
				ps.setInt(1, examVo.getClassExam()[i]);
				ps.setInt(2, examVo.getSid()[i]);
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * ȫ����ѯ�������
	 * 
	 * @return
	 */
	public int getnumberAll(String str) {
		int number = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(str);
			rs = ps.executeQuery();
			rs.next();
			number = rs.getInt(1);
			// rs.close();
			// ps.close();
			// conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * ����ѧ�� ������� ���ݿγ̺Ų�ѯ �������
	 * 
	 * @return
	 */
	public int getnumber(String str, int i) {
		int number = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(str);
			ps.setInt(1, i);
			rs = ps.executeQuery();
			rs.next();
			number = rs.getInt(1);
			// rs.close();
			// ps.close();
			// conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * �������� �γ��� ��ѯ �������
	 * 
	 */

	public int getnumberByName(String str, String i) {
		int number = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(str);
			ps.setString(1, i);
			ps.setString(2, "%" + i + "%");
			ps.setString(3, "%" + i);
			ps.setString(4, i + "%");
			rs = ps.executeQuery();
			rs.next();
			number = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return number;
	}

	// /**
	// * ���ݿγ�����ѯ �������
	// *
	// */
	//
	// public int getnumberByClassName(String str, String i) {
	// int number = 0;
	// PreparedStatement ps = null;
	// ResultSet rs = null;
	// try {
	// ps = conn.prepareStatement(str);
	// ps.setString(1, i);
	// ps.setString(2, "%" + i + "%");
	// ps.setString(3, "%" + i);
	// ps.setString(4, i + "%");
	// rs = ps.executeQuery();
	// rs.next();
	// number = rs.getInt(1);
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// return number;
	// }
	/**
	 * 
	 * ���ݿγ����޸ĳɼ��������
	 * 
	 * @param str
	 * @param i
	 * @return
	 */
	public int getnumberBySelectClassName(String str, int i) {
		int number = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = conn.prepareStatement(str);
			ps.setInt(1, i);
			rs = ps.executeQuery();
			rs.next();
			number = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return number;
	}
}
