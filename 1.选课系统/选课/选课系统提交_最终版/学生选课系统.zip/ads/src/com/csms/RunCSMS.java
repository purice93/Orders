package com.csms;
 
import com.csms.windows.LoginWindow;

// ��ʼ������
public class RunCSMS {
    public static void main(String[] args) {
        new LoginWindow();   
    }
}