package com.csms;
 
import com.csms.windows.LoginWindow;

public class RunCSMS {
    public static void main(String[] args) {
        new LoginWindow();   
    }
}