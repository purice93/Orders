package gehege;

public class Landsaeugetiergehege extends Gehege{
	 private final static String art = "Landsaeugetier";
	 
    public Landsaeugetiergehege (String name)
    {
    	super(name,art);
    }
    
}