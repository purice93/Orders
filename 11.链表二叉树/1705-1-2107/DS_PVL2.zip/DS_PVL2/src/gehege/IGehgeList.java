package gehege;

import list.*;
import tiere.TierList;

public interface IGehgeList extends MyListIterator {
	
	public TierList getTier();
	public int getTierindex();
	
	public String getName();
	public String getArt();
	public GehegeList getNext();

}
