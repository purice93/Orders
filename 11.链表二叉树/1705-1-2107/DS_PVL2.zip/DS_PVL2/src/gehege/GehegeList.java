package gehege;
import list.*;
import tiere.TierList;

public class GehegeList extends MyLinkedList {
	
		
	public GehegeList(String name, String art, MyLinkedList next) 
	{
		super(name, art, next);
	}
	
	
	private TierList tier = new TierList(name, art, null);
	private int Tierindex = tier.size(); 
	private String TierArt;
	
	
	
	public TierList getTier() {
		return tier;
	}

	public void setTier(TierList tier) {
		this.tier = tier;
	}

	public int getTierindex() {
		return Tierindex;
	}

	public void setTierindex(int tierindex) {
		Tierindex = tierindex;
	}
	
	TierList headtier = null;
	
	public String getTierArt (GehegeList gehege)
	{
		if(gehege.Tierindex == 0) TierArt ="noch kein Tier in dieser Gehege Leben";
		TierList t = headtier;
		while (t != null)
		{
			TierArt = headtier.getArt();
		}
		return TierArt;	
	}
	
	
	public String getTierListe(GehegeList gehege) { 
    	String tierListe = "";
    	if(gehege.Tierindex == 0) tierListe ="noch kein Tier in dieser Gehege Leben";
    	
    	TierList t = headtier;
    	
    	while (t !=null)
    	{
    		tierListe = tierListe.concat(t.getName());
    		t = (TierList) t.getNext();
    	}
    			
		return tierListe;
	}

	public boolean compareTierUndGehege (TierList tier, GehegeList gehege)
	{
		if(gehege.getArt() == "Landsaeugetiergehege" && (tier.getArt() == "Zebra" ||tier.getArt() == "Loewe")) return true;
		if(gehege.getArt() == "Volgelgehege" && (tier.getArt() == "Adler" ||tier.getArt() == "Papagei"||tier.getArt() == "Pinguine")) return true;
		if(gehege.getArt() == "Aquarium" && (tier.getArt() == "Walhai" ||tier.getArt() == "Kugelfisch")) return true;
		if(gehege.getArt() == "Fluss" && (tier.getArt() == "Krokodil" ||tier.getArt() == "Flusspferde")) return true;
		if(gehege.getArt() == "Wueste" && tier.getArt() == "Skorpione" ) return true;
		if(gehege.getArt() == "Erde" && tier.getArt() == "Mulle" ) return true;
		return false;
		
	}
	
	
	public boolean checkTier(TierList tier, GehegeList gehege)
	{
		
		if (compareTierUndGehege(tier,gehege))
		{
			if(gehege.isEmpty()) return true;
			else if (tier.getArt() == gehege.getTierArt(gehege)) return true;
		}
		
		return false;
	}
	
	public boolean addTier (TierList tier, GehegeList gehege)  {
    	
		if(compareTierUndGehege(tier, gehege)) {
				if(checkTier(tier, gehege)) {
					System.out.println(tier.getArt()+": '" +tier.getName() + "' ist in Gehege('"+getName()+"') eingezogen.");	
					return true;
				}else {
					System.out.println(tier.getName()+ " (" + tier.getArt()+ ") kann nicht mit Tieren des Types '"+ gehege.getTierArt(gehege) + "' zusammenleben.");	
				}

			}else {
				System.out.println(tier.getName()+ " (" + tier.getArt()+ ") kann nicht in ein Gehege der Art '" +gehege.getArt()+ "' zugeordnet werden.");	
			}
			
		
		return false;	

	}

	
	
		
}
