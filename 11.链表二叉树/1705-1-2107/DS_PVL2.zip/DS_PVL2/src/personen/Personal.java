package personen;

import zoo.*;
import tiere.*;

public class Personal extends Personen{
	private final static boolean personal = true;
	private ZooList arbeitsplatz;
	private Tier[] betreut = new Tier[100];
		private int betreuteTiereAnzahl = 0;

	public Personal(String name) {
		super(name, personal);
		this.arbeitsplatz = null;
	}
	
	public Personal(String name, ZooList arbeitsplatz) {
		super(name, personal);
		this.arbeitsplatz = arbeitsplatz;
	}
	
	public void setBetreut(String art) {
		Tier[] tmpTiere = arbeitsplatz.getTiere();
		for (int i = 0; i< arbeitsplatz.getTiereAnzahl(); i++) {
			if(tmpTiere[i].getArt() == art) {
				betreut[betreuteTiereAnzahl] = tmpTiere[i];
				betreuteTiereAnzahl++;
			}
		}
	}
	
	public void printBetreuteTiere() {
		System.out.print(this.getName() + " betreut: ");
		for (int i = 0; i< betreuteTiereAnzahl; i++) {
			System.out.print(betreut[i].getName()+ ", ");	
		}
		System.out.print("\n");	
	}
	
    public String getBetreuteTiereListe() { 
    	String tierListe = "";
    	for(int i=0; i<betreuteTiereAnzahl;i++){
    		tierListe = tierListe.concat(betreut[i].getName());		//concat => f�gt String an ende des Strings hinzu
    		if(i!=(betreuteTiereAnzahl-1)) {
    			tierListe = tierListe.concat(", ");	
    		}
    	}
			
    	
		return tierListe;
	}

}
