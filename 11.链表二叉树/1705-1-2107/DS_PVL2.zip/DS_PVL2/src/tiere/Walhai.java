package tiere;
public class Walhai extends Wassertier{
	private static final String typ = "Walhai";
		
	public Walhai(String name) {
		super(name,typ);
	}	
}