package tiere;
public class Zebra extends Landsaeugetier{
	private static final String typ = "Zebra";
		
	public Zebra(String name) {
		super(name,typ);
	}	
}