package tiere;

import list.*;

public class TierList extends MyLinkedList {
	
		
	public TierList(String name, String art, MyLinkedList next) 
	{
		super(name, art, next);
	}

		
}

