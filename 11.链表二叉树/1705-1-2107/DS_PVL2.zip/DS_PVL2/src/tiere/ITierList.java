package tiere;

import list.*;

public interface ITierList extends MyListIterator{
	
	

}
