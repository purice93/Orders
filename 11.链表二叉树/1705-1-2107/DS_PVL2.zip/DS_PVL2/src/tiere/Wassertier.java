package tiere;
public class Wassertier extends Tier {
	private static final String art = "Wassertier";
	
	public Wassertier(String name,String typ){
		super(name,typ, art);
	}
}
