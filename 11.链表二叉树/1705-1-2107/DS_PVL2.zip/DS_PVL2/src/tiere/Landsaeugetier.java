package tiere;

public class Landsaeugetier extends Tier {
	private static final String art = "Landsaeugetier";
	
	public Landsaeugetier(String name,String typ){
		super(name,typ, art);
	}
}
