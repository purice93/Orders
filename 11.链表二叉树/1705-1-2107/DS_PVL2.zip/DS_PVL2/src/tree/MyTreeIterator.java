package tree;

public interface MyTreeIterator {

}
