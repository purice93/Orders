package tree;

public class MyTree {

}
