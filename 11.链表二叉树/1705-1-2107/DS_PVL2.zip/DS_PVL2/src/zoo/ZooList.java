package zoo;

import personen.*;
import tiere.*;
import gehege.*;


public class ZooList {
	private String name;
	
	private GehegeList gehege=new GehegeList("allgemeine", "Allgemeine", null);
		private int gehegeAnzahl = gehege.size();		
	private TierList tier = new TierList("allgemeine", "Allgemeine", null);
		private int Tierindex = gehege.getTierindex(); 
		
	private Personal[] personal = new Personal[20];
		private int personalAnzahl = 0;
		
	private Besucher[] besucher = new Besucher[20];
		private int besucherAnzahl = 0;
		
	//constructor
	public ZooList(String name){
		this.name = name;
	}
	
	
	


	public String getName() {return this.name;}
	
	public void addGehege(GehegeList gehege) {
		gehege.insert_front(gehege.getName(), gehege.getArt());
	}
	
	/*public GehegeList getGehege(GehegeList gehege) {
		GehegeList g = null;
		
			if(gehege.TierUndGehege(gehege)) {
				g = gehege;
			}
			
		return g;
	}*/
	
	public void addTier(TierList tier) {
		tier.insert_front(tier.getName(), tier.getArt());
	}
	
	public TierList getTier(TierList tier) {
		TierList t = null;
		for (int i = 0; i<Tierindex;i++) {
			if(tier.compareToArt(tier)) {
				t = tier;
			}
		}	
		return t;
	}
	
	
	public TierList getTiere() {return tier;}
	public int getTiereAnzahl(GehegeList gehege) 
	{return gehege.getTierindex();}
	
	
	
	public boolean moveTierToGehege(TierList tier, GehegeList gehege) {		
		if(gehege.addTier(tier,gehege)) {
			gehege.removeData(tier);
			return true;
		}	
		return false;
	}

	public void addPersonal(Personal personal) {
		this.personal[personalAnzahl] = personal;
		personalAnzahl++;
	}
	
	
	public Personal getPersonal(String name) {
		Personal p = null;
		for (int i = 0; i<personalAnzahl;i++) {
			if(personal[i].getName() == name) {
				p = personal[i];
			}
		}	
		return p;
	}
	
	
	
	
	//Geh�rt laut uml eigentlich nicht hier hin, scheint aber der beste Ort zu sein
	public void addBesucher(Besucher besucher) {
		this.besucher[besucherAnzahl] = besucher;
		besucherAnzahl++;
	}
	
	//Geh�rt laut uml eigentlich nicht hier hin, scheint aber der beste Ort zu sein
	public Besucher getBesucher(String name) {
		Besucher b = null;
		for (int i = 0; i<besucherAnzahl;i++) {
			if(besucher[i].getName() == name) {
				b = besucher[i];
			}
		}	
		return b;
	}
	
	
	//Status in Stringform f�r die Textausgabe in der Main Klasse
	public String getStatus() {
		String tmpString = this.getName() + "\r\n \r\n";		//\r\n for text stream
		
		//Tiere
		tmpString = tmpString.concat("Tiere: \r\n");	
		tmpString = tmpString.concat("Es leben " + this.Tierindex + " Tiere im Zoo  \r\n");	
		tmpString = tmpString.concat("\r\n");	
		
		
		//Gehege
		tmpString = tmpString.concat("Gehege:  \r\n");	
		tmpString = tmpString.concat("Im Zoo gibt es " + this.gehegeAnzahl + " Gehege: \r\n");
		
		for (int i = 0; i<gehegeAnzahl;i++) {
			tmpString = tmpString.concat(gehege.getName()+"["+gehege.getTierindex()+ "] " +  "(");	
				tmpString = tmpString.concat(gehege.getTierListe() + ") ");	
			
			tmpString = tmpString.concat("\r\n");	
		}
		tmpString = tmpString.concat("\r\n");
		
		//Personal
		tmpString = tmpString.concat("Personal:  \r\n");	
		tmpString = tmpString.concat("Im Zoo arbeiten " + this.personalAnzahl + " Personen: \r\n");
		
		for (int i = 0; i<personalAnzahl;i++) {
			tmpString = tmpString.concat(personal[i].getName() + " betreut : ");	
				tmpString = tmpString.concat(personal[i].getBetreuteTiereListe());	
			
			tmpString = tmpString.concat("\r\n");	
		}
		tmpString = tmpString.concat("\r\n");
		
		//Besucher
		tmpString = tmpString.concat("Besucher:  \r\n");	
		tmpString = tmpString.concat("Es sind " + this.besucherAnzahl + " Besucher im Zoo: \r\n");
		
		for (int i = 0; i<besucherAnzahl;i++) {
			tmpString = tmpString.concat(besucher[i].getName() + " steht am Gehege: ");	
			tmpString = tmpString.concat(besucher[i].getGehege().getName());	
			tmpString = tmpString.concat(" und sieht: ");	
			tmpString = tmpString.concat(besucher[i].getGehege().getTierListe());	
			tmpString = tmpString.concat("\r\n");	
		}
		tmpString = tmpString.concat("\r\n");
		
		return tmpString;
	}
	
	
	
	

}
