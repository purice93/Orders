package list;

public class MyLinkedList {

		//DatenSpeischer
	protected String name;
	protected String art;
		//Referenz von Nachfolgen
	protected MyLinkedList next;
		
		public MyLinkedList (String name,String art, MyLinkedList next)//Daten und Nachfolgen
		{
			this.name=name;
			this.art = art;
			this.next=next;
		}
		
		public MyLinkedList (String name,String art)
		{
			this.name=name;
			this.art = art;
			this.next=null;
		}
		
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getArt() {
			return art;
		}
		public void setArt(String art) {
			this.art = art;
		}
		
		public MyLinkedList getNext() {
			return next;
		}
		public void setNext(MyLinkedList next) {
			this.next = next;
		}
	
	//Listed anlegen
		MyLinkedList head =null;//Leer List aufgabe
		
		public boolean isEmpty()
		{
			return(head == null);
		}
	
	public void insert_front(String name,String art)
	{
		MyLinkedList front = new MyLinkedList(name,art,head);
		//front.setNext(head);
		head = front;		
	}
	//Einf��gen eines Elements am Ende der Liste
	/*
	 * 
	 * */
	public void insert_back(String name, String art) // Iterative Methode
	{
		//Hilfes Zeiger/Referenzer
		MyLinkedList tmp = head;
		if (head == null)// leer list
		{	insert_front(name,art);
			return;
		}
		while (tmp.getNext()!=null) // Ѱ�����һ��Ԫ�أ�֪���ҵ�nextΪnull��Ԫ��
		{
			tmp = tmp.getNext();
		}
		tmp.setNext(new MyLinkedList (name,art, null));//���ҵ������һ��Ԫ�ص�next���һ����Ԫ�أ�֮��������Ԫ�ظ�ֵΪdata		
	}
	
	// Komplekte List Loeschen
	public void clear()
	{
		this.head = null;
		//alle nodes, die nicht mittels Referenz erreichar sind, werden von Garbage...
	}
	public int size()
	{
		int count =0;
		MyLinkedList node = head;
		while (node.getNext()!=null)
		{
			count ++;
			node = node.getNext();
		}
		return count;
	}
	
	public void removeData(MyLinkedList aim)
	{
		MyLinkedList tmp = head;
		MyLinkedList tmp_before = tmp;
		
		while (tmp != null)
		{
			if (tmp.compareTo(aim))
			{
				//head soll geloescht werden
				if (tmp == head)
				{
					this.head=tmp.getNext();
				}
				else
				{
					tmp_before.setNext(tmp.getNext());
				}
			}
			tmp_before = tmp;
			tmp = tmp.getNext();
		}
	}
	
	public boolean compareTo (MyLinkedList other)
	{
		if(this.name == other.getName() && this.art == other.getArt() )
		return true;
		return false;			
	}
	
	public boolean compareToArt (MyLinkedList otherart)
	{
		if(this.art == otherart.getArt() )
		return true;
		return false;			
	}
	
	
		public boolean hasNext(MyLinkedList tmp)
	{
		
		while (tmp !=null)
		{
			if (tmp.getNext()!= null) return true;
		}
		return false;	
	}
	
	public MyLinkedList next(MyLinkedList tmp)
	{
		if (tmp.hasNext(tmp)) tmp = tmp.getNext();
		return tmp;	
	}
	
	
	 

}


