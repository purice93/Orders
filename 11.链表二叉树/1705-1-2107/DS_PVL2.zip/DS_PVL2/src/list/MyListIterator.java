package list;


public interface MyListIterator  {
	
		

		public boolean compareTo (MyLinkedList other);
		
		public boolean hasNext(MyLinkedList tmp);
		
		public MyLinkedList next(MyLinkedList tmp);
		
		public void removeData(String name, String art);
		
		public int size();
		
		public boolean isEmpty();
		
		public void insert_front(String name,String art);
		
		public void insert_back(String name, String art);
		
		public void clear();



		public String getName(); 

		public void setName(String name) ;

		public String getArt() ;
		
		public void setArt(String art) ;

		
		public MyLinkedList getNext() ;

		public void setNext(MyLinkedList nextgehege);

		

		
	}


