package gehege;

public class Vogelgehege extends Gehege{
	 private final static String art = "Vogel";
	 
	 public Vogelgehege (String name)
	    {
	    	super(name,art);
	    }
}
