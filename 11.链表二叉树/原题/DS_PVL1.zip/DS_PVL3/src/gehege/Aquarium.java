package gehege;

public class Aquarium extends Gehege{
	 private final static String art = "Wassertier";
	 
	 public Aquarium (String name)
	    {
	    	super(name,art);
	    }
}