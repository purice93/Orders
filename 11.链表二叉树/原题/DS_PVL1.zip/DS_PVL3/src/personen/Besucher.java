package personen;

public class Besucher extends Personen {
	private final static boolean personal = false;

	public Besucher(String name) {
		super(name, personal);
	}
	
	
	

}
