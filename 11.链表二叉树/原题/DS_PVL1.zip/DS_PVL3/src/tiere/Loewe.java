package tiere;
public class Loewe extends Landsaeugetier{
	private static final String typ = "Loewe";
		
	public Loewe(String name) {
		super(name,typ);
	}	
}