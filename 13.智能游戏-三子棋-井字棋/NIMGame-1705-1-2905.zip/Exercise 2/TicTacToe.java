package tic;

/**
 * Created by mrahman on 5/24/2017.
 */
public class TicTacToe {
	public static void main(String[] args) {
		GameController gc = new GameController();
		gc.startGame();
	}
}
