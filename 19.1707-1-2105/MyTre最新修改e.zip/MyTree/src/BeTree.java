

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class BeTree {

	// 构建二叉树
	public static ExpressionTreeNode build(String[] expression) {
		int[] prio = new int[expression.length]; // 算数优先级
		int valiLen = dealPrio(expression, prio);// 处理后有效数据的长度（去掉括号）
		// 建立二叉树
		ExpressionTreeNode treeNode = buildFle(expression, prio, 0, valiLen - 1);
		return treeNode;
	}

	// 遍历二叉树（保留）
	/*
	 * public static void levelTravel(ExpressionTreeNode expressionTreeNode) {
	 * ArrayList<String> intList=new ArrayList<String>();
	 * ArrayList<ExpressionTreeNode> treeList=new
	 * ArrayList<ExpressionTreeNode>(); if(expressionTreeNode==null){ return; }
	 * treeList.add(expressionTreeNode); for(int i=0;i<treeList.size();i++){
	 * ExpressionTreeNode node= treeList.get(i); if(node.getLeft()!=null){
	 * treeList.add(node.getLeft()); } if(node.getRight()!=null){
	 * treeList.add(node.getRight()); } intList.add(node.getSymbol());
	 * System.out.print(node.getSymbol()+" "); } }
	 */

	// 层次遍历二叉树
	static ArrayList<ArrayList<String>> Print(ExpressionTreeNode pRoot) {
		ArrayList<ArrayList<String>> arrs = new ArrayList<ArrayList<String>>();
		if (pRoot == null) {
			return null;
		}
		Queue<ExpressionTreeNode> q = new LinkedList<ExpressionTreeNode>();
		q.add(pRoot);
		int last = q.size(), count = 0;
		while (!q.isEmpty()) {
			count = 0;
			last = q.size();
			ArrayList<String> arr = new ArrayList<String>();
			// 输出一层数
			while (count < last) {
				ExpressionTreeNode tr = q.poll();
				count++;
				arr.add(tr.getSymbol());
				if (tr.left != null) {
					q.add(tr.left);
				}
				if (tr.right != null) {
					q.add(tr.right);
				}
			}
			arrs.add(arr);
		}
		return arrs;
	}

	// 优先级处理
	public static int dealPrio(String[] expression, int[] prio) {
		int kuohao = 0;// 用于括号里面操作符号升级
		for (int i = 0; i < expression.length; i++) {
			switch (expression[i]) {
			case "-":
				prio[i] = 1 + kuohao;
				break;
			case "+":
				prio[i] = 1 + kuohao;
				break;
			case "*":
				prio[i] = 2 + kuohao;
				break;
			case "/":
				prio[i] = 2 + kuohao;
				break;
			case "(":
				kuohao += 2;
				prio[i] = 32767;
				break;
			case ")":
				kuohao -= 2;
				prio[i] = 32767;
				break;
			default:
				prio[i] = -32768;
			}
		}
		int j = 0;// 对括号进行去除操作
		for (int i = 0; i < expression.length; i++) {
			if (expression[i].equals("(") || expression[i].equals(")")) {
				continue;
			} else {
				expression[j] = expression[i];
				prio[j] = prio[i];
				j++;
			}
		}
		return j;// 有效数据的长度
	}

	// 构建二叉树
	public static ExpressionTreeNode buildFle(String[] expression, int[] prio, int start, int end) {
		if (start == end)// 此时只有有个值的点
		{
			ExpressionTreeNode treeNode = new ExpressionTreeNode(expression[start]);
			return treeNode;
		} else {
			// 如果不只是有值
			int prioOpe = Integer.MAX_VALUE;// 记录优先级最低的操作符值
			int currentnum = start;// 记录最低的优先级操作符位置
			// 查找最小级别的操作符
			for (int i = start; i <= end; i++) {
				if (prio[i] != -32768 && prio[i] < prioOpe) {
					prioOpe = prio[i];
					currentnum = i;
				}
			}
			// 当找到最小的操作符后，以此操作符为根做扩展
			ExpressionTreeNode expressionTreeNode = new ExpressionTreeNode(expression[currentnum]);
			expressionTreeNode.left = buildFle(expression, prio, start, currentnum - 1);
			expressionTreeNode.right = buildFle(expression, prio, currentnum + 1, end);
			return expressionTreeNode;

		}
	}
}

// 树节点
class ExpressionTreeNode {
	public String symbol; //数据
	public ExpressionTreeNode left, right; // 左右节点
	private int inX;
	private int iny;

	public int getInX() {
		return inX;
	}

	public void setInX(int inX) {
		this.inX = inX;
	}

	public int getIny() {
		return iny;
	}

	public void setIny(int iny) {
		this.iny = iny;
	}

	public ExpressionTreeNode(String symbol) {
		this.symbol = symbol;
		this.left = this.right = null;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public ExpressionTreeNode getLeft() {
		return left;
	}

	public void setLeft(ExpressionTreeNode left) {
		this.left = left;
	}

	public ExpressionTreeNode getRight() {
		return right;
	}

	public void setRight(ExpressionTreeNode right) {
		this.right = right;
	}
}
