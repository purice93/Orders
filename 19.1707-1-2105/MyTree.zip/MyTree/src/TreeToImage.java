

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class TreeToImage extends JApplet implements ActionListener {
	private JFrame frame = null; // 主界面框架
	private File file = null;// 图片文件
	private JPanel jp = null;// 右侧展示面板
	private static TreeToImage cot = new TreeToImage(); // 定义实体类
	private JLabel label = null;// 图片展示面板
	private static final long serialVersionUID = 1L;
	private JLabel textArea = new JLabel("中缀表达式"); // 提示标题
	private static String imagePath = "image.png"; // 图片初始化地址
	private ImageIcon img = null; // 初始化面板图片图标
	private JTextField textField = new JTextField("");// 表达式显示框
	String input = "";// 输入的 式子，textField转为String

	/*
	 * @see java.applet.Applet#init() 覆写Applet里边的init方法,初始化界面
	 */
	public void init() {
		Container C = getContentPane();// 定义容器（左侧整个区域）
		JButton b[] = new JButton[19]; // 19个键盘按钮
		JPanel panel = new JPanel(); // 定义一个容器（左侧键盘）
		panel.setLayout(new GridLayout(5, 4, 5, 5));// 设置容器为5行4列，大小为5*5
		JPanel panelText = new JPanel(new GridLayout(2, 1, 10, 5));// 设置容器为2行1列，大小为10*5
		panelText.add(textArea); // 添加提示和表达式显示
		panelText.add(textField);
		C.add(panelText, BorderLayout.NORTH); // 位置分别为上部和中间
		C.add(panel, BorderLayout.CENTER);
		String name[] = { "(", ")", "*", "/", "1", "2", "3", "+", "4", "5", "6", "-", "7", "8", "9", "输出", "C", "0",
				"AC" };// 按钮名（键盘字符）

		// 按钮
		for (int i = 0; i < 19; i++)// 添加按钮
		{
			// 保留15号"输出"改为长键
			/*
			 * if (i == 15) { b[i] = new JButton(name[i]); b[i].setSize(5, 5);
			 * b[i].setBackground(new Color(192, 192, 192));
			 * b[i].setForeground(Color.BLUE);// 数字键 设置为 蓝颜色 b[i].setFont(new
			 * Font("宋体", Font.PLAIN, 16));// 设置字体格式 panel.add(b[i]);
			 * b[i].addActionListener(this); continue; }
			 */
			b[i] = new JButton(name[i]);
			b[i].setBackground(new Color(192, 192, 192));
			b[i].setForeground(Color.BLUE);// 数字键 设置为 蓝颜色
			b[i].setFont(new Font("宋体", Font.PLAIN, 16));// 设置字体格式
			panel.add(b[i]);
			b[i].addActionListener(this);
		}
	}

	// 监听键盘按钮
	public void actionPerformed(ActionEvent e) {
		String actionCommand = e.getActionCommand();// 获取按钮值
		// 清除最后一个数
		if (actionCommand.equals("C"))
			input = input.substring(0, input.length() - 1);
		// 清空所有数
		else if (actionCommand.equals("AC"))
			input = "";
		// 输出图像
		else if (actionCommand.equals("输出")) {
			BeTree mytree = new BeTree(); //实例化ExpressionTreeBuild，用于二叉树相关处理
			String[] expression = new String[input.length()]; 
			
			// 将中缀表达式字符串转为字符串数组
			for (int i = 0; i < input.length(); i++) {
				expression[i] = "" + input.charAt(i);
			}

			//String[] expression1 = new String[] { "2", "*", "3", "/", "(", "2", "-", "1", ")", "+", "5", "*", "4" };
			ExpressionTreeNode node1 = mytree.build(expression);

			// Print方法：层次遍历二叉树，每一层为一个list，返回ArrayList<ArrayList<String>>
			ArrayList<ArrayList<String>> arrs1 = new ArrayList<ArrayList<String>>();
			arrs1 = mytree.Print(node1);
			
			// 画出二叉树图形
			try {
				makeImage(arrs1, cot);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			/*
			 * mytree.creatTree(input);//创建表达式的二叉树
			 * System.out.println(mytree.getRoot().getData()+"000000");
			 * //mytree.output();//输出验证 mytree.levelTravel(mytree.getRoot());
			 */
		} else
			input += actionCommand;// 数字为了避免多位数的输入 不需要加空格
		textField.setText(input);
	}

	public static void main(String args[]) {
		cot = new TreeToImage();
		cot.frame = new JFrame("Count");
		TreeToImage applet1 = new TreeToImage();
		// cot.jp = createImage(cot.imagePath);

		cot.frame.getContentPane().add(applet1, BorderLayout.WEST);
		// cot.frame.getContentPane().add(cot.jp, BorderLayout.EAST);
		applet1.init();// applet的init方法
		applet1.start();// 线程开始
		cot.frame.setSize(600, 400);// 设置窗口大小
		cot.frame.setVisible(true);// 设置窗口可见
	}

	private static JPanel createImage(String imagePath) {
		JPanel jPanelTe = new JPanel();
		jPanelTe.setLocation(20, 300);
		JButton jbt1 = new JButton("保存");
		// JButton jbt2 = new JButton("新建");
		JButton jbt3 = new JButton("退出");
		jPanelTe.add(jbt1);
		// jPanelTe.add(jbt2);
		jPanelTe.add(jbt3);

		JPanel jPanel = new JPanel(new GridLayout(2, 1, 10, 10));

		cot.label = new JLabel();
		cot.img = new ImageIcon(imagePath);
		cot.label.setIcon(cot.img);
		jPanel.add(cot.label);
		jPanel.add(jPanelTe);

		jbt1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save(cot.file);
			}

			private void save(File file) {
				JFileChooser jChooser2 = new JFileChooser();
				jChooser2.setCurrentDirectory(new File("e:/"));// 设置默认打开路径
				jChooser2.setDialogType(JFileChooser.SAVE_DIALOG);// 设置保存对话框

				int index = jChooser2.showDialog(null, "保存文件");
				if (index == JFileChooser.APPROVE_OPTION) {

					File f = jChooser2.getSelectedFile();
					String fileName = jChooser2.getName(f);
					String writePath = jChooser2.getCurrentDirectory().getAbsolutePath() + "\\" + fileName;
					System.out.println(writePath);
					copyFile(cot.imagePath, writePath);
					// 程序执行完毕后，出现一个对话框来提示
					int option = JOptionPane.showConfirmDialog(null, "保存成功！！", "结果", JOptionPane.YES_NO_OPTION);
					System.exit(0);
				}
			}
		});

		/*
		 * jbt2.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) {
		 * 
		 * } });
		 */
		jbt3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cot.frame.dispose();
			}
		});

		return jPanel;
	}

	public void makeImage(ArrayList<ArrayList<String>> arrs1, TreeToImage cot) throws Exception {
		// 定义图片大小
		int width = 300;
		int height = 180;

		// 设置图片画板
		BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = (Graphics2D) bi.getGraphics();
		g2.setBackground(Color.WHITE);
		g2.clearRect(0, 0, width, height);
		g2.setPaint(Color.RED);

		// 定位开始位置
		double x = (width + 40) / 2;
		double y = 20;

		// 定义层间隔
		int down = 0;
		
		// 定义层的深度
		int dept = 0;
		
		// 依次画每一层
		for (ArrayList<String> list : arrs1) {
			int leftindex = (int) x - (dept * 10); // 每一行最左侧
			int add = 0; // 行间隔
			for (int k = 0; k < list.size(); k++) {
				g2.drawString(list.get(k), (int) leftindex + add, (int) y + down);
				add += 15;
			}
			down += 20;
			dept++;
		}
		
		// 复制空白图片用于和二叉树字符合成 为图片
		cot.file = copyFile(cot.imagePath, "result.png");
		// 合成图片
		ImageIO.write(bi, "png", cot.file);
		
		// 将合成图片显示在界面上，刷新
		cot.jp = createImage("result.png");
		cot.frame.remove(cot.jp);
		cot.frame.getContentPane().add(cot.jp, BorderLayout.EAST);
		cot.frame.invalidate();
		cot.frame.repaint();
		cot.frame.setVisible(true);

	}

	// 复制图片
	public static File copyFile(String src, String target) {
		File srcFile = new File(src);
		File targetFile = new File(target);
		try {
			InputStream in = new FileInputStream(srcFile);
			OutputStream out = new FileOutputStream(targetFile);
			byte[] bytes = new byte[1024];
			int len = -1;
			while ((len = in.read(bytes)) != -1) {
				out.write(bytes, 0, len);
			}
			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new File(target);
	}
}