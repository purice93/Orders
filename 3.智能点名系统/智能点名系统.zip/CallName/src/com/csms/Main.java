package com.csms;
 
import com.csms.windows.AdmintratorWindow;

// ������
public class Main {
    public static void main(String[] args) {
        new AdmintratorWindow();   
    }
}