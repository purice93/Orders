package com.csms.entity;

public class CalledNumber {
	private int calledNumber;
	private int lateNumber;
	
	public int getCalledNumber() {
		return calledNumber;
	}
	public void setCalledNumber(int calledNumber) {
		this.calledNumber = calledNumber;
	}
	public int getLateNumber() {
		return lateNumber;
	}
	public void setLateNumber(int lateNumber) {
		this.lateNumber = lateNumber;
	}
	
	
}
