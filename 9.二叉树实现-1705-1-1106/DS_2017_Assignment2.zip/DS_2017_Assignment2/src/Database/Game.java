package Database;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Class to represent a PlayStation game.
 * Created for Data Structures, SP2 2017
 * @author James Baumeister
 * @version 1.0
 */
public class Game {

    public Game() {}

    public Game(String name, Calendar released, int totalTrophies) {
    }

    public String toString() {
		return null;
    }

    @Override
    public boolean equals(Object o) {
		return false;
    }

	public Object getReleased() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getTotalTrophies() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setNext(Game g2) {
		// TODO Auto-generated method stub
		
	}
}
