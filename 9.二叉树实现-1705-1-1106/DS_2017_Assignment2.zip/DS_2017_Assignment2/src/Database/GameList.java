package Database;

/**
 * Class to represent a single linked-list of Database.Game objects.
 * Created for Data Structures, SP2 2017
 * @author James Baumeister
 * @version 1.0
 */
public class GameList {

    public Game head;

	public GameList(Game head) {
    }

    public String toString() {
		return null;
    }

	public void getGame(Game object) {
		// TODO Auto-generated method stub
		
	}
}
