package nz.ac.massey.cs159272.ass1.id;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.junit.Test;

public class TestPersistency {
	private final String wfilename = "write.txt";
	private final File wfile = new File("write.txt");
	private final File rfile = new File("read.txt");
	private final File nofile = new File("nofile.txt");// unfound file
	private SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	Date dob1 = new Date();
	Course course1 = new Course("01", "Software Engineering");
	Address address1 = new Address("1 Main St", "Palmerston North", "10001", 12601);
	Student student1 = new Student("120574842", "John", "Smith", dob1, course1, address1);
	Student student2 = new Student("name2", "firstName2", "id2", dob1, course1, address1);
	
	Collection<Student> studentList = new ArrayList<>();
	{
		try {
			dob1 = formatter.parse("20-1-1990");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		studentList.add(student1);
		studentList.add(student2);
	}
	@Test
	public void testSaveCollectionOfStudentFile() throws IOException {
		StudentStorage.save(studentList, wfile);
	}

	@Test
	public void testSaveCollectionOfStudentString() throws IOException {
		StudentStorage.save(studentList, wfilename);
	}

	@Test
	public void testFetch() throws IOException, Throwable {
		Collection<Student> studentListT = StudentStorage.fetch(rfile);
		System.out.println(studentListT);
	}

}
