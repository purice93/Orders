package nz.ac.massey.cs159272.ass1.id;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class TestCloningStudents {

	@SuppressWarnings("deprecation")
	@Test
	public void testClone() throws CloneNotSupportedException {
		Course c1 = new Course();
		c1.setName("course01");
		Course c2 = new Course();
		c2.setName("course02");
		
		Address adr1 = new Address();
		adr1.setPostCode("110");
		Address adr2 = new Address();
		adr2.setPostCode("220");
		Student s1 = new Student(new Date(1000), adr1);
		s1.setCourse(c1);
		Student s2 = (Student) s1.clone();
		s1.setDob(new Date(2000));
		adr1.setPostCode("220");
		c1.setName("course02");
		
		assertArrayEquals(s1.getCourse(), s2.getCourse());
		assertArrayEquals(s1.getDob(), s2.getDob());
		assertArrayEquals(s1.getAddress(), s2.getAddress());
	}

	private void assertArrayEquals(Address address, Address address2) {
		if(address.getPostCode().equals(address2.getPostCode())) {
			System.out.println("true");
		}
		System.out.println(address.getPostCode());
		System.out.println(address2.getPostCode());
	}

	private void assertArrayEquals(Date dob, Date dob2) {
		if(dob.equals(dob2)) {
			System.out.println("true");
		}
		System.out.println(dob);
		System.out.println(dob2);
	}

	private void assertArrayEquals(Course course, Course course2) {
		if(course.equals(course2)) {
			System.out.println("true");
		}
		System.out.println(course.getName());
		System.out.println(course2.getName());
	}

}
