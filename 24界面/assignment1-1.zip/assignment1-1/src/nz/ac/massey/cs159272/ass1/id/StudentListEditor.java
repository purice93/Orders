package nz.ac.massey.cs159272.ass1.id;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JTable;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import com.jgoodies.forms.layout.FormSpecs;
import java.awt.Panel;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class StudentListEditor extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2523869083671353256L;
	private SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	private Student curStudent = new Student();
	private JPanel panel_1 = new JPanel();
	private Panel panel_2 = new Panel();
	private Vector<Vector> tblDate = new Vector<Vector>();;
	private Vector<String> tblHeaders = new Vector<String>();;
	private DefaultTableModel model = null;
	private File file = null;
	private Collection<Student> studentList = new ArrayList<>();
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JComboBox textField_5 = new JComboBox<>();
	private JTable table;
	private File savefile = new File("save.txt");

	{

		tblHeaders.add("StudentName");
		table = new JTable();

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentListEditor window = new StudentListEditor();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentListEditor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		Course c1 = new Course("01", "Software Engineering");
		Course c2 = new Course("02", "Deep Learning");
		Course c3 = new Course("03", "NLP");
		Course[] courseList = { c1, c2, c3 };
		textField_5.addItem(c1.toString());
		textField_5.addItem(c2.toString());
		textField_5.addItem(c3.toString());
		frame = new JFrame();
		BorderLayout borderLayout = (BorderLayout) frame.getContentPane().getLayout();
		borderLayout.setVgap(10);
		borderLayout.setHgap(50);
		frame.setBounds(100, 100, 646, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.NORTH);

		JButton btnNewButton = new JButton("Exit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		panel.add(btnNewButton);

		JSeparator separator = new JSeparator();
		panel.add(separator);

		JSeparator separator_2 = new JSeparator();
		panel.add(separator_2);

		JButton btnNewButton_1 = new JButton("Load");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.showOpenDialog(btnNewButton_1);
				file = fc.getSelectedFile();
				try {
					studentList = StudentStorage.fetch(file);
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				Vector<Vector> studentnames = new Vector<>();
				for (Student s : studentList) {
					Vector v = new Vector<>();
					v.add(s.getName());
					studentnames.add(v);
				}
				tblDate = studentnames;
				System.out.println(tblDate);
				// table.
				table.setModel(new DefaultTableModel(tblDate, tblHeaders));
				model.fireTableDataChanged();
				table.repaint();
				table.updateUI();
				panel_1.repaint();

				// textField.setText(t);
			}
		});
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("Save");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					StudentStorage.save(studentList, savefile);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				javax.swing.JOptionPane.showMessageDialog(null, "Stored Success");
			}
		});
		panel.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("Publish");
		panel.add(btnNewButton_3);

		JSeparator separator_1 = new JSeparator();
		panel.add(separator_1);

		JSeparator separator_3 = new JSeparator();
		panel.add(separator_3);

		JButton btnNewButton_4 = new JButton("Add");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (curStudent == null) {
					curStudent = new Student();
				}
				System.out.println(curStudent);
				studentList.add(curStudent);
			}
		});
		panel.add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("Clone");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					System.out.println(curStudent);
					Student cloneStudent = curStudent.clone();
				} catch (CloneNotSupportedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		panel.add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("Delete");
		panel.add(btnNewButton_6);
		FlowLayout flowLayout = (FlowLayout) panel_1.getLayout();
		flowLayout.setHgap(50);
		frame.getContentPane().add(panel_1, BorderLayout.WEST);

		// jtable

		model = new DefaultTableModel(this.tblDate, this.tblHeaders);
		table.setModel(model);
		table.setAutoCreateRowSorter(true);
		panel_1.add(table);

		// SelectionListener listener = new SelectionListener(table);
		// table.getSelectionModel().addListSelectionListener(listener);
		table.addMouseListener(new java.awt.event.MouseAdapter() {

			public void mouseClicked(MouseEvent e) {

				int r = table.getSelectedRow();

				int c = table.getSelectedColumn();

				Object value = table.getValueAt(r, c);

//				String info = value.toString();
//
//				javax.swing.JOptionPane.showMessageDialog(null, info);

				Student student = getStudentByName(value.toString());
				curStudent = student;
				textField.setText(student.getId());
				textField_1.setText(student.getFirstName());
				textField_2.setText(student.getName());
				textField_3.setText(student.getDob().toString());
				textField_4.setText(student.getAddress().toString());

				// int courseIndex = getIdByStudent(student);
				textField_5.setSelectedIndex(r);
			}

		});

		frame.getContentPane().add(panel_2, BorderLayout.EAST);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[] { 30, 0, 30, 200, 50 };
		gbl_panel_2.rowHeights = new int[] { 5, 5 };
		gbl_panel_2.columnWeights = new double[] { 0.0, 0.0, 1.0, Double.MIN_VALUE, 0.0 };
		gbl_panel_2.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
		panel_2.setLayout(gbl_panel_2);

		JLabel lblNewLabel = new JLabel("id:");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 1;
		gbc_lblNewLabel.gridy = 0;
		panel_2.add(lblNewLabel, gbc_lblNewLabel);

		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 2;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 2;
		gbc_textField.gridy = 0;
		panel_2.add(textField, gbc_textField);
		textField.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("first name:");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 1;
		gbc_lblNewLabel_1.gridy = 1;
		panel_2.add(lblNewLabel_1, gbc_lblNewLabel_1);

		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.gridwidth = 2;
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 2;
		gbc_textField_1.gridy = 1;
		panel_2.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("name:");
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 2;
		panel_2.add(lblNewLabel_2, gbc_lblNewLabel_2);

		textField_2 = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.gridwidth = 2;
		gbc_textField_2.insets = new Insets(0, 0, 5, 5);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 2;
		gbc_textField_2.gridy = 2;
		panel_2.add(textField_2, gbc_textField_2);
		textField_2.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("date of birth:");
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 3;
		panel_2.add(lblNewLabel_3, gbc_lblNewLabel_3);

		textField_3 = new JTextField();
		GridBagConstraints gbc_textField_3 = new GridBagConstraints();
		gbc_textField_3.gridwidth = 2;
		gbc_textField_3.insets = new Insets(0, 0, 5, 5);
		gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_3.gridx = 2;
		gbc_textField_3.gridy = 3;
		panel_2.add(textField_3, gbc_textField_3);
		textField_3.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("address:");
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 1;
		gbc_lblNewLabel_4.gridy = 4;
		panel_2.add(lblNewLabel_4, gbc_lblNewLabel_4);

		textField_4 = new JTextField();
		textField_4.setEditable(false);
		GridBagConstraints gbc_textField_4 = new GridBagConstraints();
		gbc_textField_4.gridwidth = 2;
		gbc_textField_4.insets = new Insets(0, 0, 5, 5);
		gbc_textField_4.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_4.gridx = 2;
		gbc_textField_4.gridy = 4;
		panel_2.add(textField_4, gbc_textField_4);
		textField_4.setColumns(10);

		JButton button = new JButton("...");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame addJF = new JFrame();
				Address address = new Address();
				BorderLayout borderLayout_t = (BorderLayout) frame.getContentPane().getLayout();
				borderLayout_t.setVgap(10);
				borderLayout_t.setHgap(50);
				addJF.setBounds(100, 100, 646, 300);
				addJF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				addJF.setVisible(true);

				addJF.addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {
						System.exit(0);
					}
				});

				JButton close = new JButton("close");
				addJF.getContentPane().add(close, BorderLayout.NORTH);

				Panel panel_2_t = new Panel();
				addJF.getContentPane().add(panel_2_t, BorderLayout.CENTER);
				GridBagLayout gbl_panel_2_t = new GridBagLayout();
				gbl_panel_2_t.columnWidths = new int[] { 30, 0, 30, 200, 50 };
				gbl_panel_2_t.rowHeights = new int[] { 5, 5 };
				gbl_panel_2_t.columnWeights = new double[] { 0.0, 0.0, 1.0, Double.MIN_VALUE, 0.0 };
				gbl_panel_2_t.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
				panel_2_t.setLayout(gbl_panel_2_t);

				JLabel lblNewLabel_t = new JLabel("town:");
				GridBagConstraints gbc_lblNewLabel_t = new GridBagConstraints();
				gbc_lblNewLabel_t.insets = new Insets(0, 0, 5, 5);
				gbc_lblNewLabel_t.anchor = GridBagConstraints.EAST;
				gbc_lblNewLabel_t.gridx = 1;
				gbc_lblNewLabel_t.gridy = 0;
				panel_2_t.add(lblNewLabel_t, gbc_lblNewLabel_t);

				JTextField textField_t = new JTextField();
				GridBagConstraints gbc_textField_t = new GridBagConstraints();
				gbc_textField_t.gridwidth = 2;
				gbc_textField_t.insets = new Insets(0, 0, 5, 5);
				gbc_textField_t.fill = GridBagConstraints.HORIZONTAL;
				gbc_textField_t.gridx = 2;
				gbc_textField_t.gridy = 0;
				panel_2_t.add(textField_t, gbc_textField_t);
				textField_t.setColumns(10);

				JLabel lblNewLabel_1_t = new JLabel("street:");
				GridBagConstraints gbc_lblNewLabel_1_t = new GridBagConstraints();
				gbc_lblNewLabel_1_t.anchor = GridBagConstraints.EAST;
				gbc_lblNewLabel_1_t.insets = new Insets(0, 0, 5, 5);
				gbc_lblNewLabel_1_t.gridx = 1;
				gbc_lblNewLabel_1_t.gridy = 1;
				panel_2_t.add(lblNewLabel_1_t, gbc_lblNewLabel_1_t);

				JTextField textField_1_t = new JTextField();
				GridBagConstraints gbc_textField_1_t = new GridBagConstraints();
				gbc_textField_1_t.gridwidth = 2;
				gbc_textField_1_t.insets = new Insets(0, 0, 5, 5);
				gbc_textField_1_t.fill = GridBagConstraints.HORIZONTAL;
				gbc_textField_1_t.gridx = 2;
				gbc_textField_1_t.gridy = 1;
				panel_2_t.add(textField_1_t, gbc_textField_1_t);
				textField_1_t.setColumns(10);

				JLabel lblNewLabel_2_t = new JLabel("postCode:");
				GridBagConstraints gbc_lblNewLabel_2_t = new GridBagConstraints();
				gbc_lblNewLabel_2_t.anchor = GridBagConstraints.EAST;
				gbc_lblNewLabel_2_t.insets = new Insets(0, 0, 5, 5);
				gbc_lblNewLabel_2_t.gridx = 1;
				gbc_lblNewLabel_2_t.gridy = 2;
				panel_2_t.add(lblNewLabel_2_t, gbc_lblNewLabel_2_t);

				JTextField textField_2_t = new JTextField();
				GridBagConstraints gbc_textField_2_t = new GridBagConstraints();
				gbc_textField_2_t.gridwidth = 2;
				gbc_textField_2_t.insets = new Insets(0, 0, 5, 5);
				gbc_textField_2_t.fill = GridBagConstraints.HORIZONTAL;
				gbc_textField_2_t.gridx = 2;
				gbc_textField_2_t.gridy = 2;
				panel_2_t.add(textField_2_t, gbc_textField_2_t);
				textField_2_t.setColumns(10);

				JLabel lblNewLabel_3_t = new JLabel("houseNumber:");
				GridBagConstraints gbc_lblNewLabel_3_t = new GridBagConstraints();
				gbc_lblNewLabel_3_t.anchor = GridBagConstraints.EAST;
				gbc_lblNewLabel_3_t.insets = new Insets(0, 0, 5, 5);
				gbc_lblNewLabel_3_t.gridx = 1;
				gbc_lblNewLabel_3_t.gridy = 3;
				panel_2_t.add(lblNewLabel_3_t, gbc_lblNewLabel_3_t);

				JTextField textField_3_t = new JTextField();
				GridBagConstraints gbc_textField_3_t = new GridBagConstraints();
				gbc_textField_3_t.gridwidth = 2;
				gbc_textField_3_t.insets = new Insets(0, 0, 5, 5);
				gbc_textField_3_t.fill = GridBagConstraints.HORIZONTAL;
				gbc_textField_3_t.gridx = 2;
				gbc_textField_3_t.gridy = 3;
				panel_2_t.add(textField_3_t, gbc_textField_3_t);
				textField_3_t.setColumns(10);

				
				if(curStudent!=null&&curStudent.getAddress()!=null) {
					Address adr = curStudent.getAddress();
					textField_t.setText(adr.getTown());
					textField_1_t.setText(adr.getStreet());
					textField_2_t.setText(adr.getPostCode());
					textField_3_t.setText(String.valueOf(adr.getHouseNumber()));
				}
				close.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						address.setTown(textField_t.getText());
						address.setStreet(textField_1_t.getText());
						address.setPostCode(textField_2_t.getText());
						System.out.println(textField_3_t.getText());
						address.setHouseNumber(Integer.valueOf(textField_3_t.getText()));
						if (curStudent == null) {
							curStudent = new Student();
							curStudent.setId(textField.getText());
							curStudent.setFirstName(textField_1.getText());
							curStudent.setName(textField_2.getText());
							Date date = new Date();
							try {
								date = formatter.parse(textField_3.getText());
							} catch (ParseException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}   
							curStudent.setDob(date);
							curStudent.setAddress(address);
							int index = textField_5.getSelectedIndex();
							curStudent.setCourse(courseList[index]);
						} else {
							curStudent.setId(textField.getText());
							curStudent.setFirstName(textField_1.getText());
							curStudent.setName(textField_2.getText());
							Date date = new Date();
							try {
								date = formatter.parse(textField_3.getText());
							} catch (ParseException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}   
							curStudent.setDob(date);
							curStudent.setAddress(address);
							int index = textField_5.getSelectedIndex();
							curStudent.setCourse(courseList[index]);
						}
						textField_4.setText(address.toString());
						addJF.dispose();
					}
				});
				// addJF.addWindowListener(new WindowAdapter() {
				//
				// public void windowClosing(WindowEvent e) {
				//// this.windowClosing(e);
				// address.setTown(textField_t.getText());
				// address.setStreet(textField_1_t.getText());
				// address.setPostCode(textField_2_t.getText());
				// System.out.println(textField_3_t.getText());
				// address.setHouseNumber(Integer.valueOf(textField_3_t.getText()));
				// curStudent.setAddress(address);
				// textField_4.setText(address.toString());
				// }
				//
				// });
			}
		});
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 0);
		gbc_button.gridx = 4;
		gbc_button.gridy = 4;
		panel_2.add(button, gbc_button);

		JLabel lblNewLabel_5 = new JLabel("course:");
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_5.gridx = 1;
		gbc_lblNewLabel_5.gridy = 5;
		panel_2.add(lblNewLabel_5, gbc_lblNewLabel_5);

		// textField_5 = new JComboBox();
		GridBagConstraints gbc_textField_5 = new GridBagConstraints();
		gbc_textField_5.gridwidth = 2;
		gbc_textField_5.insets = new Insets(0, 0, 0, 5);
		gbc_textField_5.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_5.gridx = 2;
		gbc_textField_5.gridy = 5;
		panel_2.add(textField_5, gbc_textField_5);
		// textField_5.set
	}

	protected int getIdByStudent(Student student) {
		int rs = 0;
		int sum = textField_5.getItemCount();
		for (int i = 0; i < sum; i++) {
			Course c = (Course) textField_5.getItemAt(i);
			if (c.getName().equals(student.getCourse().getName())) {
				rs = i;
			}
		}
		return rs;
	}

	protected Student getStudentByName(String name) {
		Student rs = null;
		for (Student s : studentList) {
			if (s.getName().equals(name)) {
				rs = s;
			}
		}
		return rs;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}

class SelectionListener implements ListSelectionListener {
	JTable table;

	SelectionListener(JTable table) {
		this.table = table;
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (e.getSource() == table.getColumnModel().getSelectionModel() && table.getRowSelectionAllowed()) {
			int firstRow = e.getFirstIndex();
			int lastRow = e.getLastIndex();
			int row = e.getFirstIndex();
			System.out.println(e.getSource().toString());
		}
	}
}
