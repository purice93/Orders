package nz.ac.massey.cs159272.ass1.id;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;


public class StudentStorage {
	public static void save(Collection<Student> studentList, File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		for (Student student : studentList) {
			oos.writeObject(studentList);
		}
		oos.flush();
		oos.close();
	}

	public static void save(Collection<Student> studentList, String fileName) throws IOException {
		FileOutputStream fos = new FileOutputStream(fileName);
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		for (Student student : studentList) {
			oos.writeObject(student);
		}
		oos.close();
	}

	public static Collection<Student> fetch(File file) throws IOException, Throwable {
		Collection<Student> studentList = new ArrayList<>();
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		studentList = (Collection) ois.readObject();
//		for (Student student : alist) {
//			studentList.add(student);
//		}
		return studentList;
	}
}
