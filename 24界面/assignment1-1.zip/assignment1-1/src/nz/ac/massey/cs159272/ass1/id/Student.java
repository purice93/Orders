package nz.ac.massey.cs159272.ass1.id;

import java.io.Serializable;
import java.util.Date;

public class Student implements Cloneable, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -669707263902251732L;
	private String name;
	private String firstName;
	private String id;
	private Date dob;
	private Course course;
	private Address address;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course c1) {
		this.course = c1;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((course == null) ? 0 : course.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (course != other.course)
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	// shallow
	public Student(Course course) {
		super();
		this.course = course;
	}

	public Student(Date dob, Address address) {
		super();
		this.dob = dob;
		this.address = address;
	}

	public Student(String name, String firstName, String id, Date dob, Course course, Address address) {
		super();
		this.name = name;
		this.firstName = firstName;
		this.id = id;
		this.dob = dob;
		this.course = course;
		this.address = address;
	}

	// clone
	public Student clone() throws CloneNotSupportedException {
		Student s = (Student) super.clone();
		Address thisAdr = this.address;
		Address adr = new Address(thisAdr.getTown(), thisAdr.getStreet(), thisAdr.getPostCode(),
				thisAdr.getHouseNumber());
		Date date = new Date();
		date = (Date) this.dob.clone();
		s.address = adr;
		s.dob = date;
		return s;
	}

	
	
	public Student() {
		super();
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", firstName=" + firstName + ", id=" + id + ", dob=" + dob + ", course="
				+ course.toString() + ", address=" + address.toString() + "]";
	}
	
	
}
