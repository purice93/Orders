/**
 * @program 管理员窗口
 *
 */
 
package com.csms.windows;
 
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
 
import com.csms.dao.AdminitartorDAO;
import com.csms.dao.CourseDAO;
import com.csms.dao.SelectCourseDAO;
import com.csms.dao.StudentDAO;
import com.csms.entity.Adminitartor;
import com.csms.entity.Course;
import com.csms.entity.SelectCourse;
import com.csms.entity.Student;
 
public class AdmintratorWindow {
    private static final int WINDOWWIDE = 200;
    private static final int WINDOWHIGH = 400;
    private static Adminitartor admin = null;
    String userName = LoginWindow.getLoginUserName();
    String userPsd = LoginWindow.getLoginPassword();
    String url = "src//images//icons//admin1.png";
    private JFrame frame = new JFrame();

    // 管理员窗口
    public AdmintratorWindow() {
        admin = this.getAdminitratorInformation();
        this.informationArea(frame);
 
        PublicWindowSet.windowAttribute(frame, WINDOWWIDE, WINDOWHIGH, url, "管理员窗口");
    }
 
    // 面板信息呈现
    public void informationArea(JFrame jfr) {
        // 大标题
        PublicWindowSet.addLabel(jfr, 26, 30, 10, 150, 30, "管理员信息");
        // 管理员账号名
        PublicWindowSet.addLabel(jfr, 16, 20, 80, 100, 15, "账号:");
        // 管理员界面功能按钮
        addButton(1, "添加学生", 140, jfr);
        addButton(2, "退出", 260, jfr);
        // 添加管理员的详细信息
        PublicWindowSet.addLabel(jfr, 16, 65, 80, 100, 15, admin.getAdminName());
    }
 
    // 添加button
    private static void addButton(int flag, String str, int high, JFrame frm) {
        JButton button = new JButton(str);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setBounds(30, high, 130, 30);
        button.setContentAreaFilled(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                switch (flag) {
                case 1:
                    // 添加学生
                    new releaseStudentInformationWindow();
                    break;
                case 2:
                    // 退出
                    frm.dispose();
                    break;
                }
            }
        });
        frm.add(button);
    }
 
    // 获取管理员的所有信息
    public Adminitartor getAdminitratorInformation() {
        return new AdminitartorDAO().getInformation(userName, userPsd);
    }
}
 
// 添加学生信息
class releaseStudentInformationWindow {
 
    private JFrame frame = new JFrame();
    String url = "src//images//icons//admin.png";
    public releaseStudentInformationWindow() {
        this.displayInformation(this.frame);
 
    }
 
    private void displayInformation(JFrame jfr) {
        PublicWindowSet.addLabel(jfr, 26, 35, 10, 170, 30, "学生信息录入");
        PublicWindowSet.addLabel(jfr, 16, 20, 70, 90, 30, "学生ID:");
        PublicWindowSet.addLabel(jfr, 16, 20, 100, 90, 30, "登录密码:");
        PublicWindowSet.addLabel(jfr, 16, 20, 130, 90, 30, "学生姓名:");
        PublicWindowSet.addLabel(jfr, 16, 20, 160, 90, 30, "学生院系:");
 
        JTextField userName = new JTextField();
        PublicWindowSet.addTextField(userName, 100, 70, 120, 25, jfr);
        JTextField userPsd = new JTextField();
        PublicWindowSet.addTextField(userPsd, 100, 100, 120, 25, jfr);
        JTextField id = new JTextField();
        PublicWindowSet.addTextField(id, 100, 130, 120, 25, jfr);
        JTextField sdept = new JTextField();
        PublicWindowSet.addTextField(sdept, 100, 160, 120, 25, jfr);
 
        JButton button = new JButton("确定添加");
        button.setBounds(75, 330, 100, 30);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setContentAreaFilled(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Student student = new Student();
                if((userPsd.getText() == null) || (userPsd.getText() == null)|| (userName.getText() == null)|| 
                		(sdept.getText() == null)) {
                	PublicWindowSet.promptPopUp("输入不能为空!!!", "提示", jfr);
                }
                // ID
                student.setLoginName(userPsd.getText());
                // 登录密码
                student.setLoginPSD(userPsd.getText());
                // 学生姓名
                student.setStuName(userName.getText());
                // 学生系院
                student.setStuSdept(sdept.getText());
                new StudentDAO().insertStudentInformation(student);
                PublicWindowSet.promptPopUp("录入学生成功!!!", "提示", jfr);
                userName.setText("");
                userPsd.setText("");
                id.setText("");
                sdept.setText("");
            }
        });
        jfr.add(button);
        PublicWindowSet.windowAttribute(this.frame, 250, 400, url, "添加学生");
    }
}
 