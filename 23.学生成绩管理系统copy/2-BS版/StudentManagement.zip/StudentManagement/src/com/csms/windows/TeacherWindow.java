/**
 * @program 管理员窗口
 *
 */
 
package com.csms.windows;
 
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
 
import com.csms.dao.AdminitartorDAO;
import com.csms.dao.CourseDAO;
import com.csms.dao.ScoreDAO;
import com.csms.dao.SelectCourseDAO;
import com.csms.dao.StudentDAO;
import com.csms.dao.TeacherDAO;
import com.csms.entity.Adminitartor;
import com.csms.entity.Course;
import com.csms.entity.Score;
import com.csms.entity.SelectCourse;
import com.csms.entity.Student;
import com.csms.entity.Teacher;
 
public class TeacherWindow {
    private static final int WINDOWWIDE = 200;
    private static final int WINDOWHIGH = 400;
    public static Teacher teacher = null;
    String userName = LoginWindow.getLoginUserName();
    String userPsd = LoginWindow.getLoginPassword();
    String url = "src//images//icons//admin1.png";
    private JFrame frame = new JFrame();

    // 管理员窗口
    public TeacherWindow() {
    	teacher = new Teacher(userName);
        this.informationArea(frame);
 
        PublicWindowSet.windowAttribute(frame, WINDOWWIDE, WINDOWHIGH, url, "管理员窗口");
    }
 
    // 面板信息呈现
    public void informationArea(JFrame jfr) {
        // 大标题
        PublicWindowSet.addLabel(jfr, 26, 30, 10, 150, 30, "教师");
        // 管理员账号名
        PublicWindowSet.addLabel(jfr, 16, 20, 80, 100, 15, "账号:");
        // 管理员界面功能按钮
        addButton(1, "添加学生成绩", 140, jfr);
        addButton(2, "添加课程", 180, jfr);
        addButton(4, "退出", 260, jfr);
        // 添加管理员的详细信息
        //PublicWindowSet.addLabel(jfr, 16, 65, 80, 100, 15, teacher.getLoginName());
    }
 
    // 添加button
    private static void addButton(int flag, String str, int high, JFrame frm) {
        JButton button = new JButton(str);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setBounds(30, high, 130, 30);
        button.setContentAreaFilled(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                switch (flag) {
                case 1:
                    // 添加学生成绩
                    new addStudentInformationWindow();
                    break;
                case 2:
                    // 添加课程
                    new addCourseInformationWindow();
                    break;
                case 4:
                    // 退出
                    frm.dispose();
                    break;
                }
            }
        });
        frm.add(button);
    }
 
    // 获取管理员的所有信息
    public Teacher getAdminitratorInformation() {
        return teacher;
    }
}
 
// 添加学生信息
class addStudentInformationWindow {
 
    private JFrame frame = new JFrame();
    String url = "src//images//icons//admin.png";
    public addStudentInformationWindow() {
        this.displayInformation(this.frame);
 
    }
 
    private void displayInformation(JFrame jfr) {
        PublicWindowSet.addLabel(jfr, 26, 35, 10, 170, 30, "学生信息录入");
        PublicWindowSet.addLabel(jfr, 16, 20, 70, 90, 30, "学生ID:");
        PublicWindowSet.addLabel(jfr, 16, 20, 100, 90, 30, "课程ID:");
        PublicWindowSet.addLabel(jfr, 16, 20, 130, 90, 30, "成绩:");
 
        JTextField sid = new JTextField();
        PublicWindowSet.addTextField(sid, 100, 70, 120, 25, jfr);
        JTextField cid = new JTextField();
        PublicWindowSet.addTextField(cid, 100, 100, 120, 25, jfr);
        JTextField sco = new JTextField();
        PublicWindowSet.addTextField(sco, 100, 130, 120, 25, jfr);
 
        JButton button = new JButton("确定添加");
        button.setBounds(75, 330, 100, 30);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setContentAreaFilled(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Score score = new Score();
                if((sid.getText() == null) || (cid.getText() == null)|| (sco.getText() == null)) {
                	PublicWindowSet.promptPopUp("输入不能为空!!!", "提示", jfr);
                }
                // 学生ID
                score.setLoginName(sid.getText());
                // 登录密码
                score.setCourID(cid.getText());
                // 学生成绩
                score.setScore(Integer.parseInt(sco.getText()));
                new ScoreDAO().insertScore(score);
                PublicWindowSet.promptPopUp("录入学生成绩成功!!!", "提示", jfr);
                sid.setText("");
                cid.setText("");
                sco.setText("");
            }
        });
        jfr.add(button);
        PublicWindowSet.windowAttribute(this.frame, 250, 400, url, "添加学生成绩");
    }
}
 
// 录入排课信息
class addCourseInformationWindow {
    private JFrame frame = new JFrame();
    String url = "src//images//icons//admin.png";
 
    private void displayInformation(JFrame jfr) {
        PublicWindowSet.addLabel(jfr, 26, 35, 10, 170, 30, "排课信息录入");
        PublicWindowSet.addLabel(jfr, 16, 20, 70, 90, 30, "课程ID:");
        PublicWindowSet.addLabel(jfr, 16, 20, 100, 90, 30, "课程名称:");
        PublicWindowSet.addLabel(jfr, 16, 20, 130, 90, 30, "课程人数:");
        PublicWindowSet.addLabel(jfr, 16, 20, 160, 90, 30, "必修/选修:");
 
        JTextField courID = new JTextField();
        PublicWindowSet.addTextField(courID, 100, 70, 120, 25, jfr);
        JTextField name = new JTextField();
        PublicWindowSet.addTextField(name, 100, 100, 120, 25, jfr);
        JTextField number = new JTextField();
        PublicWindowSet.addTextField(number, 100, 130, 120, 25, jfr);
        JTextField attributes = new JTextField();
        PublicWindowSet.addTextField(attributes, 100, 160, 120, 25, jfr);
 
        JButton button = new JButton("确定添加");
        button.setBounds(75, 350, 100, 30);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setContentAreaFilled(false);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	Course ca = new Course();
            	if((courID.getText() == null) || (courID.getText() == null)|| (courID.getText() == null) 
            			|| (courID.getText() == null)) {
                	PublicWindowSet.promptPopUp("输入不能为空!!!", "提示", jfr);
                }
                ca.setCourID(courID.getText());
                ca.setCourName(name.getText());
                ca.setCsum(Integer.valueOf(number.getText()));
                ca.setAttributes(attributes.getText());
                

                new CourseDAO().insertCourse(ca);
                new TeacherDAO().insertCourse(ca,TeacherWindow.teacher.getLoginName());
                PublicWindowSet.promptPopUp("录入课程成功!!!", "提示", jfr);
                courID.setText("");
                name.setText("");
                number.setText("");
                attributes.setText("");
            }
        });
        jfr.add(button);
 
        PublicWindowSet.windowAttribute(this.frame, 250, 420, url, "添加课程");
    }
 

	public addCourseInformationWindow() {
        this.displayInformation(frame);
    }
}
 
// 删除信息
class deleInformationWindow {
    private JFrame frame = new JFrame();
    String url = "src//images//icons//admin.png";
 
    public deleInformationWindow() {
        this.displayInformation(frame);
    }
 
    private void displayInformation(JFrame jfr) {
        // 添加分类大标签
        PublicWindowSet.addLabel(jfr, 26, 35, 10, 170, 30, "课程修改");
 
        // 添加课程信息
        PublicWindowSet.addLabel(jfr, 16, 20, 70, 90, 30, "课程ID:");
        JTextField couIDField = new JTextField();
        PublicWindowSet.addTextField(couIDField, 85, 70, 125, 25, jfr);
        this.addButton(1, "查看所有课程", 235, this.frame, couIDField);
        this.addButton(2, "删除课程信息", 270, this.frame, couIDField);
 
        // 设置窗口属性
        PublicWindowSet.windowAttribute(jfr, 250, 420, url, "课程修改");
    }
 
    public void addButton(int flag, String str, int high, JFrame jfr, JTextField tf) {
        JButton button = new JButton(str);
        button.setFont(new Font("楷体", Font.PLAIN, 16));
        button.setContentAreaFilled(false);
        button.setBounds(50, high, 150, 30);
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                switch (flag) {
                case 1:
                    // 查看排课信息
                    DefaultTableModel courTableModel;
                    String[] courStr = { "课程ID", "课程名字","课程总人数", "已选人数" };
                    JFrame courFrame = new JFrame();
                    PublicWindowSet.windowAttribute(courFrame, 300, 400, null, "排课信息");
                    courTableModel = PublicWindowSet.addTableList(courFrame, courStr);
                    List<Course> courseList = new CourseDAO().searchAllCourse();
                    Course courseArrange = null;
                    for (int i = 0; i < courseList.size(); i++) {
                        courseArrange = courseList.get(i);
                        courTableModel.addRow(new Object[] { 
                        		courseArrange.getCourID(),
                        		courseArrange.getCourName(),
                        		courseArrange.getCsum(),
                        		courseArrange.getCselected()
                        });
                    }
                    break;
                case 2:
                    // 删除排课信息
                    String arrangeId = tf.getText();
                    if (arrangeId.length() == 0) {
                        PublicWindowSet.promptPopUp("请输入课程ID！！！", "错误提示", jfr);
                    } else {
                        new CourseDAO().deleteArrageCourse(arrangeId);
                        PublicWindowSet.promptPopUp("删除课程成功!!!", "提示", jfr);
                        tf.setText("");
                    }
                    break;
                }
            }
        });
        jfr.add(button);
    }
}