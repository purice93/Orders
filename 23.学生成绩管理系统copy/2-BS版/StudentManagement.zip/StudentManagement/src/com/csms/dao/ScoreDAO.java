package com.csms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.csms.DBLink;
import com.csms.entity.Course;
import com.csms.entity.Score;
import com.csms.entity.SelectCourse;
import com.csms.entity.Student;

public class ScoreDAO {

	public List<Score> searchScoreById(String courseID) {
        Connection conn = DBLink.getConn();
        String sql = "SELECT Sno,Cno,sco FROM score where Cno=?";
        List<Score> list = new ArrayList<Score>();
 
        PreparedStatement ptm = null;
        ResultSet rs = null;
        Score score = null;
 
        try {
            ptm = conn.prepareStatement(sql);
            ptm.setString(1, courseID);
            rs = ptm.executeQuery();
            while (rs.next()) {
            	score = new Score();
            	score.setLoginName(rs.getString("Sno"));
            	score.setCourID(rs.getString("Cno"));
            	score.setScore(Integer.parseInt(rs.getString("sco")));
                list.add(score);
            }
 
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ptm != null)
                    ptm.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
 
        return list;
	}

	public void insertScore(Score score) {
		Connection conn = DBLink.getConn();;
		PreparedStatement pstmt = null;
		
		try {
			String sql = "update studentcourse set Sco=? where Sno=? and Cno=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, score.getScore());
			pstmt.setString(2, score.getLoginName());
			pstmt.setString(3, score.getCourID());
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
