package com.csms.entity;

public class Score {
	// 登录名||学生ID
    private String loginName;
    // 课程ID，唯一标识
    private String courID;
    // 课程分数
    private int score;
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getCourID() {
		return courID;
	}
	public void setCourID(String courID) {
		this.courID = courID;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
    
}
