package com.csms.entity;

public class Teacher {
	// 登录名||学生ID
    private String loginName;
    // 登录密码
    private String loginPSD;
	private String Cno;
	public Teacher() {
	}
	public Teacher(String userName) {
		this.loginName = userName;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPSD() {
		return loginPSD;
	}
	public void setLoginPSD(String loginPSD) {
		this.loginPSD = loginPSD;
	}
	public String getCno() {
		return Cno;
	}
	public void setCno(String cno) {
		Cno = cno;
	}
}
