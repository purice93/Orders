package com;
 
import com.windows.MainWindow;

public class RunCSMS {
    public static void main(String[] args) {
        new MainWindow();   
    }
}