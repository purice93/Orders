package com.csms;
 
import com.csms.windows.MainWindow;

public class RunCSMS {
    public static void main(String[] args) {
        new MainWindow();   
    }
}