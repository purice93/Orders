package com.csms;
 
import com.csms.windows.MainWindow;

// ��ʼ������
public class RunCSMS {
    public static void main(String[] args) {
        new MainWindow();   
    }
}