package com;
/*
 * 程序启动类，程序从这里启动，执行main函数
 */
import com.windows.LoginWindow;

public class MyMain {
    public static void main(String[] args) {
    	new LoginWindow();  //生成一个登录界面
    }
}