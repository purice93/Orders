
package com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * @author jqs The main function of memory flop
 */
public class CardColor extends JFrame {

	/**
	 * Initial game interface size, the number of rows must be even
	 */
	private static final int HEIGHT = 600;
	private static final int WIDTH = 600;

	/**
	 * The number of columns to initialize the game, the number of rows must be even
	 */
	private static final int ROWS = 4;
	private static final int COLUMNS = 4;
	private static final long serialVersionUID = -8908268719780973221L;
	private boolean isRunning = false;
	
	/**
	 * Save the picture directory, 
	 * for the sake of simplicity, 
	 * the number of images stored in the directory for the initial number of rows of half of the product
	 */
	private String picDir = "pic";
	private String[] picture;
	protected boolean isStart;
	private PicPanel preOne = null;

	
	/**
	 * Initialize the two prompt box
	 */
	private JLabel lbl_Text0 = new JLabel();
	private JLabel lbl_Text1 = new JLabel();
	
	/**
	 * Used to indicate the logarithm found
	 */
	private int count;
	private JPanel panel_Pic;

	/**
	 * Initialize 6 prompt statements
	 */
	private String text1 = "- Choose your first square";
	private String text2 = "- Choose your second square";
	private String text3 = "- well done - click a square to continue";
	private String text4 = "- failed :(-click a square to end turn)";
	private String text5 = "- Player 0's turn.Please wait";
	private String text6 = "- Player 1's turn.Please wait";
	
	/**
	 * Declare two users
	 */
	private Player player0 = new Player("player0", 0, text1);
	private Player player1 = new Player("player1", 0, text5);
	

	public CardColor() {
		this.setSize(HEIGHT, WIDTH);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);

		setTitle("My Game");
		JPanel panel_Time1 = new JPanel();
		JPanel panel_Time2 = new JPanel();

		lbl_Text0 = new JLabel(
				"*** " + this.player0.getName() + ",score:" + this.player0.getScore() + this.player0.getText());
		lbl_Text0.setFont(new java.awt.Font("Dialog", 1, 20));
		lbl_Text0.setOpaque(true);
		lbl_Text0.setBackground(Color.green);
		panel_Time1.add(lbl_Text0);

		panel_Pic = new JPanel();

		lbl_Text1 = new JLabel(
				"*** " + this.player0.getName() + ",score:" + this.player0.getScore() + this.player0.getText());
		lbl_Text1.setFont(new java.awt.Font("Dialog", 1, 20));
		lbl_Text1.setOpaque(true);
		lbl_Text1.setBackground(Color.red);
		panel_Time2.add(lbl_Text1);

		this.getContentPane().add(panel_Time1, BorderLayout.NORTH);
		getContentPane().add(panel_Pic, BorderLayout.CENTER);
		getContentPane().add(panel_Time2, BorderLayout.SOUTH);

		initPicPanels();
	}

	/**
	 * Initializing image panel
	 */
	private void initPicPanels() {
		panel_Pic.setLayout(new GridLayout(ROWS, COLUMNS, 1, 1));
		initPictureIndex();
		for (int i = 0; i < ROWS * COLUMNS; i++) {
			PicPanel panel_1 = new PicPanel(this, picture[i]);
			panel_Pic.add(panel_1);
		}
	}

	/**
	 * Initialize the index of the image and assign the path to each image
	 */
	private void initPictureIndex() {
		picture = new String[ROWS * COLUMNS];

		// 这里没有检测图片目录中文件的有效性，需要保证都是图片类型。
		File file = new File(picDir);
		File[] pics = file.listFiles();

		// 初始化一个ROWS*COLUMNS的int数组，里面存放每个图片的索引
		int[] indexs = getIndexs(picture.length, pics.length);
		for (int i = 0; i < indexs.length; i++) {
			picture[i] = pics[indexs[i]].getAbsolutePath();
		}
	}

	/**
	 * An array of length sum is used to represent the index of each image based on the total number of images provided
	 * 
	 * @param sum
	 *            result of rows * columns
	 * @param picNums
	 *            The total number of images in a given directory
	 * @return
	 */
	private int[] getIndexs(int sum, int picNums) {
		int half = sum / 2;

		if (picNums < half) {
			return getIndexsByMap(sum, picNums);
		}
		int[] tmpResult = new int[sum];
		Random random = new Random(System.currentTimeMillis());
		int temp = 0;
		LinkedList<Integer> list = new LinkedList<Integer>();
		while (list.size() != half) {
			temp = random.nextInt(picNums);
			if (!list.contains(temp)) {
				list.add(temp);
			} else if (picNums < half) {
				list.add(temp);
			}
		}

		for (int i = 0; i < tmpResult.length; i++) {
			tmpResult[i] = list.get(i >= half ? i % half : i);
		}
		// Disrupt the order, otherwise the first half and the second half will be completely separated
		LinkedList<Integer> _result = new LinkedList<Integer>();
		while (_result.size() != sum) {
			temp = random.nextInt(sum);
			if (!_result.contains(temp)) {
				_result.add(temp);
			}
		}
		int[] result = new int[sum];
		for (int i = 0; i < result.length; i++) {
			result[i] = tmpResult[_result.get(i)];
		}
		return result;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	/**
	 * 当图片数量小于总格子数一半时需要使用下面的方法获取，保证所有的图片都能使用上
	 * When number is less than the total number of pictures will need to use the lattice count half time, 
	 * ensure all the pictures can be used
	 * 
	 * @param sum
	 * @param picNums
	 * @return
	 */
	private int[] getIndexsByMap(int sum, int picNums) {
		int half = sum / 2;
		int[] tmpResult = new int[sum];
		Random random = new Random(System.currentTimeMillis());
		int temp = 0;
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		// 因为图片的数量小于sum的一半，因此先按顺序将图片索引都添加到map中以保证得到的结果中每个图片都被使用到
		for (int i = 0; i < picNums; i++) {
			map.put(i, 1);
		}
		int size = picNums;
		while (size != half) {
			temp = random.nextInt(picNums);
			if (!map.containsKey(temp)) {
				map.put(temp, 1);
			} else {
				map.put(temp, map.get(temp) + 1);
			}
			size++;
		}

		List<Integer> list = mapKeyToList(map);
		for (int i = 0; i < tmpResult.length; i++) {
			tmpResult[i] = list.get(i >= half ? i % half : i);
		}
		// 将顺序打乱，否则会出现前半部分和后半部分是完全分开的情况
		LinkedList<Integer> _result = new LinkedList<Integer>();
		while (_result.size() != sum) {
			temp = random.nextInt(sum);
			if (!_result.contains(temp)) {
				_result.add(temp);
			}
		}
		int[] result = new int[sum];
		for (int i = 0; i < result.length; i++) {
			result[i] = tmpResult[_result.get(i)];
		}
		return result;
	}

	/**
	 * Map will be converted into a list in key, 
	 * where each key of the number of key that the number of times, 
	 * if the number of times in the conversion of more than 1 need to repeat the addition of key to list
	 * 
	 * @param map
	 * @return
	 */
	private List<Integer> mapKeyToList(HashMap<Integer, Integer> map) {
		List<Integer> list = new ArrayList<Integer>();
		Iterator<Integer> keyIt = map.keySet().iterator();
		Integer key = 0;
		while (keyIt.hasNext()) {
			key = keyIt.next();
			if (map.get(key) == 1) {
				list.add(key);
			} else {
				for (int i = 0; i < map.get(key); i++) {
					list.add(key);
				}
			}
		}
		return list;
	}

	public PicPanel getPreOne() {
		return preOne;
	}

	public void setPreOne(PicPanel preOne) {
		this.preOne = preOne;
	}

	public void addCount() {
		count++;
	}

	public boolean isRunning() {
		return isRunning;
	}

	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}

	/*
	 *  First step, get First box
	 */
	public void update1(CardColor parent, int curplayer) {
		if (curplayer == 0) {
			parent.player0.setText(text2);
		} else {
			parent.player1.setText(text2);
		}
		lbl_Text0.setText("*** " + parent.player0.getName() + ",score:" + parent.player0.getScore() + player0.getText());
		lbl_Text1.setText("*** " + parent.player1.getName() + ",score:" + parent.player1.getScore() + player1.getText());
	}

	/*
	 *  Two boxes are the same
	 */
	public void update2(CardColor parent, int curplayer) {
		if (curplayer == 0) {
			parent.player0.setScore(parent.player0.getScore() + 2);
			parent.player0.setText(text3);
		} else {
			parent.player1.setScore(parent.player1.getScore() + 2);
			parent.player1.setText(text3);
		}
		lbl_Text0.setText("*** " + parent.player0.getName() + ",score:" + parent.player0.getScore() + player0.getText());
		lbl_Text1.setText("*** " + parent.player1.getName() + ",score:" + parent.player1.getScore() + player1.getText());
	}

	/*
	 *  Two boxes are not the same
	 */
	public void update3(CardColor parent, int curplayer) {
		if (curplayer == 0) {
			parent.player0.setText(text4);
		} else {
			parent.player1.setText(text4);
		}
		lbl_Text0.setText("*** " + parent.player0.getName() + ",score:" + parent.player0.getScore() + player0.getText());
		lbl_Text1.setText("*** " + parent.player1.getName() + ",score:" + parent.player1.getScore() + player1.getText());
	}
	
	/*
	 *  Two boxes are the same, Change background to black
	 */
	private void changeBackground(JLabel lbl_Text02, JLabel lbl_Text03, int signal) {
		if (signal == 0) {
			lbl_Text0.setBackground(Color.red);
			lbl_Text1.setBackground(Color.green);
		} else {
			lbl_Text0.setBackground(Color.green);
			lbl_Text1.setBackground(Color.red);
		}
	}
	
	/*
	 *  Two boxes are not the same, Change player
	 */
	public int update4(CardColor parent, int curplayer, int signal) {
		if (curplayer == 0) {
			parent.player0.setText(text6);
			parent.player1.setText(text1);
			curplayer = 1;
		} else {
			parent.player1.setText(text5);
			parent.player0.setText(text1);
			curplayer = 0;
		}
		lbl_Text0.setText("*** " + parent.player0.getName() + ",score:" + parent.player0.getScore() + player0.getText());
		lbl_Text1.setText("*** " + parent.player1.getName() + ",score:" + parent.player1.getScore() + player1.getText());
		changeBackground(lbl_Text0, lbl_Text0, signal);
		return curplayer;
	}

	/*
	 *  Determine whether the game is over
	 */
	public void isComplete(CardColor parent, int count2) {
		if (count2 < ROWS * COLUMNS / 2) {
			return;
		}
		if (parent.player0.getScore() == parent.player1.getScore()) {
			JOptionPane.showMessageDialog(null, "A draw.");
		} else if (parent.player0.getScore() < parent.player1.getScore()) {
			JOptionPane.showMessageDialog(null, "Player1 Win.");
		} else {
			JOptionPane.showMessageDialog(null, "Player0 Win.");
		}
		
		// After the end of the panel to re initialize the next run
		count = 0;
		panel_Pic.removeAll();
		initPicPanels();
		panel_Pic.validate();
		isRunning = false;
	}
}
