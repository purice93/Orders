package com;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.LineBorder;

/**
 * @author jqs
 * 
 * Image panel, the main achievement of the picture and the picture to show the same judgment
 */
public class PicPanel extends JPanel {
	private static final long serialVersionUID = 2172162568449349737L;
	private String picPath;
	private JLabel lbl_Pic = new JLabel();
	private ImageIcon bgIcon = null;
	private boolean isShow = false;
	private CardColor parent;
	private boolean finished = false;
	private static int curplayer = 0;// Current player
	private static boolean failSignal = false; // Matching failure
	private static boolean picShowSignal = true;// If the match fails, do not show; match successfully, show
	private static ImageIcon lastbgIcon;// 上一个方块

	public PicPanel(CardColor CardColor, String picPath) {
		this.picPath = picPath;
		this.parent = CardColor;
		this.setBorder(new CompoundBorder(null, new LineBorder(new Color(0, 0, 0), 2)));
		this.setLayout(new BorderLayout());
		this.add(lbl_Pic, BorderLayout.CENTER);
		this.addMouseListener(mouseAdapter);
	}

	public String getPicPath() {
		return picPath;
	}

	public void setPicPath(String picPath) {
		this.picPath = picPath;
	}

	/**
	 * The mouse event of the image panel is monitored, 
	 * and the matching process is completed
	 */
	private MouseAdapter mouseAdapter = new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) {
			new Thread() {
				public void run() {
					synchronized (this) {

						if (finished) {// Matching success
							return;
						}
						isShow = !isShow; // Start, and no box
						
						if (isShow) { 
							if (bgIcon == null) { // Initialize all squares
								initLabelImage();
							}
							PicPanel curOne = (PicPanel) lbl_Pic.getParent();
							PicPanel preOne = parent.getPreOne();
							
							/*
							 * Two boxes are not the same, Change player
							 */
							if (preOne == null) { 
								if (failSignal) {
									curplayer = parent.update4(parent,curplayer, 1);
									failSignal = false;
									picShowSignal = false;
								} 
								
								/*
								 * First step, get First box
								 */
								else {
									parent.setPreOne(curOne);
									parent.update1(parent,curplayer);
								}
							} else {
								boolean right = checkRight(curOne, preOne);
								
								/*
								 * Two boxes are the same
								 */
								if (right) { 
									parent.setPreOne(null);
									curOne.setFinished(true);
									preOne.setFinished(true);
									parent.addCount();

									parent.update2(parent,curplayer);
									lbl_Pic.setIcon(bgIcon);
									try {
										Thread.sleep(500);
									} catch (InterruptedException e1) {
										e1.printStackTrace();
									}

									Image image = null;
									try {
										image = ImageIO.read(new File("black.png"));
									} catch (IOException e1) {
										e1.printStackTrace();
									}
									bgIcon = new ImageIcon(image.getScaledInstance(bgIcon.getIconWidth(), bgIcon.getIconHeight(),
											Image.SCALE_DEFAULT));
									lbl_Pic.setIcon(bgIcon);
									preOne.lbl_Pic.setIcon(bgIcon);
								} 
								
								/*
								 * Two boxes are not the same
								 */
								else { 
									lbl_Pic.setIcon(bgIcon);
									repaint();
									try {
										Thread.sleep(500);
									} catch (InterruptedException e1) {
										e1.printStackTrace();
									}
									lbl_Pic.setIcon(null);
									isShow = !isShow;
									repaint();
									preOne.getMouseListeners()[0].mouseClicked(null);
									parent.setPreOne(null);

									failSignal = true;

									parent.update3(parent,curplayer);

									return;
								}
							}
							if (picShowSignal) {
								lbl_Pic.setIcon(bgIcon); // Display box
								lastbgIcon = bgIcon;
							} else {
								picShowSignal = true;
							}
						} else {
							lbl_Pic.setIcon(null);
						}
						repaint();
						parent.isComplete(parent,parent.getCount());
					}
				};
			}.start();
		}

		/**
		 * Check whether the two panels show the same picture, 
		 * according to the path of the image to determine, 
		 * but also to ensure that the two panels are not the same panel
		 * 
		 * @param curOne
		 * @param preOne
		 * @return
		 */
		private boolean checkRight(PicPanel curOne, PicPanel preOne) {
			return curOne.getPicPath().equals(preOne.getPicPath()) && !curOne.equals(preOne);
		}
	};

	/**
	 * Initialize Label object image
	 */
	private void initLabelImage() {
		try {
			Image image = ImageIO.read(new File(picPath));
			if (image != null) {
				int lblWidth = this.getWidth();
				int lblHeight = this.getHeight();
				bgIcon = new ImageIcon(image.getScaledInstance(lblWidth, lblHeight, Image.SCALE_DEFAULT));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * When you find the matching image panel, 
	 * set the completion status to true, 
	 * then click on the image panel is invalid.
	 * 
	 * @param b
	 */
	protected void setFinished(boolean b) {
		finished = b;
	}
}