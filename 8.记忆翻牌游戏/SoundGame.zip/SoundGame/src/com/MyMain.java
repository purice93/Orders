package com;

/*
 * Main class, start two games
 */
public class MyMain {
	public static void main(String[] args) {
		CardColor remCard0 = new CardColor();
		CardColor remCard1 = new CardColor();
	}
}
